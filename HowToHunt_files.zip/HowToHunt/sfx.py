"""HOW TO HUNT - звуки и музыка. Всё синтезируется кодом (внешних файлов не нужно) и кэшируется
в ~/.how_to_hunt/sfx при первом запуске. Воспроизведение - через звуковую систему Panda3D."""
import array
import math
import os
import random
import wave

RATE = 22050
VERSION = "8"
POOLED = {"pin", "snap", "hurt", "shell", "cut", "thunder", "rifle", "shotgun", "sniper", "bow", "hit", "step", "click", "crit", "pickup", "kill"}


def _wav(path, data, rate, norm=None):
    peak = max(1e-9, max(abs(x) for x in data))
    k = norm / peak if norm else (.92 / peak if peak > .92 else 1.0)
    a = array.array("h", (int(max(-1.0, min(1.0, x * k)) * 32000) for x in data))
    with wave.open(path, "wb") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(rate)
        f.writeframes(a.tobytes())


def _n(sec):
    return int(sec * RATE)


def _noise(n, seed):
    r = random.Random(seed)
    return [r.uniform(-1, 1) for _ in range(n)]


def _lp(x, a):
    y, out = 0.0, []
    for v in x:
        y += a * (v - y)
        out.append(y)
    return out


def _hp(x, a):
    return [v - l for v, l in zip(x, _lp(x, a))]


def _sine(n, f0, f1=None, rate=RATE):
    out, ph = [], 0.0
    for i in range(n):
        f = f0 if f1 is None else f0 + (f1 - f0) * i / n
        ph += 2 * math.pi * f / rate
        out.append(math.sin(ph))
    return out


def _env(x, tau, atk=.003):
    return [v * math.exp(-(i / RATE) / tau) * min(1.0, i / (atk * RATE + 1)) for i, v in enumerate(x)]


def _mix(*layers):
    out = [0.0] * max(len(l) for l, _ in layers)
    for l, g in layers:
        for i, v in enumerate(l):
            out[i] += v * g
    return out


def _shift(x, sec):
    return [0.0] * int(sec * RATE) + list(x)


def _delay(x, sec, gain, times=2):
    step = int(sec * RATE)
    out = list(x) + [0.0] * (step * times)
    for t in range(1, times + 1):
        for i, v in enumerate(x):
            out[i + step * t] += v * gain ** t
    return out


def _shot(sec, boom, hz, tau, lp, echo=False):
    n = _n(sec)
    s = _mix((_env(_noise(n, 1), .010), .8), (_env(_lp(_noise(n, 2), lp), tau), boom),
             (_env(_sine(n, hz * 1.8, hz), tau * 1.3), .9))
    return _delay(s, .11, .28, 2) if echo else s


def _bow():
    n = _n(.55)
    twang = _env(_mix((_sine(n, 210, 170), 1), (_sine(n, 420, 340), .5), (_sine(n, 630, 510), .25)), .14)
    return _mix((twang, .7), (_env(_lp(_noise(n, 3), .25), .07), .5), (_env(_noise(n, 4), .008), .5))


def _bell(f, sec, tau):
    n = _n(sec)
    return _env(_mix((_sine(n, f), 1), (_sine(n, f * 2.01), .4)), tau)


def _coins():
    return _mix(*[(_shift(_bell(f, .3, .09), i * .055), .6) for i, f in enumerate((1250, 1650, 2100, 2500))])


def _buy():
    return _mix((_bell(700, .3, .1), .7), (_shift(_bell(1050, .3, .12), .09), .7))


def _levelup():
    return _mix(*[(_shift(_bell(f, .6, .22), i * .13), .55) for i, f in enumerate((523, 659, 784, 1047))])


def _skill():
    n = _n(.5)
    return _mix((_env(_sine(n, 900, 2200), .25), .5), (_env(_sine(n, 1800, 2600), .18), .3))


def _bird(seed):
    r = random.Random(seed)
    out = []
    for i in range(r.randint(3, 4)):
        n = _n(.085)
        f0 = r.uniform(2400, 3200)
        out += _env(_sine(n, f0, f0 * r.uniform(1.1, 1.4)), .05, .004) + [0.0] * _n(.05)
    return out


def _wind():
    n = _n(6)
    base = _lp(_noise(n, 9), .025)
    return [v * (.65 + .35 * math.sin(2 * math.pi * i / n)) for i, v in enumerate(base)]


def _fire():
    n = _n(4)
    out = [v * .6 for v in _lp(_noise(n, 10), .03)]
    r = random.Random(11)
    for _ in range(28):
        pos = r.randrange(n - 400)
        burst = _env(_hp(_noise(300, r.random()), .6), .008)
        g = r.uniform(.3, 1.0)
        for i, v in enumerate(burst):
            out[pos + i] += v * g * .5
    return out


def _music():
    """Мягкий пэд на 4 аккордах (Am - F - C - G), 16 секунд, зацикливается."""
    rate, length = 11025, 16
    total = rate * length
    buf = [0.0] * total
    chords = ((110, 164.8, 220, 261.6), (87.3, 174.6, 220, 261.6), (130.8, 196, 261.6, 329.6), (98, 196, 246.9, 293.7))
    seg = rate * 6
    for ci, chord in enumerate(chords):
        start = ci * 4 * rate
        for fi, f in enumerate(chord):
            for det in (-.35, .35):
                ph, w = 0.0, 2 * math.pi * (f + det) / rate
                for i in range(seg):
                    ph += w
                    win = math.sin(math.pi * i / seg) ** 2
                    buf[(start + i) % total] += math.sin(ph) * win * (.22 if fi else .3)
    return buf


def _rain():
    n = _n(4)
    hiss = _hp(_lp(_noise(n, 12), .6), .04)
    return [v * (.85 + .15 * math.sin(2 * math.pi * i / n * 3)) for i, v in enumerate(hiss)]


def _thunder():
    n = _n(3.4)
    rumble = _lp(_noise(n, 13), .02)
    return _mix((_env(rumble, 1.1, .08), 4.0), (_env(_sine(n, 62, 34), .9, .06), .7), (_env(_noise(n, 14), .03), .35))


def _shell():
    ting = _mix((_bell(3150, .25, .05), .5), (_bell(4720, .25, .03), .3))
    return _mix((ting, 1.0), (_shift([v * .45 for v in ting], .09), 1.0))


def _cut():
    n = _n(.28)
    swish = _hp(_noise(n, 15), .25)
    env = [math.sin(math.pi * min(1.0, i / n * 1.6)) ** 2 for i in range(n)]
    return _mix(([v * e for v, e in zip(swish, env)], .6), (_env(_sine(n, 180, 90), .05), .35))


def _cuckoo():
    out = []
    for _ in range(2):
        out += _env(_sine(_n(.22), 680, 660), .12, .02) + [0.0] * _n(.06) + _env(_sine(_n(.3), 545, 530), .16, .02) + [0.0] * _n(.35)
    return out


def _owl():
    def hoot(sec):
        n = _n(sec)
        return [v * math.sin(math.pi * i / n) for i, v in enumerate(_sine(n, 390, 350))]
    return hoot(.45) + [0.0] * _n(.25) + hoot(.18) + [0.0] * _n(.08) + hoot(.4)


def _roar():
    n = _n(1.5)
    growl = _lp(_noise(n, 16), .06)
    env = [min(1.0, i / (RATE * .15)) * math.exp(-max(0, i / RATE - .5) / .45) for i in range(n)]
    return _mix(([g * e * (1 + .5 * math.sin(i / RATE * 2 * math.pi * 23)) for i, (g, e) in enumerate(zip(growl, env))], 5.0),
                ([v * e for v, e in zip(_sine(n, 95, 55), env)], .6))


def _hurt():
    n = _n(.3)
    return _mix((_env(_sine(n, 130, 70), .08), 1.0), (_env(_lp(_noise(n, 17), .3), .05), .7))


def _chest():
    n = _n(.5)
    creak = [math.sin(2 * math.pi * (300 + 60 * math.sin(i / RATE * 40)) * i / RATE) * math.sin(math.pi * i / n) for i in range(n)]
    return _mix((creak, .35), (_shift(_coins(), .35), 1.0))


def _pin():
    n = _n(.12)
    return _mix((_env(_hp(_noise(n, 21), .3), .02), .6), (_bell(2300, .12, .03), .5))


def _snap():
    n = _n(.18)
    return _mix((_env(_hp(_noise(n, 22), .5), .03), .9), (_bell(900, .18, .02), .4))


def _unlock():
    return _mix((_bell(1200, .5, .12), .6), (_shift(_bell(1800, .5, .12), .12), .6), (_shift(_pin(), .02), .8))


RECIPES = {
    "pin": (_pin, RATE, .5),
    "snap": (_snap, RATE, .6),
    "unlock": (_unlock, RATE, .7),
    "roar": (_roar, RATE, .9),
    "hurt": (_hurt, RATE, .8),
    "chest": (_chest, RATE, .8),
    "cuckoo": (_cuckoo, RATE, .5),
    "owl": (_owl, RATE, .5),
    "shell": (_shell, RATE, .5),
    "cut": (_cut, RATE, .6),
    "rain": (_rain, RATE, .7),
    "thunder": (_thunder, RATE, .9),
    "rifle": (lambda: _shot(.5, 1.0, 90, .09, .32), RATE, None),
    "shotgun": (lambda: _shot(.6, 1.5, 70, .12, .5), RATE, None),
    "sniper": (lambda: _shot(1.1, 1.4, 55, .16, .4, True), RATE, None),
    "bow": (_bow, RATE, None),
    "hit": (lambda: _mix((_env(_sine(_n(.18), 150, 60), .05), 1), (_env(_noise(_n(.18), 5), .01), .4)), RATE, None),
    "crit": (lambda: _mix((_bell(1320, .4, .2), .6), (_bell(1980, .4, .12), .4)), RATE, None),
    "kill": (lambda: _mix((_env(_sine(_n(.45), 120, 38), .12), 1), (_env(_lp(_noise(_n(.45), 6), .2), .08), .6)), RATE, None),
    "pickup": (lambda: _mix((_env(_hp(_noise(_n(.3), 7), .5), .08), .5), (_env(_sine(_n(.3), 500, 900), .08), .3)), RATE, None),
    "sell": (_coins, RATE, None),
    "buy": (_buy, RATE, None),
    "levelup": (_levelup, RATE, None),
    "skill": (_skill, RATE, None),
    "click": (lambda: _env(_sine(_n(.06), 1000, 700), .02), RATE, .5),
    "error": (lambda: _env(_mix((_sine(_n(.25), 150, 120), 1), (_sine(_n(.25), 155, 125), .8)), .12), RATE, .5),
    "step": (lambda: _env(_lp(_noise(_n(.14), 8), .22), .035), RATE, .5),
    "bird1": (lambda: _bird(1), RATE, .5),
    "bird2": (lambda: _bird(2), RATE, .5),
    "wind": (_wind, RATE, .8),
    "fire": (_fire, RATE, .8),
    "music": (_music, 11025, .7),
}


def generate(folder):
    """Создаёт wav-файлы, если их ещё нет. Возвращает {имя: путь}."""
    os.makedirs(folder, exist_ok=True)
    stamp = os.path.join(folder, ".version")
    fresh = os.path.exists(stamp) and open(stamp).read() == VERSION
    paths = {}
    for name, (fn, rate, norm) in RECIPES.items():
        path = os.path.join(folder, name + ".wav")
        paths[name] = path
        if not fresh or not os.path.exists(path):
            _wav(path, fn(), rate, norm)
    with open(stamp, "w") as f:
        f.write(VERSION)
    return paths


class Sfx:
    """Проигрыватель: короткие звуки (с пулом экземпляров) и зацикленные фоновые дорожки."""

    def __init__(self, base, folder, vol=.7, music=.4, amb=.7, master=1.0):
        self.ok, self.snd, self.loops = False, {}, {}
        self.vol, self.music, self.amb, self.master = vol, music, amb, master
        try:
            from panda3d.core import Filename
            for name, path in generate(folder).items():
                fp = Filename.from_os_specific(path).get_fullpath()
                self.snd[name] = [base.loader.loadSfx(fp) for _ in range(3 if name in POOLED else 1)]
            self.ok = True
        except Exception as e:
            print("Звук недоступен:", e)

    def play(self, name, vol=1.0, rate=1.0):
        pool = self.snd.get(name)
        if not self.ok or not pool or vol <= 0.01:
            return
        try:
            playing = getattr(pool[0], "PLAYING", 2)
            s = next((x for x in pool if x.status() != playing), pool[0])
            s.setVolume(max(0.0, min(1.0, vol * self.vol * self.master)))
            s.setPlayRate(rate)
            s.play()
        except Exception:
            pass

    def loop(self, name, kind="sfx"):
        pool = self.snd.get(name)
        if not self.ok or not pool or name in self.loops:
            return
        try:
            pool[0].setLoop(True)
            pool[0].setVolume(0.0)
            pool[0].play()
            self.loops[name] = (pool[0], kind, 0.0)
        except Exception:
            pass

    def level(self, name, v):
        item = self.loops.get(name)
        if item is None:
            return
        s, kind, _ = item
        self.loops[name] = (s, kind, v)
        try:
            k = self.music if kind == "music" else (self.amb if kind == "amb" else self.vol)
            s.setVolume(max(0.0, min(1.0, v * k * self.master)))
        except Exception:
            pass

    def set_volumes(self, vol, music, amb=None, master=None):
        self.vol, self.music = vol, music
        if amb is not None:
            self.amb = amb
        if master is not None:
            self.master = master
        for name, (s, kind, v) in list(self.loops.items()):
            self.level(name, v)
