"""HOW TO HUNT - игровой сервер (мультиплеер) и все правила игры.
Отдельный запуск выделенного сервера:  python server.py
(при выборе «Играть» в клиенте сервер запускается автоматически)

Мир: плоскость X/Y в метрах (в 3D-клиенте Y сервера = Z движка), высота считается отдельно.
"""
import json
import math
import os
import random
import socket
import threading
import time

PORT = 5555
W, H = 480.0, 340.0                # размер каждой локации, метры
CAMP = (W / 2, H / 2)              # лагерь: магазин, продажа, путешествия
CAMP_R = 14.0                      # безопасная зона (стрелять нельзя)
EYE = 1.7                          # высота глаз охотника
TICK = 1 / 20
RESPEC_COST = 500
HIP_SPREAD = {"bow": .045, "rifle": .03, "shotgun": 0.0, "sniper": .09}   # стрельба «от бедра»; прицеливание (ПКМ) убирает
ADS_SPEED = .65                    # множитель скорости при прицеливании
CARCASS_TTL, CARCASS_LOCK, PICKUP_R = 180.0, 20.0, 3.8   # туша лежит 3 мин, 20 с принадлежит охотнику, радиус подбора
SAVE_FILE = os.path.join(os.path.expanduser("~"), ".how_to_hunt", "hunt_save.json")      # старое единственное сохранение
SLOTS_DIR = os.path.join(os.path.expanduser("~"), ".how_to_hunt", "saves")
SLOT_COUNT = 5

# r - радиус попадания (сфера), h - высота центра тела над землёй, flee - дистанция, с которой зверь убегает
ANIMALS = {
    "rabbit": dict(name="Кролик",  hp=1,  speed=9.0,  value=12,  xp=5,   r=0.7, h=0.25, flee=18),
    "deer":   dict(name="Олень",   hp=3,  speed=11.0, value=45,  xp=18,  r=1.2, h=0.9,  flee=30),
    "boar":   dict(name="Кабан",   hp=7,  speed=8.5,  value=90,  xp=35,  r=1.2, h=0.6,  flee=16),
    "fox":    dict(name="Песец",   hp=3,  speed=12.0, value=80,  xp=25,  r=0.8, h=0.35, flee=30),
    "wolf":   dict(name="Волк",    hp=10, speed=11.0, value=220, xp=70,  r=1.1, h=0.6,  flee=22),
    "bear":   dict(name="Медведь", hp=24, speed=7.0,  value=650, xp=200, r=1.8, h=0.95, flee=14),
    "redfox": dict(name="Лиса",    hp=3,  speed=12.0, value=70,  xp=22,  r=0.8, h=0.35, flee=32),
    "grouse": dict(name="Тетерев", hp=1,  speed=10.0, value=25,  xp=8,   r=0.6, h=0.3,  flee=24),
    "moose":  dict(name="Лось",    hp=14, speed=9.5,  value=170, xp=80,  r=1.7, h=1.4,  flee=28),
    "hare":   dict(name="Заяц-беляк", hp=1, speed=10.0, value=30, xp=8,  r=0.7, h=0.28, flee=24),
    "reindeer": dict(name="Северный олень", hp=5, speed=10.5, value=95, xp=32, r=1.3, h=1.0, flee=28),
    "musk":   dict(name="Овцебык", hp=18, speed=7.5,  value=260, xp=95,  r=1.6, h=0.9,  flee=14),
    "boss_boar": dict(name="Матёрый Секач", hp=140, speed=11.0, value=2200, xp=600, r=2.4, h=1.2, flee=0, boss=True),
    "boss_bear": dict(name="Медведь-шатун", hp=320, speed=8.5, value=4200, xp=1200, r=3.1, h=1.8, flee=0, boss=True),
    "boss_wolf": dict(name="Белый вожак", hp=220, speed=14.0, value=5200, xp=1600, r=2.2, h=1.2, flee=0, boss=True),
}
# характер: herd - держатся стадом (макс. размер), bold - смелость (меньше пугаются), zig - петляют при бегстве,
# turn - как быстро поворачивают (рад/с), graze - доля времени на кормёжку
AI = {
    "rabbit": dict(herd=0, bold=0.0, zig=1.0, turn=6.0, graze=.45),
    "hare":   dict(herd=0, bold=0.0, zig=1.0, turn=6.0, graze=.45),
    "grouse": dict(herd=3, bold=0.0, zig=.8, turn=5.0, graze=.5),
    "deer":   dict(herd=5, bold=0.0, zig=.25, turn=3.0, graze=.45),
    "reindeer": dict(herd=6, bold=.1, zig=.2, turn=2.8, graze=.45),
    "redfox": dict(herd=0, bold=.2, zig=.6, turn=4.5, graze=.25),
    "fox":    dict(herd=0, bold=.2, zig=.6, turn=4.5, graze=.25),
    "boar":   dict(herd=4, bold=.4, zig=.15, turn=2.5, graze=.55),
    "moose":  dict(herd=2, bold=.45, zig=.1, turn=2.0, graze=.5),
    "wolf":   dict(herd=4, bold=.5, zig=.2, turn=3.5, graze=.15),
    "musk":   dict(herd=5, bold=.6, zig=.05, turn=1.8, graze=.6),
    "bear":   dict(herd=0, bold=.8, zig=.05, turn=1.8, graze=.4),
}
ST_IDLE, ST_WALK, ST_GRAZE, ST_ALERT, ST_FLEE, ST_ATTACK = 0, 1, 2, 3, 4, 5
# враждебные звери: нападают сами, если охотник подошёл ближе aggro; provoke - шанс броситься на стрелка после ранения.
# Раненые сильнее порога flee убегают. pack - стая приходит на помощь.
HOSTILE = {
    "wolf":  dict(aggro=24, dmg=9, cd=1.1, reach=1.9, flee=.3, spd=1.0, pack=32, provoke=1.0),
    "bear":  dict(aggro=15, dmg=22, cd=1.7, reach=2.5, flee=.2, spd=.95, pack=0, provoke=1.0),
    "boar":  dict(aggro=7, dmg=9, cd=1.6, reach=1.9, flee=.35, spd=1.0, pack=14, provoke=1.0),
    "moose": dict(aggro=0, dmg=16, cd=1.8, reach=2.6, flee=.45, spd=.9, pack=0, provoke=.5),
}
GIANT_HP = 7                       # «крупные звери» для навыка «Убийца великанов»
RARE_VALUE = 200                   # «редкие трофеи» для навыка «Чутьё на редкое»

LOCS = {
    "forest": dict(name="Лес",    level=1, spawn={"rabbit": 90, "deer": 50, "boar": 20, "redfox": 24, "grouse": 40}),
    "thicket": dict(name="Чаща",  level=3, spawn={"deer": 28, "boar": 32, "moose": 16, "redfox": 30, "grouse": 48, "wolf": 14}),
    "tundra": dict(name="Тундра", level=6, spawn={"fox": 40, "wolf": 22, "bear": 9, "hare": 52, "reindeer": 26, "musk": 13}),
}
# ---------- боссы: у каждой локации свой ----------
BOSS_OF = {"forest": "boss_boar", "thicket": "boss_bear", "tundra": "boss_wolf"}
BOSSES = {
    "boss_boar": dict(speed=11.0, dmg=24, reach=2.8, aggro=32, cd=2.2, knock=3.0),
    "boss_bear": dict(speed=8.5, dmg=40, reach=3.3, aggro=28, cd=2.8, knock=2.2),
    "boss_wolf": dict(speed=14.0, dmg=17, reach=2.6, aggro=42, cd=1.3, knock=1.6),
}
BOSS_RESPAWN = 600.0
ARENA_R = 27.0                                  # радиус арены босса (стены по кругу, одни ворота)
# ---------- сюжет: главы и что нужно сделать (проверяет сервер, награда - деньги и опыт) ----------
STORY = [
    dict(title="Новый егерь", goal="Добудь и продай первую дичь, дорасти до 2 уровня", gold=150, xp=60),
    dict(title="Голос в эфире", goal="Купи боевой радар у Радиста Фёдора", gold=300, xp=150),
    dict(title="Тень в лесу", goal="Одолей Матёрого Секача на лесной арене", gold=800, xp=350),
    dict(title="Хозяин чащи", goal="Дорасти до 3 уровня, иди в Чащу и одолей Медведя-шатуна", gold=1500, xp=700),
    dict(title="Белое безмолвие", goal="Дорасти до 6 уровня, иди в Тундру и одолей Белого вожака", gold=3000, xp=1200),
]


def story_step_done(p, i):
    return (p.level >= 2, p.radar, "boss_boar" in p.bosses, "boss_bear" in p.bosses, "boss_wolf" in p.bosses)[i]


# ---------- золотые звери, жетоны и игровой автомат со скинами оружия ----------
GOLD_CHANCE, GOLD_MAX = .04, 3                 # шанс, что новый зверь золотой; не больше 3 золотых в локации одновременно
TOKENS_FOR = {"rabbit": 1, "hare": 1, "grouse": 1, "redfox": 1, "fox": 1, "deer": 2, "reindeer": 2, "boar": 2,
              "wolf": 2, "musk": 2, "moose": 3, "bear": 3}
SPIN_COST = 2                                  # жетонов за прокрутку автомата
SLOT_POS = (CAMP[0], CAMP[1] + 6.5)            # автомат стоит в лагере между палатками, лицом к костру
RARITY = {"common": ("Обычный", (196, 196, 196), 58), "rare": ("Редкий", (90, 160, 255), 28),
          "epic": ("Эпический", (186, 100, 255), 11), "legend": ("Легендарный", (255, 196, 50), 3)}
# скин: оружие, название, редкость, цвет дерева (ложа, лук), металла, акцент (полосы, наконечники)
SKINS = {
    "bow_birch": ("bow", "Берёзовый", "common", (226, 216, 192), (60, 58, 56), None),
    "bow_ash": ("bow", "Пепельный", "common", (92, 92, 98), (40, 40, 44), None),
    "bow_crimson": ("bow", "Багровый", "rare", (150, 30, 36), (60, 20, 22), (230, 190, 70)),
    "bow_aurora": ("bow", "Северное сияние", "epic", (40, 176, 150), (30, 60, 80), (176, 96, 255)),
    "bow_gold": ("bow", "Золотой", "legend", (240, 192, 52), (200, 150, 30), (255, 246, 210)),
    "rifle_camo": ("rifle", "Камуфляж", "common", (92, 104, 62), (62, 72, 52), None),
    "rifle_walnut": ("rifle", "Тёмный орех", "common", (76, 46, 28), (28, 28, 32), None),
    "rifle_frost": ("rifle", "Иней", "rare", (204, 222, 236), (120, 150, 182), (170, 222, 255)),
    "rifle_dragon": ("rifle", "Красный дракон", "epic", (44, 20, 20), (150, 26, 26), (255, 172, 40)),
    "rifle_gold": ("rifle", "Золотая", "legend", (240, 192, 52), (200, 150, 30), (255, 246, 210)),
    "shot_rust": ("shotgun", "Ржавчина", "common", (110, 70, 44), (130, 70, 40), None),
    "shot_hunter": ("shotgun", "Охотничий", "common", (130, 92, 50), (52, 56, 46), None),
    "shot_toxic": ("shotgun", "Токсик", "rare", (40, 46, 40), (70, 180, 60), (180, 255, 90)),
    "shot_neon": ("shotgun", "Неон", "epic", (30, 30, 46), (240, 70, 170), (60, 230, 255)),
    "shot_gold": ("shotgun", "Золотой", "legend", (240, 192, 52), (200, 150, 30), (255, 246, 210)),
    "sn_desert": ("sniper", "Пустыня", "common", (196, 170, 120), (150, 130, 96), None),
    "sn_night": ("sniper", "Ночь", "common", (30, 32, 40), (20, 22, 28), None),
    "sn_ice": ("sniper", "Лёд", "rare", (220, 236, 248), (150, 190, 220), (110, 200, 255)),
    "sn_space": ("sniper", "Космос", "epic", (40, 20, 70), (90, 40, 150), (120, 230, 255)),
    "sn_gold": ("sniper", "Золотая", "legend", (240, 192, 52), (200, 150, 30), (255, 246, 210)),
}


def roll_skin(rng=random):
    """Прокрутка автомата: сначала редкость (по весам), потом случайный скин этой редкости."""
    r = rng.uniform(0, sum(v[2] for v in RARITY.values()))
    for rar, (_, _, w) in RARITY.items():
        r -= w
        if r <= 0:
            break
    return rng.choice([k for k, v in SKINS.items() if v[2] == rar])


RADAR_PRICE = 500                               # цена боевого радара: он открывает ворота арен и показывает боссов
# чтобы попасть в следующую локацию, нужно победить босса предыдущей (и дорасти до её уровня)
BOSS_GATE = {"thicket": "boss_boar", "tundra": "boss_bear"}
MAX_HP = 100
LOOT = {"amulet": ("Старинный амулет", 260), "horn": ("Охотничий рог", 180), "knife": ("Нож мастера", 220),
        "map": ("Старая карта", 140), "fang": ("Оберег с клыком", 320), "coins": ("Мешочек старых монет", 200)}
CHEST_RESPAWN = 480.0
TIER = {"forest": 1, "thicket": 2, "tundra": 3}
# погода: (вид, вес) для каждой локации; меняется сама, одинакова для всех игроков локации
WEATHER = {
    "forest": (("clear", 5), ("cloudy", 3), ("fog", 2), ("rain", 3), ("storm", 1)),
    "thicket": (("clear", 3), ("cloudy", 3), ("fog", 4), ("rain", 3), ("storm", 1)),
    "tundra": (("clear", 3), ("cloudy", 3), ("snow", 4), ("blizzard", 1), ("fog", 1)),
}
WEATHER_FLEE = dict(clear=1.0, cloudy=1.0, fog=.8, rain=.85, storm=.7, snow=.9, blizzard=.65)   # в непогоду звери хуже вас замечают

WEAPONS = {
    "bow":     dict(name="Лук",       price=0,    level=1, dmg=1.0, cd=0.8, range=45,  pellets=1, spread=0.0),
    "rifle":   dict(name="Винтовка",  price=600,  level=2, dmg=3.0, cd=0.9, range=90,  pellets=1, spread=0.0),
    "shotgun": dict(name="Дробовик",  price=1800, level=4, dmg=2.0, cd=1.2, range=35,  pellets=6, spread=0.07),
    "sniper":  dict(name="Снайперка", price=6000, level=6, dmg=9.0, cd=1.6, range=170, pellets=1, spread=0.0),
}

# ---------------- дерево навыков ----------------
# per - величина одного ранга (показывается игроку), fmt - строка эффекта, req - нужные навыки (ранг >= 1)
BRANCHES = {"marksman": "СТРЕЛОК", "pathfinder": "СЛЕДОПЫТ", "trader": "ТОРГОВЕЦ"}
SKILLS = {
    "a1": dict(branch="marksman", name="Твёрдая рука", max=5, per=10, req=[],
               fmt="Урон +{}%"),
    "a2": dict(branch="marksman", name="Быстрые руки", max=3, per=7, req=["a1"],
               fmt="Перезарядка -{}%"),
    "a3": dict(branch="marksman", name="Меткость", max=3, per=8, req=["a1"],
               fmt="Зона попадания +{}%, разброс -{}%"),
    "a4": dict(branch="marksman", name="Критический выстрел", max=5, per=6, req=["a2"],
               fmt="Шанс крита +{}% (двойной урон)"),
    "a5": dict(branch="marksman", name="Убийца великанов", max=1, per=40, req=["a3", "a4"],
               fmt="+{}% урона по кабанам, волкам и медведям"),
    "b1": dict(branch="pathfinder", name="Лёгкая походка", max=5, per=6, req=[],
               fmt="Скорость ходьбы +{}%"),
    "b2": dict(branch="pathfinder", name="Вместительная сумка", max=5, per=3, req=["b1"],
               fmt="+{} места в сумке"),
    "b3": dict(branch="pathfinder", name="Тихий шаг", max=3, per=8, req=["b1"],
               fmt="Звери замечают вас на {}% ближе"),
    "b4": dict(branch="pathfinder", name="Спринтер", max=3, per=10, req=["b2"],
               fmt="Скорость бега (Shift) +{}%"),
    "b5": dict(branch="pathfinder", name="Опытный следопыт", max=1, per=25, req=["b3", "b4"],
               fmt="Опыт за добычу +{}%"),
    "c1": dict(branch="trader", name="Торг", max=5, per=8, req=[],
               fmt="Цена продажи +{}%"),
    "c2": dict(branch="trader", name="Скидка оружейника", max=3, per=6, req=["c1"],
               fmt="Оружие дешевле на {}%"),
    "c3": dict(branch="trader", name="Чутьё на редкое", max=3, per=12, req=["c1"],
               fmt="Редкие трофеи (от $200) дороже на {}%"),
    "c4": dict(branch="trader", name="Магнат", max=1, per=20, req=["c2", "c3"],
               fmt="Вся добыча дороже на {}%"),
}


# ---------------- лагерь: палатки с NPC ----------------
TENT_W, TENT_D, TENT_H, TENT_R, TENT_FREE = 4.4, 4.6, 3.2, 10.0, 1.35
TENT_ANGLES = (0.5, 2.6, 4.4, 5.75)
NPC_DEFS = (dict(id="trader", name="Торговец Макар", role="Лавка"),
            dict(id="master", name="Охотовед Тамара", role="Заказы на охоту"),
            dict(id="tracker", name="Следопыт Игнат", role="Навыки, обучение, советы"),
            dict(id="radio", name="Радист Фёдор", role="Боевой радар"))
TALK_R = 3.4                       # на каком расстоянии с NPC можно говорить
QUEST_NEED = dict(rabbit=(4, 8), deer=(2, 4), boar=(1, 3), fox=(2, 4), wolf=(1, 3), bear=(1, 1), redfox=(2, 4), grouse=(3, 6),
                  moose=(1, 2), hare=(3, 6), reindeer=(2, 3), musk=(1, 1))


def tent_world(t, lx, lz):
    """Локальные координаты палатки (lx - вправо, lz - вперёд, к входу) -> мировые (x, y)."""
    th = math.radians(t["yaw"])
    return t["x"] + lx * math.cos(th) + lz * math.sin(th), t["y"] - lx * math.sin(th) + lz * math.cos(th)


TENTS = []
NPCS = {}
for _i, _d in enumerate(NPC_DEFS):
    _a = TENT_ANGLES[_i]
    _t = dict(x=CAMP[0] + TENT_R * math.cos(_a), y=CAMP[1] + TENT_R * math.sin(_a),
              yaw=math.degrees(math.atan2(-math.cos(_a), -math.sin(_a))), npc=_d["id"])      # вход смотрит на костёр
    TENTS.append(_t)
    _nx, _ny = tent_world(_t, 0, -TENT_D / 2 + 1.25)
    NPCS[_d["id"]] = dict(_d, x=_nx, y=_ny, yaw=_t["yaw"], tent=_i)


def _in_boxes(boxes, x, y):
    for cx, cy, hw, hd, th in boxes:
        dx, dy = x - cx, y - cy
        if abs(dx) > hw + hd or abs(dy) > hw + hd:
            continue
        c, s_ = math.cos(th), math.sin(th)
        if abs(dx * c - dy * s_) < hw and abs(dx * s_ + dy * c) < hd:
            return True
    return False


def blocked(x, y, loc=None, key=True):
    """Твёрдые объекты: костровище, NPC, стенки палаток (вход открыт), стены построек и арен, камни локации.
    key - есть ли у игрока боевой радар: без него ворота арены боссов закрыты силовым барьером."""
    if loc is not None:
        L = LAYOUTS.get(loc, {})
        if _in_boxes(L.get("solids", ()), x, y):
            return True
        if not key and _in_boxes(L.get("gates", ()), x, y):
            return True
    if math.hypot(x - SLOT_POS[0], y - SLOT_POS[1]) < .95:
        return True
    if math.hypot(x - CAMP[0], y - CAMP[1]) < 1.8:
        return True
    for n in NPCS.values():
        if math.hypot(x - n["x"], y - n["y"]) < 1.0:
            return True
    for t in TENTS:
        th = math.radians(t["yaw"])
        c, s = math.cos(th), math.sin(th)
        dx, dy = x - t["x"], y - t["y"]
        lx, lz = dx * c - dy * s, dx * s + dy * c
        if abs(lz) < TENT_D / 2 + .2 and TENT_FREE < abs(lx) < TENT_W / 2 + .5:
            return True
        if abs(lx) <= TENT_W / 2 + .5 and -TENT_D / 2 - .5 < lz < -TENT_D / 2 + .35:
            return True
    return False


def move(x, y, dx, dy, loc=None, key=True):
    """Сдвиг с учётом твёрдых объектов (скольжение вдоль стенок). Используют и сервер, и клиент."""
    if blocked(x, y, loc, key):                    # уже внутри препятствия - выпускаем
        return x + dx, y + dy
    if not blocked(x + dx, y + dy, loc, key):
        return x + dx, y + dy
    if not blocked(x + dx, y, loc, key):
        return x + dx, y
    if not blocked(x, y + dy, loc, key):
        return x, y + dy
    return x, y


def camp_spawn():
    for _ in range(30):
        a, r = random.uniform(0, 6.283), random.uniform(3.2, 5.0)
        x, y = CAMP[0] + r * math.cos(a), CAMP[1] + r * math.sin(a)
        if not blocked(x, y):
            return x, y
    return CAMP[0] + 4, CAMP[1] + 4


# ---------------- случайная карта: постройки с сундуками и логово босса ----------------
WOOD, WOOD_D, ROOF, STONE, MOSSY = (122, 88, 54), (88, 62, 40), (108, 62, 48), (132, 130, 126), (98, 114, 88)
METAL, RUST, CLOTH, BONE, ICE, DARK = (124, 132, 142), (142, 84, 52), (152, 124, 84), (232, 226, 210), (172, 216, 240), (24, 22, 22)
# детали построек: (форма, x, y, z, ширина, высота, глубина, цвет, твёрдая, поворот) в метрах относительно центра,
# вход смотрит в сторону +z. Сервер берёт твёрдые детали для столкновений, клиент - всё для отрисовки.


def _hut(wall, roof, floor):
    return [("cube", 0, .05, 0, 5, .1, 4, floor, 0, None),
            ("cube", 0, 1.3, -2, 5, 2.6, .2, wall, 1, None), ("cube", -2.5, 1.3, 0, .2, 2.6, 4, wall, 1, None),
            ("cube", 2.5, 1.3, 0, .2, 2.6, 4, wall, 1, None), ("cube", -1.55, 1.3, 2, 1.9, 2.6, .2, wall, 1, None),
            ("cube", 1.55, 1.3, 2, 1.9, 2.6, .2, wall, 1, None), ("cube", 0, 2.4, 2, 1.2, .4, .2, wall, 0, None),
            ("cube", 0, 3.05, -1.15, 5.8, .14, 2.75, roof, 0, (-32, 0, 0)), ("cube", 0, 3.05, 1.15, 5.8, .14, 2.75, roof, 0, (32, 0, 0)),
            ("cube", -1.4, .45, -1.3, 1.2, .9, .7, WOOD_D, 0, None)]


BLUEPRINTS = {
    "hut": dict(name="Заброшенная хижина", chest=(1.4, -1.1), r=4.5, parts=_hut(WOOD, ROOF, WOOD_D)),
    "tower": dict(name="Охотничья вышка", chest=(0, 0), r=3.0, parts=[
        *[("cube", sx * 1.1, 1.9, sz * 1.1, .22, 3.8, .22, WOOD_D, 1, None) for sx in (-1, 1) for sz in (-1, 1)],
        ("cube", 0, 3.85, 0, 2.7, .15, 2.7, WOOD, 0, None),
        ("cube", 0, 4.35, 1.3, 2.7, .08, .08, WOOD, 0, None), ("cube", 0, 4.35, -1.3, 2.7, .08, .08, WOOD, 0, None),
        ("cube", 1.3, 4.35, 0, .08, .08, 2.7, WOOD, 0, None), ("cube", -1.3, 4.35, 0, .08, .08, 2.7, WOOD, 0, None),
        *[("cube", sx * 1.2, 4.65, sz * 1.2, .1, 1.5, .1, WOOD_D, 0, None) for sx in (-1, 1) for sz in (-1, 1)],
        ("cube", 0, 5.45, 0, 3.0, .12, 3.0, ROOF, 0, None),
        ("cube", -.3, 1.9, 1.45, .07, 3.8, .07, WOOD, 0, None), ("cube", .3, 1.9, 1.45, .07, 3.8, .07, WOOD, 0, None),
        *[("cube", 0, .5 + i * .55, 1.45, .6, .05, .05, WOOD, 0, None) for i in range(6)]]),
    "stones": dict(name="Каменный круг", chest=(0, 1.4), r=5.5, parts=[
        *[("rock%d" % (i % 3), 4.4 * math.cos(i * .698), 1.1, 4.4 * math.sin(i * .698), 1.0, 2.4, .8, STONE, 1, (0, -math.degrees(i * .698), 0))
          for i in range(9)],
        ("cube", 0, .35, 0, 1.6, .7, 1.0, STONE, 1, None)]),
    "cart": dict(name="Брошенная телега", chest=(1.9, -.6), r=3.0, parts=[
        ("cube", 0, .9, 0, 1.4, .5, 2.6, WOOD, 1, None), ("cube", .7, 1.25, 0, .08, .3, 2.6, WOOD_D, 0, None),
        ("cube", -.7, 1.25, 0, .08, .3, 2.6, WOOD_D, 0, None),
        *[("cube", sx * .8, .45, sz * 1.0, .12, .9, .9, WOOD_D, 0, None) for sx in (-1, 1) for sz in (-1, 1)],
        ("cube", 0, .7, 2.2, .1, .1, 2.2, WOOD, 0, None), ("cube", .1, 1.45, -.4, .7, .6, .7, WOOD_D, 0, (0, 20, 0)),
        ("cube", -1.6, .1, 1.0, .9, .12, .9, WOOD_D, 0, (0, 30, 80))]),
    "ruin": dict(name="Руины часовни", chest=(1.2, -2.0), r=4.5, parts=[
        ("cube", 0, 1.8, -3, 6, 3.6, .5, MOSSY, 1, None), ("cube", -3, 1.2, -.5, .5, 2.4, 5, STONE, 1, None),
        ("cube", 3, .7, -1.5, .5, 1.4, 3, MOSSY, 1, None), ("cube", -2, 1.6, 2.4, .55, 3.2, .55, STONE, 1, None),
        ("cube", 2, 1.1, 2.4, .55, 2.2, .55, MOSSY, 1, None), ("cube", -.9, 3.3, 2.4, 2.8, .45, .55, STONE, 0, None),
        ("rock0", 2.4, .4, 3.6, 1.2, .8, 1.0, STONE, 0, None), ("rock1", -.6, .3, -1.0, .9, .6, .8, MOSSY, 0, None)]),
    "poacher": dict(name="Лагерь браконьеров", chest=(0, -1.2), r=4.5, parts=[
        ("cube", -2.4, .75, -.8, 2.2, 2.2, 3, CLOTH, 1, (0, 0, 45)), ("cube", 2.4, .75, -.8, 2.2, 2.2, 3, (110, 104, 74), 1, (0, 0, 45)),
        ("cube", 2.4, .4, 2.4, .8, .8, .8, WOOD, 1, None), ("cube", 3.2, .3, 2.0, .6, .6, .6, WOOD_D, 0, (0, 25, 0)),
        *[("rock%d" % (i % 3), 1.0 * math.cos(i * 1.257), .15, 1.6 + 1.0 * math.sin(i * 1.257), .4, .3, .4, STONE, 0, None) for i in range(5)],
        ("cube", -3.2, 1.2, 2.2, .1, 2.4, .1, WOOD_D, 0, None), ("cube", -1.6, 1.2, 2.2, .1, 2.4, .1, WOOD_D, 0, None),
        ("cube", -2.4, 2.3, 2.2, 1.8, .08, .08, WOOD_D, 0, None), ("cube", -2.4, 1.6, 2.2, 1.2, 1.2, .04, (130, 96, 64), 0, None)]),
    "station": dict(name="Заброшенная метеостанция", chest=(1.0, -.8), r=4.5, parts=[
        *_hut(METAL, RUST, (90, 90, 96))[:7], ("cube", 0, 2.7, 0, 5.3, .15, 4.3, RUST, 0, None),
        ("cube", 3.2, 4.5, -1.2, .14, 9, .14, METAL, 1, None), ("cube", 3.2, 7.5, -1.2, 1.6, .08, .08, METAL, 0, None),
        ("cube", 3.2, 8.6, -1.2, .08, .08, 1.2, METAL, 0, None), ("cube", -3.3, .55, 1.2, .7, 1.1, .7, RUST, 1, None),
        ("cube", -3.3, .55, 2.1, .7, 1.1, .7, (90, 110, 70), 0, None)]),
    "wreck": dict(name="Обломки самолёта", chest=(-2.4, 1.0), r=5.0, parts=[
        ("cube", 0, 1.0, 0, 2.0, 1.8, 7, METAL, 1, (0, 0, 8)), ("sphere", 0, 1.1, 3.8, 1.8, 1.6, 2.0, METAL, 1, None),
        ("cube", 2.8, .4, .3, 5, .15, 1.6, METAL, 0, (0, 10, -12)), ("cube", -3.6, .15, -1.5, 3, .12, 1.4, METAL, 0, (0, -35, 5)),
        ("cube", 0, 2.4, -3.3, .15, 1.6, 1.2, (180, 60, 50), 0, None), ("cube", 0, 1.8, -3.4, 2.4, .1, .8, METAL, 0, None),
        ("cube", 1.4, .2, -4.6, .8, .3, .6, METAL, 0, (20, 40, 10)), ("cube", -1.8, .15, 4.6, .6, .3, .9, DARK, 0, (0, 60, 0))]),
    "sled": dict(name="Брошенные сани", chest=(1.5, .9), r=3.0, parts=[
        ("cube", 0, .55, 0, 1.4, .3, 3, WOOD, 1, None), ("cube", .62, .15, 0, .08, .12, 3.4, METAL, 0, None),
        ("cube", -.62, .15, 0, .08, .12, 3.4, METAL, 0, None), ("cube", 0, .95, -.6, 1.2, .5, 1.2, WOOD_D, 0, None),
        ("cube", 0, .85, .8, 1.3, .3, 1.0, (210, 205, 195), 0, None), ("sphere", .2, .4, -2.6, 1.6, .7, 1.4, (246, 250, 255), 0, None)]),
    "lair_forest": dict(name="Логово Секача", chest=None, r=10.0, parts=[
        ("sphere", 0, .02, 0, 16, .1, 12, (74, 56, 38), 0, None), ("sphere", 2, .03, 1, 7, .12, 5, (56, 42, 30), 0, None),
        *[("cube", 7 * math.cos(a), .4, 6 * math.sin(a), 4.5, .55, .55, WOOD_D, 1, (0, -math.degrees(a) + 70, 8)) for a in (.4, 2.1, 3.9, 5.2)],
        *[("cube", 3 * math.cos(a), .06, 3 * math.sin(a), .5, .1, .12, BONE, 0, (0, a * 50, 0)) for a in (.5, 1.7, 2.9, 4.4, 5.6)],
        ("rock2", -6, .6, -4, 2.5, 1.6, 2, STONE, 1, None)]),
    "lair_thicket": dict(name="Берлога Шатуна", chest=None, r=10.0, parts=[
        *[("rock%d" % (i % 3), 8 * math.cos(a), 2.0, 8 * math.sin(a), 5.0, 5.6, 4.0, MOSSY, 1, (0, -math.degrees(a), 0))
          for i, a in enumerate((3.4, 3.9, 4.4, 4.9, 5.4, 5.9))],
        ("cube", 0, 1.7, -7.2, 3.4, 3.4, .3, DARK, 0, None), ("sphere", 0, .02, -2, 12, .1, 10, (60, 50, 38), 0, None),
        *[("cube", 2.5 * math.cos(a), .06, -2 + 2.5 * math.sin(a), .55, .1, .12, BONE, 0, (0, a * 50, 0)) for a in (.5, 1.7, 2.9, 4.4)]]),
    "lair_tundra": dict(name="Логово Белого вожака", chest=None, r=10.0, parts=[
        *[("cone", 8 * math.cos(a), 0, 8 * math.sin(a), 1.6, 4 + (i % 3) * 1.5, 1.6, ICE, 1, (8 * math.sin(i), 0, 8 * math.cos(i)))
          for i, a in enumerate([j * .785 for j in range(8)])],
        *[("cube", 3 * math.cos(a), .06, 3 * math.sin(a), .55, .1, .12, BONE, 0, (0, a * 50, 0)) for a in (.3, 1.5, 2.6, 3.9, 5.1)],
        ("sphere", 0, .02, 0, 14, .12, 14, (236, 242, 250), 0, None)]),
}
# ---------------- интерьер построек: мебель и вещи внутри (все детали в метрах относительно центра постройки) ----------------
RED, WHITE, GREEN, BLACK, PAPER, FLAME = (150, 52, 44), (232, 228, 218), (70, 110, 70), (32, 30, 30), (222, 208, 170), (255, 190, 90)
LEATHER, STEEL, SCREEN, GLASSC = (110, 76, 50), (92, 98, 108), (80, 200, 150), (150, 196, 214)


def _legs(cx, y, cz, w, d, h, col, t=.08):
    """Четыре ножки стола под столешницей (вкопаны в пол, чтобы не было совпадающих плоскостей)."""
    return [("cube", cx + sx * (w / 2 - t), y, cz + sz * (d / 2 - t), t, h, t, col, 0, None) for sx in (-1, 1) for sz in (-1, 1)]


def _candle(x, y, z):
    return [("cube", x, y, z, .05, .2, .05, PAPER, 0, None), ("sphere_lo", x, y + .14, z, .06, .1, .06, FLAME, 0, None)]


def _in_hut():
    p = []
    # кровать у левой стены: рама, матрас (вдавлен в раму), одеяло, подушка
    p += [("cube", -1.75, .3, -.9, 1.3, .4, 2.1, WOOD_D, 1, None), ("cube", -1.75, .55, -.9, 1.18, .2, 1.95, (214, 206, 184), 0, None),
          ("cube", -1.75, .62, -.45, 1.22, .1, 1.2, RED, 0, None), ("cube", -1.75, .66, -1.72, .8, .14, .4, WHITE, 0, None)]
    # стол с посудой и свечой, табурет
    p += [("cube", 1.5, .83, .75, 1.4, .08, .9, WOOD, 1, None)] + _legs(1.5, .45, .75, 1.4, .9, .75, WOOD_D)
    p += [("cube", 1.25, .89, .75, .3, .04, .3, WHITE, 0, None), ("cube", 1.8, .93, .95, .12, .14, .12, LEATHER, 0, None)] + _candle(1.55, 1.0, .5)
    p += [("cube", 1.5, .3, 1.55, .4, .4, .4, WOOD_D, 0, None)]
    # печка с трубой и поленница
    p += [("cube", -.15, .6, -1.55, .8, 1.0, .6, (50, 48, 52), 1, None), ("cube", -.15, 2.3, -1.6, .16, 2.0, .16, (60, 58, 62), 0, None),
          ("cube", -.15, .5, -1.24, .3, .24, .04, FLAME, 0, None), ("cube", .6, .3, -1.72, .5, .4, .4, (96, 66, 42), 0, None)]
    # полка со склянками, ковёр, фонарь под потолком, рога на стене
    p += [("cube", 1.4, 1.7, -1.85, 1.6, .06, .3, WOOD, 0, None), ("cube", 1.0, 1.85, -1.85, .14, .2, .14, (120, 170, 120), 0, None),
          ("cube", 1.4, 1.83, -1.85, .16, .16, .16, (190, 150, 70), 0, None), ("cube", 1.8, 1.86, -1.85, .3, .22, .12, (120, 60, 50), 0, None)]
    p += [("cube", 0, .11, .4, 2.0, .04, 1.4, (130, 50, 45), 0, None), ("cube", 0, 2.35, -.3, .04, .5, .04, (60, 58, 62), 0, None),
          ("cube", 0, 2.05, -.3, .16, .2, .16, FLAME, 0, None)]
    p += [("sphere_lo", -.75, 1.85, -1.86, .3, .24, .2, BONE, 0, None), ("cube", -.95, 2.0, -1.86, .04, .3, .04, BONE, 0, (0, 0, 28)),
          ("cube", -.55, 2.0, -1.86, .04, .3, .04, BONE, 0, (0, 0, -28))]
    return p


def _in_tower():
    return [("cube", -.75, 4.1, -.75, .6, .5, .6, WOOD_D, 0, None), ("cube", .55, 3.97, -.55, .8, .1, 1.6, GREEN, 0, None),
            ("cube", -.2, 4.0, .95, .04, 1.0, .04, (60, 58, 62), 0, (12, 0, 0)), ("cube", -.2, 4.5, .9, .08, .08, .3, STEEL, 0, None)] + _candle(.9, 4.0, .9)


def _in_stones():
    p = [("sphere_lo", 0, .78, 0, .5, .2, .5, (90, 70, 50), 0, None), ("sphere_lo", 0, .86, 0, .3, .1, .3, FLAME, 0, None)]
    p += _candle(-.55, .85, 0) + _candle(.55, .85, 0)
    p += [("sphere_lo", 1.2, .05, 1.3, .3, .1, .2, BONE, 0, None), ("sphere_lo", -1.4, .05, 1.1, .25, .1, .2, BONE, 0, None),
          ("cube", 1.9, .06, -.8, .5, .12, .08, BONE, 0, (0, 40, 0))]
    return p


def _in_cart():
    p = [("cube", -.2, 1.45, .3, .5, .5, .5, (190, 170, 120), 0, (0, 25, 0)), ("cube", .25, 1.4, -.5, .45, .4, .45, (176, 156, 108), 0, (0, -10, 0))]
    p += [("cube", 2.6, .45, 1.0, .6, .8, .6, WOOD, 0, None), ("cube", 2.6, .45, 1.0, .64, .06, .64, (50, 46, 42), 0, None),
          ("cube", 2.6, .75, 1.0, .64, .06, .64, (50, 46, 42), 0, None), ("cube", 3.3, .3, -.2, .5, .5, .5, WOOD_D, 0, (0, 20, 0))]
    p += [("cube", 1.2, .08, 2.8, 1.4, .05, .05, (170, 150, 100), 0, (0, 30, 0)), ("sphere_lo", -1.5, .25, -1.5, .6, .5, .5, (190, 170, 120), 0, None)]
    return p


def _in_ruin():
    p = [("cube", 0, .04, -.3, 5.2, .08, 5.0, (118, 116, 112), 0, None)]                # остатки плиточного пола
    p += [("cube", -.8, .45, -1.9, 1.8, .8, .7, STONE, 1, None), ("cube", -.8, 1.05, -1.9, 1.5, .08, .55, (150, 148, 142), 0, None)]
    p += _candle(-1.3, 1.2, -1.9) + _candle(-.3, 1.2, -1.9)
    p += [("cube", 1.5, .3, .6, 3.0, .3, .3, WOOD_D, 0, (0, 35, 8)), ("cube", -2.4, .3, 1.4, 1.6, .25, .25, WOOD_D, 0, (0, -20, 5))]
    p += [("rock1", 2.0, .25, 1.8, .8, .5, .6, MOSSY, 0, None), ("rock2", -2.2, .2, -.5, .6, .4, .5, STONE, 0, None),
          ("sphere_lo", 0.2, .1, .8, .3, .2, .25, BONE, 0, None), ("cube", .6, .05, .9, .5, .1, .08, BONE, 0, (0, 20, 0))]
    p += [("cube", 2.2, .5, -1.6, .5, .9, .5, (160, 158, 150), 0, (0, 20, 0)), ("sphere_lo", 2.2, 1.1, -1.6, .35, .35, .35, (160, 158, 150), 0, None)]   # обломок статуи
    return p


def _in_poacher():
    p = [("cone", 0, .55, 1.6, .5, .9, .5, FLAME, 0, None), ("sphere_lo", 0, .95, 1.6, .5, .38, .5, BLACK, 0, None)]
    p += [("cube", .9 * math.cos(a), .5, 1.6 + .9 * math.sin(a), .04, 1.1, .04, WOOD_D, 0, (math.degrees(math.sin(a)) * -.4, 0, math.degrees(math.cos(a)) * .4))
          for a in (0.4, 2.5, 4.6)]
    p += [("cube", -1.2, .3, 2.6, 1.2, .3, .35, WOOD, 0, (0, 20, 0)), ("cube", 1.3, .3, 3.0, 1.2, .3, .35, WOOD, 0, (0, -25, 0))]            # брёвна-лавки
    p += [("cube", -2.4, .09, .7, .8, .12, 1.6, GREEN, 0, None), ("cube", 2.4, .09, .7, .8, .12, 1.6, (150, 90, 50), 0, None)]            # спальники
    p += [("cube", -2.4, .08, -.3, .05, .05, .05, BLACK, 0, None)] + [("sphere_lo", -2.4, 1.0, .1, .2, .2, .2, FLAME, 0, None)]
    p += [("cube", 3.2, .8, 2.0, .6, .6, .6, WOOD, 0, None), ("cube", 3.2, 1.4, 2.0, .55, .5, .55, WOOD_D, 0, (0, 15, 0))]
    p += [("cube", 1.0, .06, -1.8, 1.2, .05, .9, (170, 140, 100), 0, (0, 25, 0)), ("cube", -1.0, .06, -2.2, 1.0, .05, .8, (140, 120, 90), 0, (0, -30, 0))]   # шкуры
    p += [("cube", 3.8, .65, -.6, .06, 1.3, .06, (60, 58, 62), 0, (0, 0, 12)), ("cube", 3.8, 1.3, -.6, .06, .06, .5, STEEL, 0, None)]       # прислонённое ружьё
    return p


def _in_station():
    p = []
    p += [("cube", -1.5, 1.0, -1.5, 1.8, .08, .8, WOOD, 1, None)] + _legs(-1.5, .55, -1.5, 1.8, .8, .9, STEEL)
    p += [("cube", -1.95, 1.3, -1.7, .55, .38, .06, (30, 34, 38), 0, None), ("cube", -1.95, 1.3, -1.67, .46, .3, .02, SCREEN, 0, None),
          ("cube", -1.9, 1.06, -1.35, .5, .03, .16, (50, 54, 58), 0, None), ("cube", -1.0, 1.15, -1.7, .35, .2, .25, (150, 120, 60), 0, None)]
    p += [("cube", -2.25, 1.1, .4, .5, 2.0, .9, STEEL, 1, None)] + [("cube", -2.0, 1.0 + i * .35, .4, .04, .22, .7, (30 + 40 * (i % 2), 34, 38), 0, None) for i in range(4)]
    p += [("sphere_lo", -2.0, 1.7, .4, .1, .1, .1, (230, 70, 50), 0, None), ("sphere_lo", -2.0, 1.5, .55, .08, .08, .08, (90, 230, 90), 0, None)]
    p += [("cube", 1.95, .5, 1.0, 1.2, .1, 2.0, STEEL, 1, None), ("cube", 1.95, 1.2, 1.0, 1.2, .1, 2.0, STEEL, 0, None), ("cube", 1.95, .65, 1.0, 1.1, .16, 1.9, (90, 100, 70), 0, None),
          ("cube", 1.95, 1.35, 1.0, 1.1, .16, 1.9, (100, 90, 70), 0, None)] + [("cube", 1.45 + sx * 1.0, .75, 1.0 + sz * .9, .06, 1.5, .06, STEEL, 0, None) for sx in (0, 1) for sz in (-1, 1)]
    p += [("cube", 0, 1.75, -1.9, 1.6, .9, .03, PAPER, 0, None), ("cube", -.4, 1.8, -1.88, .1, .1, .02, RED, 0, None), ("cube", .3, 1.65, -1.88, .1, .1, .02, RED, 0, None),
          ("cube", 1.4, 1.2, -1.9, .3, .3, .06, STEEL, 0, None), ("sphere_lo", 1.4, 1.2, -1.86, .22, .22, .04, (230, 230, 220), 0, None)]
    p += [("cube", -.1, .15, .3, .5, .08, .5, (60, 50, 40), 0, None), ("cube", .6, .3, -1.6, .5, .5, .5, (140, 100, 50), 0, None)]
    return p


def _in_wreck():
    p = []
    for i, (x, z, c) in enumerate(((3.6, 2.8, (60, 70, 110)), (4.4, 2.0, (60, 70, 110)), (-4.2, -3.4, (70, 70, 74)), (2.2, -4.6, (60, 70, 110)))):
        p += [("cube", x, .4, z, .6, .5, .6, c, 0, (0, 30 * i, 0)), ("cube", x, .85, z - .22, .6, .6, .1, c, 0, (0, 30 * i, 0))]               # выброшенные кресла
    p += [("cube", -3.4, .3, 3.4, .7, .5, .45, (150, 60, 50), 0, (0, 25, 0)), ("cube", -3.9, .25, 2.7, .6, .4, .4, (60, 90, 120), 0, (0, -20, 0)),
          ("cube", 4.6, .2, -1.0, .8, .35, .5, (90, 70, 50), 0, (0, 70, 0)), ("cube", 4.8, .15, -1.7, .5, .28, .38, (180, 160, 90), 0, (0, 10, 0))]   # чемоданы
    p += [("cube", -1.2, .04, -5.2, 3.2, .04, 2.2, (232, 120, 40), 0, (0, 20, 0)), ("cube", -3.0, .05, 4.8, 1.0, .1, .8, (220, 40, 40), 0, None),
          ("cube", -3.0, .11, 4.8, .5, .03, .12, WHITE, 0, None)]                                                                              # купол парашюта, аптечка
    p += [("cube", .5, .05, 5.6, 2.0, .04, .04, (30, 30, 34), 0, (0, 35, 0)), ("cube", 1.4, .12, 6.0, .3, .2, .2, (60, 60, 64), 0, None)]
    return p


def _in_sled():
    return [("cube", -.2, 1.15, -.8, .55, .45, .5, (190, 170, 120), 0, (0, 20, 0)), ("cube", .3, 1.1, .1, .5, .35, .45, (120, 90, 60), 0, (0, -15, 0)),
            ("cube", 1.7, .55, -.5, .06, 1.1, .06, (90, 70, 50), 0, (0, 0, 15)), ("cube", 1.76, 1.1, -.5, .22, .06, .06, STEEL, 0, None),
            ("cube", 1.2, .05, 1.6, 1.4, .04, .04, (170, 150, 100), 0, (0, 40, 0)), ("sphere_lo", -1.4, .25, 1.4, .5, .4, .4, (246, 250, 255), 0, None)]


def _in_lair(kind):
    if kind == "lair_forest":
        return [("sphere_lo", 4.0, .15, 2.0, .35, .25, .3, BONE, 0, None), ("cube", 4.6, .08, 2.6, .8, .08, .08, BONE, 0, (0, 40, 0)),
                ("cube", -3, .5, 3, .5, .8, .35, (92, 70, 48), 0, (0, 30, 12)), ("sphere_lo", -3, .9, 3, .35, .3, .3, (150, 60, 50), 0, None)]
    if kind == "lair_thicket":
        return [("sphere_lo", 3.0, .15, -1.0, .45, .3, .35, BONE, 0, None), ("cube", 3.5, .1, -1.6, 1.0, .1, .1, BONE, 0, (0, 30, 0)),
                ("sphere_lo", -2.0, .2, -3.0, 2.2, .35, 1.6, (70, 52, 38), 0, None), ("cube", -4.0, .05, -.5, .8, .06, .8, (110, 100, 90), 0, (0, 15, 0))]
    return [("sphere_lo", 3.0, .2, 2.0, .5, .35, .4, BONE, 0, None), ("cube", 2.4, .1, 1.5, 1.0, .1, .1, BONE, 0, (0, 70, 0)),
            ("cube", -3.4, .4, -2.4, 1.4, .7, .6, (210, 214, 222), 0, (0, 20, 0)), ("cone", -3.4, 1.0, -2.4, .5, .7, .5, ICE, 0, None)]


# ---------------- арены боссов: круглая стена, одни ворота (закрыты барьером без радара), укрытия внутри ----------------
ARENA_STYLE = {   # стена, верх стены, пол, внутренний круг, цвет барьера
    "forest": ((126, 120, 108), (98, 114, 88), (92, 76, 54), (118, 98, 68)),
    "thicket": ((72, 86, 68), (52, 70, 52), (48, 54, 40), (66, 54, 42)),
    "tundra": ((176, 192, 212), (236, 242, 250), (226, 232, 242), (176, 206, 230)),
}
ARENA_TITLE = {"forest": "Арена Секача", "thicket": "Арена Шатуна", "tundra": "Арена Белого вожака"}
GATE_COLOR = (230, 60, 60)
PILLARS = ((15, 14, 4.2), (55, 10, 3.4), (150, 12, 4.6), (195, 9, 3.0), (235, 14, 4.0), (290, 11, 3.6), (335, 13, 4.4))


def _arena_parts(loc):
    """Детали арены в локальных координатах (ворота в сторону +z). solid=1 - твёрдая стена, solid=2 - барьер ворот."""
    R, N = ARENA_R, 22
    wall, cap, floor, ring = ARENA_STYLE[loc]
    parts = [("sphere", 0, .02, 0, 2 * R - 1, .1, 2 * R - 1, floor, 0, None),             # пол арены (две «наклейки» на земле)
             ("sphere", 0, .02, 0, 2 * R * .42, .12, 2 * R * .42, ring, 0, None)]
    ga = math.pi / 2                                                                      # направление на ворота (+z)
    L = 2 * R * math.sin(math.pi / N) * 1.04
    for i in range(1, N):                                                                 # i = 0 - место ворот
        a = ga + 2 * math.pi * i / N
        x, z = R * math.cos(a), R * math.sin(a)
        rot = -math.degrees(a) - 90
        parts.append(("cube", x, 2.25, z, L, 4.5, 1.4, wall, 1, (0, rot, 0)))
        parts.append(("cube", x, 4.62, z, L * .96, .26, 1.6, cap, 0, (0, rot, 0)))        # верхняя кромка
        if i % 2 == 0:                                                                    # факелы на внутренней стороне стены
            tx, tz = (R - 1.1) * math.cos(a), (R - 1.1) * math.sin(a)
            parts += [("cube", tx, 1.5, tz, .14, 3.0, .14, WOOD_D, 0, None), ("sphere_lo", tx, 3.15, tz, .4, .5, .4, FLAME, 0, None)]
    for sx in (-1, 1):                                                                    # ворота: два столба, перекладина, знамёна
        gx = sx * (L / 2 + .9)
        parts += [("cube", gx, 3.3, R, 1.9, 6.6, 1.9, wall, 1, None), ("cube", gx, 6.75, R, 2.3, .4, 2.3, cap, 0, None),
                  ("cube", gx, 4.4, R - 1.05, .08, 2.6, 1.1, RED, 0, None), ("sphere_lo", gx, 7.1, R, .45, .6, .45, FLAME, 0, None)]
    parts.append(("cube", 0, 6.4, R, L + 3.8, .8, 1.5, wall, 0, None))
    parts.append(("cube", 0, 2.25, R, L - .1, 4.5, .5, GATE_COLOR, 2, None))             # барьер (рисует клиент полупрозрачным)
    for ang, r_, h in PILLARS:                                                            # укрытия внутри арены
        px, pz = r_ * math.cos(math.radians(ang)), r_ * math.sin(math.radians(ang))
        parts += [("cube", px, h / 2, pz, 1.8, h, 1.8, wall, 1, (0, ang, 0)), ("cube", px, h + .15, pz, 2.2, .3, 2.2, cap, 0, (0, ang, 0))]
        parts.append(("rock1", px + 1.8, .3, pz - 1.2, .9, .6, .8, wall, 0, None))
    parts += [("cube", -3.4, .45, R - 3.2, .8, .9, .8, (40, 38, 40), 0, None), ("sphere_lo", -3.4, 1.05, R - 3.2, .6, .5, .6, FLAME, 0, None),
              ("cube", 3.4, .45, R - 3.2, .8, .9, .8, (40, 38, 40), 0, None), ("sphere_lo", 3.4, 1.05, R - 3.2, .6, .5, .6, FLAME, 0, None)]
    return parts


for _loc in LOCS:
    BLUEPRINTS["lair_" + _loc] = dict(name=ARENA_TITLE[_loc], chest=None, r=ARENA_R + 3, parts=_arena_parts(_loc))


for _k, _f in (("hut", _in_hut), ("tower", _in_tower), ("stones", _in_stones), ("cart", _in_cart), ("ruin", _in_ruin),
               ("poacher", _in_poacher), ("station", _in_station), ("wreck", _in_wreck), ("sled", _in_sled)):
    BLUEPRINTS[_k]["parts"] = list(BLUEPRINTS[_k]["parts"]) + _f()
for _k in ("lair_forest", "lair_thicket", "lair_tundra"):
    BLUEPRINTS[_k]["parts"] = list(BLUEPRINTS[_k]["parts"]) + _in_lair(_k)         # кости и гнездо босса в центре арены


STRUCT_KINDS = {"forest": ("hut", "tower", "stones", "cart"), "thicket": ("ruin", "poacher", "hut", "stones"),
                "tundra": ("station", "wreck", "sled", "stones")}
LOC_SALT = {"forest": 11, "thicket": 23, "tundra": 37}
LAYOUTS = {}
WORLD_SEED = [0]


def struct_world(s, lx, lz):
    th = math.radians(s["yaw"])
    return s["x"] + lx * math.cos(th) + lz * math.sin(th), s["y"] - lx * math.sin(th) + lz * math.cos(th)


def make_layout(loc, seed):
    """Случайная, но одинаковая у сервера и всех клиентов (по общему seed) раскладка построек и логова."""
    r = random.Random(seed * 1009 + LOC_SALT[loc])
    taken = [(CAMP[0], CAMP[1], CAMP_R + 36)]

    def spot(rad, min_camp, margin=35):
        for _ in range(400):
            x, y = r.uniform(margin, W - margin), r.uniform(margin, H - margin)
            if math.hypot(x - CAMP[0], y - CAMP[1]) < min_camp:
                continue
            if all(math.hypot(x - tx, y - ty) > rad + tr + 18 for tx, ty, tr in taken):
                taken.append((x, y, rad))
                return x, y
        return None

    out = dict(structs=[], lair=None, solids=[], gates=[], centers=[])
    lp = spot(ARENA_R + 6, 150, ARENA_R + 16)
    if lp:
        out["lair"] = dict(kind="lair_" + loc, x=lp[0], y=lp[1], yaw=r.uniform(0, 360), boss=BOSS_OF[loc])
    for i in range(8):
        kind = r.choice(STRUCT_KINDS[loc])
        p = spot(BLUEPRINTS[kind]["r"], 55)
        if p:
            out["structs"].append(dict(id=i + 1, kind=kind, x=p[0], y=p[1], yaw=r.choice((0, 90, 180, 270)) + r.uniform(-15, 15)))
    for s in out["structs"] + ([out["lair"]] if out["lair"] else []):
        bp = BLUEPRINTS[s["kind"]]
        out["centers"].append((s["x"], s["y"], bp["r"]))
        for part in bp["parts"]:
            if part[8]:
                cx, cy = struct_world(s, part[1], part[3])
                box = (cx, cy, part[4] / 2 + .35, part[6] / 2 + .35, math.radians(s["yaw"]) + math.radians((part[9] or (0, 0, 0))[1]))
                (out["gates"] if part[8] == 2 else out["solids"]).append(box)
        if bp["chest"]:
            s["cx"], s["cy"] = struct_world(s, *bp["chest"])
    if out["lair"]:
        out["lair"]["gx"], out["lair"]["gy"] = struct_world(out["lair"], 0, ARENA_R)     # центр ворот арены (в мировых координатах)
    return out


def set_world_seed(seed):
    WORLD_SEED[0] = seed
    for loc in LOCS:
        LAYOUTS[loc] = make_layout(loc, seed)


set_world_seed(0)                                   # карта по умолчанию (меню); сервер заменит своим seed


def slot_path(i):
    return os.path.join(SLOTS_DIR, f"slot{i + 1}.json")


def read_slot(i):
    """Краткие сведения о слоте для меню или None, если слот пуст."""
    try:
        with open(slot_path(i), encoding="utf-8") as f:
            d = json.load(f)
        m = d.get("meta") or {}
        if not m.get("owner"):
            return None
        return dict(owner=m["owner"], level=int(m.get("level", 1)), gold=int(m.get("gold", 0)), last=float(m.get("last", 0)),
                    seed=int(d.get("seed", 0)), loc=m.get("loc", "forest"), made=float(m.get("made", 0)))
    except (OSError, ValueError, TypeError):
        return None


def delete_slot(i):
    try:
        os.remove(slot_path(i))
    except OSError:
        pass


def new_slot(i, owner):
    """Создаёт пустое сохранение: новый случайный мир и имя охотника."""
    d = dict(v=2, seed=random.randint(1, 10 ** 9), players={}, chests={},
             meta=dict(owner=owner, level=1, gold=0, last=time.time(), made=time.time(), loc="forest"))
    _atomic_write(slot_path(i), d)


def _atomic_write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, path)                                # файл не будет испорчен, даже если выключат питание во время записи


def migrate_legacy(owner):
    """Старое единственное сохранение превращаем в слот 1 (один раз)."""
    if any(read_slot(i) for i in range(SLOT_COUNT)) or not os.path.exists(SAVE_FILE):
        return
    try:
        with open(SAVE_FILE, encoding="utf-8") as f:
            old = json.load(f)
        if not isinstance(old, dict) or not old:
            return
        who = owner if owner in old else next(iter(old))
        d = old[who]
        _atomic_write(slot_path(0), dict(v=2, seed=random.randint(1, 10 ** 9), players=old, chests={},
                      meta=dict(owner=who, level=level_of(int(d.get("xp", 0))), gold=int(d.get("gold", 0)), last=time.time(),
                                made=time.time(), loc="forest")))
    except (OSError, ValueError, TypeError):
        pass


def item_parts(item):
    """Предмет в сумке: 'deer', 'deer|115' (115 - качество разделки в %) или 'deer|115|g' (золотой зверь)."""
    kind, _, rest = str(item).partition("|")
    q = rest.partition("|")[0]
    try:
        return kind, max(50, min(130, int(q))) if q else 100
    except ValueError:
        return kind, 100


def item_gold(item):
    return str(item).endswith("|g")


# сколько скорости отнимает ноша в руках (множитель скорости): мелочь почти не мешает, лось и медведь - сильно
CARRY_SLOW = {"rabbit": .97, "hare": .97, "grouse": .97, "redfox": .94, "fox": .94, "deer": .82, "reindeer": .8, "boar": .78,
              "wolf": .86, "musk": .74, "moose": .68, "bear": .66, "boss_boar": .6, "boss_bear": .55, "boss_wolf": .6}


def xp_for(level):
    return 40 * (level - 1) ** 2


def level_of(xp):
    return 1 + int(math.sqrt(xp / 40))


class Player:
    def __init__(self, pid, name, conn):
        self.id, self.conn = pid, conn
        self.name = name.replace("<", "").replace(">", "").strip()[:14] or f"Охотник{pid}"
        self.loc = "forest"
        self.x, self.y = camp_spawn()
        self.quest = None
        self.radar, self.shield_t, self.jy = False, 0.0, 0.0
        self.story, self.bosses = 0, []
        self.tokens, self.skins, self.equip = 0, [], {}
        self.carry = -1                                       # номер добычи в сумке, которую несём в руках (-1 - руки свободны)
        self.hp, self.hurt_t, self.dead = float(MAX_HP), 99.0, 0.0
        self.dx = self.dy = self.cool = self.pit = 0.0
        self.ang, self.sprint, self.ads = 0.0, False, False
        self.gold = self.xp = 0
        self.weapon, self.owned = "bow", {"bow"}
        self.sk = {k: 0 for k in SKILLS}
        self.bag, self.msgs = [], []

    # --- уровень и очки навыков
    level = property(lambda s: level_of(s.xp))
    points = property(lambda s: s.level - 1 + s.level // 5 - sum(s.sk.values()))

    # --- характеристики, которые дают навыки
    speed = property(lambda s: 6.5 * (1 + 0.06 * s.sk["b1"]))
    sprint_mult = property(lambda s: 1.5 * (1 + 0.10 * s.sk["b4"]))
    cap = property(lambda s: 6 + 3 * s.sk["b2"])
    stealth = property(lambda s: 1 - 0.08 * s.sk["b3"])
    xp_mult = property(lambda s: 1 + 0.25 * s.sk["b5"])
    dmg_mult = property(lambda s: 1 + 0.10 * s.sk["a1"])
    cd_mult = property(lambda s: 1 - 0.07 * s.sk["a2"])
    hit_mult = property(lambda s: 1 + 0.08 * s.sk["a3"])
    spread_mult = property(lambda s: max(0.4, 1 - 0.08 * s.sk["a3"]))
    crit = property(lambda s: 0.06 * s.sk["a4"])
    giant = property(lambda s: 0.40 * s.sk["a5"])
    sell_mult = property(lambda s: 1 + 0.08 * s.sk["c1"] + 0.20 * s.sk["c4"])
    rare_mult = property(lambda s: 1 + 0.12 * s.sk["c3"])
    discount = property(lambda s: 1 - 0.06 * s.sk["c2"])

    def in_camp(self):
        return math.hypot(self.x - CAMP[0], self.y - CAMP[1]) <= CAMP_R

    def value_of(self, item):
        kind, q = item_parts(item)
        if kind.startswith("loot:"):
            return int(LOOT.get(kind[5:], ("", 100))[1] * self.sell_mult * q / 100)
        v = ANIMALS[kind]["value"] * self.sell_mult * q / 100
        return int(v * (self.rare_mult if ANIMALS[kind]["value"] >= RARE_VALUE else 1))

    def price_of(self, wkey):
        return int(WEAPONS[wkey]["price"] * self.discount)

    def carry_kind(self):
        """Что несём в руках: (вид, золотой) или None."""
        if 0 <= self.carry < len(self.bag):
            k = item_parts(self.bag[self.carry])[0]
            if k in ANIMALS:
                return k, item_gold(self.bag[self.carry])
        return None

    def carry_mult(self):
        c = self.carry_kind()
        return CARRY_SLOW.get(c[0], .85) if c else 1.0

    def dump(self):
        return dict(gold=self.gold, xp=self.xp, weapon=self.weapon, owned=sorted(self.owned),
                    sk=self.sk, bag=self.bag, quest=self.quest, radar=int(self.radar),
                    story=self.story, bosses=self.bosses, tokens=self.tokens, skins=self.skins, equip=self.equip)

    def restore(self, d):
        self.gold = int(d.get("gold", 0))
        self.xp = int(d.get("xp", 0))
        self.owned = {w for w in d.get("owned", []) if w in WEAPONS} | {"bow"}
        self.weapon = d.get("weapon") if d.get("weapon") in self.owned else "bow"
        for k, s in SKILLS.items():
            self.sk[k] = max(0, min(s["max"], int(d.get("sk", {}).get(k, 0))))
        if self.points < 0:                      # защита от испорченного сохранения
            self.sk = {k: 0 for k in SKILLS}
        self.bag = [a for a in d.get("bag", []) if item_parts(a)[0] in ANIMALS or item_parts(a)[0][5:] in LOOT][:self.cap]
        q = d.get("quest")
        self.quest = q if isinstance(q, dict) and q.get("k") in ANIMALS else None
        self.radar = bool(d.get("radar", 0))
        self.bosses = [b for b in d.get("bosses", []) if b in ANIMALS][:3]
        self.story = max(0, min(len(STORY), int(d.get("story", 0))))
        self.tokens = max(0, int(d.get("tokens", 0)))
        self.skins = [k for k in d.get("skins", []) if k in SKINS]
        self.equip = {w: k for w, k in (d.get("equip") or {}).items() if k in self.skins and SKINS[k][0] == w}


class Server:
    def __init__(self, port=PORT, save_file=None, owner=None):
        self.port = port
        self.save_file, self.owner = save_file or slot_path(0), owner
        self.token = None
        self.lock = threading.RLock()
        self.players, self.next_id, self.aid = {}, 1, 1
        self.animals = {k: [] for k in LOCS}
        self.events = {k: [] for k in LOCS}
        self.carcasses = {k: [] for k in LOCS}
        self.cid = 1
        self.saves, self.meta_made, saved_chests = {}, time.time(), {}
        try:
            with open(self.save_file, encoding="utf-8") as f:
                data = json.load(f)
            if "players" in data:                                 # формат со слотами
                self.saves, saved_chests = data.get("players", {}), data.get("chests", {})
                self.seed = int(data.get("seed") or random.randint(1, 10 ** 9))
                self.meta_made = float((data.get("meta") or {}).get("made", self.meta_made))
            else:                                                 # старый формат: просто словарь игроков
                self.saves = data
                self.seed = random.randint(1, 10 ** 9)
        except (OSError, ValueError, TypeError, AttributeError):
            self.seed = random.randint(1, 10 ** 9)
        set_world_seed(self.seed)
        self.chests = {loc: [dict(id=s["id"], x=s["cx"], y=s["cy"], name=BLUEPRINTS[s["kind"]]["name"], opened={})
                             for s in LAYOUTS[loc]["structs"]] for loc in LOCS}
        for loc in LOCS:                                          # когда кто открывал сундуки (чтобы перезапуск не обнулял)
            for c in self.chests[loc]:
                c["opened"] = {k: float(v) for k, v in (saved_chests.get(f"{loc}:{c['id']}") or {}).items()}
        self.boss_t = {loc: 0.0 for loc in LOCS}                  # время до появления босса
        self.respawn_t = 3.0
        now0 = time.time()
        self.weather = {loc: self.roll_weather(loc, now0) for loc in LOCS}
        self.running = True
        self.sock = None
        for loc, info in LOCS.items():
            for kind, n in info["spawn"].items():
                for _ in range(n):
                    self.spawn(loc, kind)
            self.spawn_boss(loc)

    # ---------- мир ----------
    def spawn_boss(self, loc):
        lair = LAYOUTS[loc]["lair"]
        if not lair:
            return
        k = lair["boss"]
        self.animals[loc].append(dict(
            id=self.aid, k=k, x=lair["x"], y=lair["y"], hp=float(ANIMALS[k]["hp"]), herd=0, boss=True,
            lx=lair["x"], ly=lair["y"], dir=0.0, spd=0.0, st=ST_IDLE, cd=0.0, angry=0.0, dmg_by={},
            t=0.0, tx=lair["x"], ty=lair["y"], fl=0.0, fx=0.0, fy=0.0, stam=1.0, alert=0.0, ph=0.0))
        self.aid += 1

    def damage_player(self, p, dmg, src):
        if p.dead > 0:
            return
        p.hp -= dmg
        p.hurt_t = 0.0
        self.events[p.loc].append(dict(k="hurt", p=p.id, d=dmg, x=round(src["x"], 2), y=round(src["y"], 2)))
        if p.hp <= 0:
            p.hp, p.dead = 0.0, 3.0
            lost = len(p.bag)
            p.bag = []
            p.carry = -1
            p.carry = -1
            self.note(p, "Вы погибли!" + (f" Добыча в сумке потеряна ({lost} шт.)." if lost else "") + " Возвращение в лагерь...")

    def in_arena(self, a, x, y, pad=0.0):
        return math.hypot(x - a["lx"], y - a["ly"]) < ARENA_R - 1.0 + pad

    def move_boss(self, a, dt, players, loc=None):
        """Босс живёт на своей арене: нападает только на тех, кто зашёл внутрь, бросается, кусает и откидывает.
        Выйти за стены он не может; если охотники ушли, возвращается в центр и потихоньку лечится."""
        b, info = BOSSES[a["k"]], ANIMALS[a["k"]]
        a["cd"] = max(0.0, a["cd"] - dt)
        a["angry"] = max(0.0, a["angry"] - dt)
        enr = 1.3 if a["hp"] < info["hp"] * .4 else 1.0          # раненый босс звереет
        tgt, td = None, 1e9
        for p in players:
            if p.dead > 0 or p.in_camp() or not self.in_arena(a, p.x, p.y):
                continue
            d = math.hypot(p.x - a["x"], p.y - a["y"])
            if d < td:
                tgt, td = p, d
        if tgt is not None:
            ang = math.atan2(tgt.y - a["y"], tgt.x - a["x"])
            a["st"] = ST_FLEE
            if td > b["reach"]:
                target_spd = b["speed"] * enr
            else:
                target_spd = 0.0
                if a["cd"] <= 0:
                    a["cd"] = b["cd"] / enr
                    kx, ky = (tgt.x - a["x"]) / max(td, .1), (tgt.y - a["y"]) / max(td, .1)
                    tgt.x, tgt.y = move(tgt.x, tgt.y, kx * b["knock"], ky * b["knock"], tgt.loc, tgt.radar)
                    tgt.x, tgt.y = min(W - 3, max(3, tgt.x)), min(H - 3, max(3, tgt.y))
                    self.damage_player(tgt, b["dmg"] * enr, a)
        else:
            d = math.hypot(a["lx"] - a["x"], a["ly"] - a["y"])
            if d > 5:
                ang, target_spd, a["st"] = math.atan2(a["ly"] - a["y"], a["lx"] - a["x"]), b["speed"] * .4, ST_WALK
            else:
                ang, target_spd, a["st"] = a["dir"] + math.sin(a["ph"] + time.time() * .2) * .5, 0.0, ST_IDLE
                a["hp"] = min(float(info["hp"]), a["hp"] + 2.0 * dt)
        diff = (ang - a["dir"] + math.pi) % (2 * math.pi) - math.pi
        turn = 3.2 * dt
        a["dir"] += max(-turn, min(turn, diff))
        a["spd"] += max(-18 * dt, min(18 * dt, target_spd - a["spd"]))
        dx, dy = math.cos(a["dir"]) * a["spd"] * dt, math.sin(a["dir"]) * a["spd"] * dt
        nx, ny = move(a["x"], a["y"], dx, dy, loc)                # обходит укрытия-колонны внутри арены
        ox, oy = nx - a["lx"], ny - a["ly"]
        rr = math.hypot(ox, oy)
        lim = ARENA_R - 2.6                                       # к стене вплотную не подходит
        if rr > lim:
            nx, ny = a["lx"] + ox / rr * lim, a["ly"] + oy / rr * lim
        a["x"], a["y"] = nx, ny

    def spawn(self, loc, kind):
        ai = AI.get(kind, AI["deer"])
        herd = 0
        x = y = 0.0
        if ai["herd"]:                                # присоединяемся к неполному стаду своего вида
            sizes = {}
            for o in self.animals[loc]:
                if o["k"] == kind and o["herd"]:
                    sizes.setdefault(o["herd"], []).append(o)
            open_ = [h for h, m in sizes.items() if len(m) < ai["herd"]]
            if open_:
                herd = random.choice(open_)
                mem = sizes[herd]
                hx, hy = sum(o["x"] for o in mem) / len(mem), sum(o["y"] for o in mem) / len(mem)
                x, y = hx + random.uniform(-8, 8), hy + random.uniform(-8, 8)
            else:
                self.hid = getattr(self, "hid", 0) + 1
                herd = self.hid
        near_p = [(q.x, q.y) for q in self.players.values() if q.loc == loc]
        if herd and any(math.hypot(x - qx, y - qy) < 70 for qx, qy in near_p):
            self.hid = getattr(self, "hid", 0) + 1                # рядом с охотником стадо не пополняем - зверь не «появится» у него перед носом
            herd = self.hid
        if not herd or not (15 < x < W - 15 and 15 < y < H - 15) or math.hypot(x - CAMP[0], y - CAMP[1]) < CAMP_R + 35 or any(
                math.hypot(x - sx, y - sy) < sr + 6 for sx, sy, sr in LAYOUTS[loc]["centers"]) or any(
                math.hypot(x - qx, y - qy) < 70 for qx, qy in near_p):
            for _ in range(30):
                if random.random() < .22:                      # часть зверей держится недалеко от лагеря
                    ang, rr = random.uniform(0, 6.283), random.uniform(CAMP_R + 40, 130)
                    x, y = CAMP[0] + math.cos(ang) * rr, CAMP[1] + math.sin(ang) * rr
                    if not (15 < x < W - 15 and 15 < y < H - 15):
                        continue
                else:
                    x, y = random.uniform(15, W - 15), random.uniform(15, H - 15)
                if math.hypot(x - CAMP[0], y - CAMP[1]) > CAMP_R + 35 and all(
                        math.hypot(x - sx, y - sy) > sr + 10 for sx, sy, sr in LAYOUTS[loc]["centers"]) and all(
                        math.hypot(x - qx, y - qy) > 70 for qx, qy in near_p):
                    break
        gold = kind in TOKENS_FOR and random.random() < GOLD_CHANCE and \
            sum(1 for o in self.animals[loc] if o.get("gold")) < GOLD_MAX
        self.animals[loc].append(dict(
            id=self.aid, k=kind, x=x, y=y, hp=float(ANIMALS[kind]["hp"]), herd=herd, gold=gold,
            dir=random.uniform(0, 6.28), spd=0.0, st=ST_IDLE, t=random.uniform(1, 4), tx=x, ty=y,
            fl=0.0, fx=0.0, fy=0.0, stam=1.0, alert=0.0, ph=random.uniform(0, 6.28)))
        self.aid += 1

    def hostile_target(self, a, dt, players, hs, loc):
        """Кого атакует враждебный зверь (или None). Раненый сверх меры зверь не нападает - он убегает."""
        a["rage"] = max(0.0, a.get("rage", 0.0) - dt)
        a["acd"] = max(0.0, a.get("acd", 0.0) - dt)
        if a["hp"] < ANIMALS[a["k"]]["hp"] * hs["flee"]:
            a["rage"] = 0.0
            return None
        best, bd = None, 1e9
        for p in players:
            if p.dead > 0 or p.in_camp() or math.hypot(p.x - CAMP[0], p.y - CAMP[1]) < CAMP_R + 3:
                continue                                       # в лагерь звери не заходят
            d = math.hypot(p.x - a["x"], p.y - a["y"])
            lim = 55.0 if a["rage"] > 0 else hs["aggro"] * p.stealth
            if d < lim and d < bd:
                best, bd = p, d
        if best is None:
            a["rage"] = 0.0
            return None
        if a["rage"] <= 0:
            a["rage"] = 10.0
            if hs["pack"] and a["herd"]:                        # стая приходит на помощь
                for o in self.animals.get(loc, ()):
                    if o is not a and o["k"] == a["k"] and o["herd"] == a["herd"] and math.hypot(o["x"] - a["x"], o["y"] - a["y"]) < hs["pack"]:
                        o["rage"] = max(o.get("rage", 0.0), 8.0)
        elif bd < 20:
            a["rage"] = max(a["rage"], 4.0)                    # пока охотник рядом - не успокаивается
        return best, bd

    @staticmethod
    def _steer_walls(x, y, vx, vy, reach=28.0, loc=None):
        """Отталкивание от границ карты и от лагеря: зверь заранее заворачивает, а не упирается в стену."""
        for d, nx, ny in ((x, 1, 0), (W - x, -1, 0), (y, 0, 1), (H - y, 0, -1)):
            if d < reach:
                k = ((reach - d) / reach) ** 2 * 2.6
                vx += nx * k
                vy += ny * k
        dc = math.hypot(x - CAMP[0], y - CAMP[1])
        if dc < CAMP_R + 30:
            k = ((CAMP_R + 30 - dc) / 30) * 2.0
            vx += (x - CAMP[0]) / max(dc, .1) * k
            vy += (y - CAMP[1]) / max(dc, .1) * k
        if loc is not None:                                   # постройки и логово тоже обходят
            for sx, sy, sr in LAYOUTS.get(loc, {}).get("centers", ()):
                d = math.hypot(x - sx, y - sy)
                if d < sr + 7:
                    k = (sr + 7 - d) / (sr + 7) * 2.5
                    vx += (x - sx) / max(d, .1) * k
                    vy += (y - sy) / max(d, .1) * k
        return vx, vy

    def move_animal(self, a, dt, players, wm=1.0, herds=None, loc=None):
        info, ai = ANIMALS[a["k"]], AI.get(a["k"], AI["deer"])
        a["fl"] = max(0.0, a["fl"] - dt)
        a["t"] -= dt
        flee_r = info["flee"] * wm * (1 - .45 * ai["bold"]) * (1.35 if a.get("gold") else 1.0)       # золотой - пугливее
        threat, td = None, 1e9
        for p in players:
            d = math.hypot(a["x"] - p.x, a["y"] - p.y)
            if d < flee_r * 1.7 * p.stealth and d < td:
                threat, td = p, d
        close = threat is not None and td < flee_r * threat.stealth
        hs = HOSTILE.get(a["k"])
        prey = self.hostile_target(a, dt, players, hs, loc) if hs else None
        if prey is not None:                                    # нападает: бежит к охотнику, кусает/бодает с перезарядкой
            p, pd = prey
            a["st"] = ST_ATTACK
            ang = math.atan2(p.y - a["y"], p.x - a["x"])
            if pd > hs["reach"]:
                vx, vy = self._steer_walls(a["x"], a["y"], math.cos(ang), math.sin(ang), 12.0, loc=loc)
                ang = math.atan2(vy, vx)
                target_spd = info["speed"] * hs["spd"] * (.55 + .45 * min(1.0, a["stam"] * 2))
            else:
                target_spd = 0.0
                if a.get("acd", 0.0) <= 0:
                    a["acd"] = hs["cd"]
                    kx, ky = (p.x - a["x"]) / max(pd, .1), (p.y - a["y"]) / max(pd, .1)
                    p.x, p.y = move(p.x, p.y, kx * 1.1, ky * 1.1, p.loc, p.radar)
                    p.x, p.y = min(W - 3, max(3, p.x)), min(H - 3, max(3, p.y))
                    self.damage_player(p, hs["dmg"], a)
            a["stam"] = max(0.0, a["stam"] - dt / 30)
            acc = 16.0
        elif close or a["fl"] > 0:
            if a["st"] != ST_FLEE:
                a["ph"] = random.uniform(0, 6.28)
            a["st"] = ST_FLEE
            sx, sy = (threat.x, threat.y) if close else (a["fx"], a["fy"])
            if close:
                a["fl"] = max(a["fl"], random.uniform(1.5, 3.0))    # и ещё немного бежит после того, как оторвался
                a["fx"], a["fy"] = sx, sy
            ux, uy = a["x"] - sx, a["y"] - sy
            n = math.hypot(ux, uy) or 1.0
            vx, vy = ux / n, uy / n
            vx, vy = self._steer_walls(a["x"], a["y"], vx, vy, loc=loc)
            ang = math.atan2(vy, vx) + math.sin(a["ph"] + a["t"] * 3.1) * .55 * ai["zig"]   # петляет
            a["stam"] = max(0.0, a["stam"] - dt / 14)
            target_spd = info["speed"] * (.45 + .55 * min(1.0, a["stam"] * 2.5))         # выдохся - бежит медленнее
            acc = 14.0
        elif threat is not None and ai["bold"] < .7:              # заметил охотника издалека: замер и смотрит
            if a["st"] != ST_ALERT:
                a["alert"] = 0.0
            a["st"] = ST_ALERT
            a["alert"] += dt
            ang = math.atan2(threat.y - a["y"], threat.x - a["x"])
            target_spd, acc = 0.0, 10.0
            if a["alert"] > 2.5:                                   # насторожился - уходит шагом
                vx, vy = self._steer_walls(a["x"], a["y"], -math.cos(ang), -math.sin(ang), loc=loc)
                ang = math.atan2(vy, vx)
                target_spd = info["speed"] * .3
            a["stam"] = min(1.0, a["stam"] + dt / 20)
        else:
            a["stam"] = min(1.0, a["stam"] + dt / 20)
            if a["st"] in (ST_FLEE, ST_ALERT, ST_ATTACK) or a["t"] <= 0:      # новое занятие: идти, пастись или стоять
                r = random.random()
                if r < ai["graze"]:
                    a["st"], a["t"] = ST_GRAZE, random.uniform(4, 10)
                elif r < ai["graze"] + .12:
                    a["st"], a["t"] = ST_IDLE, random.uniform(2, 6)
                else:
                    a["st"], a["t"] = ST_WALK, random.uniform(6, 14)
                    cx, cy = a["x"], a["y"]
                    if herds is not None and a["herd"] and (a["k"], a["herd"]) in herds:
                        cx, cy = herds[(a["k"], a["herd"])]               # стадо держится вместе
                        rad = 10.0
                    else:
                        rad = 30.0
                    for _ in range(12):
                        tx, ty = cx + random.uniform(-rad, rad), cy + random.uniform(-rad, rad)
                        if 18 < tx < W - 18 and 18 < ty < H - 18 and math.hypot(tx - CAMP[0], ty - CAMP[1]) > CAMP_R + 32 and all(
                                math.hypot(tx - sx, ty - sy) > sr + 3 for sx, sy, sr in LAYOUTS.get(loc, {}).get("centers", ())):
                            break
                    a["tx"], a["ty"] = min(W - 18, max(18, tx)), min(H - 18, max(18, ty))
            if a["st"] == ST_WALK:
                dx, dy = a["tx"] - a["x"], a["ty"] - a["y"]
                if math.hypot(dx, dy) < 1.5:
                    a["t"] = 0.0
                vx, vy = self._steer_walls(a["x"], a["y"], dx / (math.hypot(dx, dy) or 1), dy / (math.hypot(dx, dy) or 1), 18.0, loc=loc)
                ang = math.atan2(vy, vx)
                target_spd = info["speed"] * .22
            else:
                ang, target_spd = a["dir"], 0.0
            acc = 4.0
        # плавный поворот и разгон вместо мгновенного разворота
        diff = (ang - a["dir"] + math.pi) % (2 * math.pi) - math.pi
        turn = ai["turn"] * dt * (1.6 if a["st"] == ST_FLEE else 1.0)
        a["dir"] += max(-turn, min(turn, diff))
        a["spd"] += max(-acc * dt, min(acc * dt, target_spd - a["spd"]))
        if a["spd"] > .01:
            nx = a["x"] + math.cos(a["dir"]) * a["spd"] * dt
            ny = a["y"] + math.sin(a["dir"]) * a["spd"] * dt
            if not (3 < nx < W - 3):                               # упёрся в край - скользит вдоль, а не стоит
                a["dir"] = math.atan2(math.sin(a["dir"]), -math.cos(a["dir"]) * .2)
            if not (3 < ny < H - 3):
                a["dir"] = math.atan2(-math.sin(a["dir"]) * .2, math.cos(a["dir"]))
            a["x"], a["y"] = min(W - 3, max(3, nx)), min(H - 3, max(3, ny))
            for sx, sy, sr in LAYOUTS.get(loc, {}).get("centers", ()):   # на арены и в постройки звери не заходят: выталкиваем наружу
                ddx, ddy = a["x"] - sx, a["y"] - sy
                dd = math.hypot(ddx, ddy)
                if dd < sr:
                    k = (sr + .2) / max(dd, .01)
                    a["x"], a["y"] = sx + ddx * k, sy + ddy * k

    def tick(self, dt):
        with self.lock:
            for p in self.players.values():
                p.cool = max(0.0, p.cool - dt)
                while p.story < len(STORY) and story_step_done(p, p.story):          # сюжет: глава выполнена
                    ch = STORY[p.story]
                    p.gold += ch["gold"]
                    p.xp += ch["xp"]
                    self.events[p.loc].append(dict(k="story", p=p.id, ch=p.story, x=round(p.x, 2), y=round(p.y, 2)))
                    self.note(p, f"Глава {p.story + 1} «{ch['title']}» пройдена! +${ch['gold']}, +{ch['xp']} опыта")
                    p.story += 1
                p.hurt_t += dt
                if p.dead > 0:                                  # мёртвый ждёт и возрождается в лагере
                    p.dead -= dt
                    if p.dead <= 0:
                        p.dead, p.hp = 0.0, float(MAX_HP)
                        p.x, p.y = camp_spawn()
                    continue
                if p.hurt_t > 6:                                # здоровье восстанавливается вне боя
                    p.hp = min(float(MAX_HP), p.hp + 4 * dt)
                moving = p.dx or p.dy
                if p.carry >= len(p.bag):
                    p.carry = -1
                spd = p.speed * (ADS_SPEED if p.ads else (p.sprint_mult if p.sprint and moving else 1.0)) * p.carry_mult()
                nx, ny = move(p.x, p.y, p.dx * spd * dt, p.dy * spd * dt, p.loc, p.radar)
                p.x, p.y = min(W - 3, max(3, nx)), min(H - 3, max(3, ny))
            for loc, lst in self.animals.items():
                here = [p for p in self.players.values() if p.loc == loc]
                if not here:                                    # в локации никого - звери «спят» (экономим процессор)
                    lst = []
                wm = WEATHER_FLEE.get(self.weather[loc]["kind"], 1.0)
                acc = {}
                for a in lst:                                  # центры стад
                    if a["herd"]:
                        c = acc.setdefault((a["k"], a["herd"]), [0.0, 0.0, 0])
                        c[0] += a["x"]
                        c[1] += a["y"]
                        c[2] += 1
                herds = {k: (v[0] / v[2], v[1] / v[2]) for k, v in acc.items()}
                for a in lst:
                    if a.get("boss"):
                        self.move_boss(a, dt, here, loc)
                        continue
                    dmin = min((p.x - a["x"]) ** 2 + (p.y - a["y"]) ** 2 for p in here)
                    if dmin > 130 * 130:                        # далёкие звери думают реже (игроку их не видно)
                        a["acc"] = a.get("acc", 0.0) + dt
                        if a["acc"] < .25:
                            continue
                        step, a["acc"] = a["acc"], 0.0
                        self.move_animal(a, step, here, wm, herds, loc)
                    else:
                        self.move_animal(a, dt, here, wm, herds, loc)
                if here and not any(a.get("boss") for a in self.animals[loc]):        # босс возрождается через 10 минут
                    self.boss_t[loc] -= dt
                    if self.boss_t[loc] <= 0:
                        self.spawn_boss(loc)
                        self.boss_t[loc] = BOSS_RESPAWN
            now = time.time()
            for lst in self.carcasses.values():                 # туши со временем исчезают
                lst[:] = [c for c in lst if c["exp"] > now]
            for loc, w in self.weather.items():                 # смена погоды
                if now >= w["until"]:
                    self.weather[loc] = self.roll_weather(loc, now)
            self.respawn_t -= dt
            if self.respawn_t <= 0:                       # возрождение животных
                self.respawn_t = 3.0
                for loc, info in LOCS.items():
                    for kind, n in info["spawn"].items():
                        if sum(1 for a in self.animals[loc] if a["k"] == kind) < n:
                            self.spawn(loc, kind)
            for p in list(self.players.values()):
                self.send(p, self.snapshot(p))
            for e in self.events.values():
                e.clear()

    def roll_weather(self, loc, now):
        kinds, weights = zip(*WEATHER[loc])
        return dict(kind=random.choices(kinds, weights)[0], until=now + random.uniform(100, 260))

    def set_weather(self, loc, kind, seconds=9999):
        self.weather[loc] = dict(kind=kind, until=time.time() + seconds)

    def snapshot(self, p):
        msgs, p.msgs = p.msgs, []
        now = time.time()
        return dict(
            t="s", loc=p.loc, n=len(self.players), wx=self.weather[p.loc]["kind"],
            you=dict(id=p.id, gold=p.gold, xp=p.xp, lv=p.level, cur=xp_for(p.level),
                     nxt=xp_for(p.level + 1), w=p.weapon, owned=sorted(p.owned), sk=p.sk,
                     pts=p.points, bag=p.bag, cap=p.cap, cool=round(p.cool, 2),
                     cdm=round(p.cd_mult, 2), camp=p.in_camp(), spd=round(p.speed, 2),
                     spr=round(p.sprint_mult, 2), msgs=msgs,
                     bagval=sum(p.value_of(a) for a in p.bag), quest=p.quest,
                     prices={k: p.price_of(k) for k in WEAPONS}, respec=RESPEC_COST,
                     hp=round(p.hp), dead=round(p.dead, 1), radar=int(p.radar), story=p.story, bosses=p.bosses,
                     carry=p.carry, cm=round(p.carry_mult(), 3),
                     tok=p.tokens, skins=p.skins, equip=p.equip),
            ch=[[c["id"], int(now - c["opened"].get(p.name, -1e9) > CHEST_RESPAWN)] for c in self.chests[p.loc]],
            pl=[[q.id, q.name, round(q.x, 2), round(q.y, 2), round(q.ang, 2), q.weapon, round(q.jy, 2), q.equip.get(q.weapon), *(q.carry_kind() or (None, False))]
                for q in self.players.values() if q.loc == p.loc],
            an=[[a["id"], a["k"], round(a["x"], 2), round(a["y"], 2), round(a["dir"], 2), round(a["hp"], 1), a["st"], int(a.get("gold", 0))]
                for a in self.animals[p.loc]
                if (a["x"] - p.x) ** 2 + (a["y"] - p.y) ** 2 < (450 * 450 if a.get("boss") else 220 * 220)],
            cs=[[c["id"], c["k"], round(c["x"], 2), round(c["y"], 2), round(c["dir"], 2),
                 int(c["owner"] != p.id and now < c["lock"]), int(c.get("gold", 0))] for c in self.carcasses[p.loc]],
            ev=self.events[p.loc])

    # ---------- действия игроков ----------
    def note(self, p, text):
        p.msgs.append(text)

    def shoot(self, p, ang, pit, ads=False):
        w = WEAPONS[p.weapon]
        if p.cool > 0 or p.in_camp() or p.dead > 0:
            return
        if p.carry >= 0 and p.carry_kind():                    # руки заняты добычей - стрелять нельзя
            if time.time() - p.shield_t > 3:
                p.shield_t = time.time()
                self.note(p, "Руки заняты добычей: положите её (G или сумка на I) или возьмите оружие (1-4)")
            return
        p.cool = w["cd"] * p.cd_mult
        ox, oy, oz = p.x, p.y, EYE + p.jy
        loud = 22 if p.weapon == "bow" else 55                    # лук тихий, ружья слышно далеко
        for an in self.animals[p.loc]:
            if math.hypot(an["x"] - ox, an["y"] - oy) < loud * (1 - .5 * AI.get(an["k"], AI["deer"])["bold"]):
                an["fl"], an["fx"], an["fy"] = max(an["fl"], random.uniform(2.5, 4.5)), ox, oy
        for _ in range(w["pellets"]):
            sp = w["spread"] * p.spread_mult + (0.0 if ads else HIP_SPREAD[p.weapon])
            a = ang + random.uniform(-sp, sp)
            t = pit + random.uniform(-sp, sp)
            ux, uy, uz = math.cos(a) * math.cos(t), math.sin(a) * math.cos(t), math.sin(t)
            best, dist = None, w["range"]
            for an in self.animals[p.loc]:
                info = ANIMALS[an["k"]]
                rx, ry, rz = an["x"] - ox, an["y"] - oy, info["h"] - oz
                proj = rx * ux + ry * uy + rz * uz
                if proj < 0 or proj >= dist:
                    continue
                qx, qy, qz = rx - ux * proj, ry - uy * proj, rz - uz * proj
                r = info["r"] * p.hit_mult
                if qx * qx + qy * qy + qz * qz <= r * r:
                    best, dist = an, proj
            if best is not None and best.get("boss") and not self.in_arena(best, p.x, p.y, 1.2):
                self.events[p.loc].append(dict(k="shield", x=round(best["x"], 2), y=round(best["y"], 2), z=ANIMALS[best["k"]]["h"]))
                if time.time() - p.shield_t > 4:              # снаружи босса не достать - щит арены гасит выстрелы
                    p.shield_t = time.time()
                    self.note(p, "Щит арены гасит выстрелы. Зайдите внутрь через ворота (нужен боевой радар)")
                best = None
            if best is None and uz < 0:                   # луч упёрся в землю
                dist = min(dist, EYE / -uz)
            self.events[p.loc].append(dict(
                k="shot", p=p.id, w=p.weapon, x=round(ox, 2), y=round(oy, 2), z=oz,
                x2=round(ox + ux * dist, 2), y2=round(oy + uy * dist, 2), z2=round(max(0.0, oz + uz * dist), 2)))
            if best:
                self.hit(p, best, w["dmg"] * p.dmg_mult)

    def hit(self, p, an, dmg):
        info = ANIMALS[an["k"]]
        crit = random.random() < p.crit
        if crit:
            dmg *= 2
        if info["hp"] >= GIANT_HP:
            dmg *= 1 + p.giant
        an["hp"] -= dmg
        if an.get("boss"):                                  # босса нельзя спугнуть - он злится и запоминает обидчиков
            an["angry"] = 12.0
            an["dmg_by"][p.id] = an["dmg_by"].get(p.id, 0) + dmg
        else:
            an["fl"], an["fx"], an["fy"] = 5.0, p.x, p.y
            hs = HOSTILE.get(an["k"])
            if hs and random.random() < hs["provoke"]:         # раненый хищник / кабан / лось бросается на стрелка
                an["rage"] = 12.0
        dead = an["hp"] <= 0
        self.events[p.loc].append(dict(k="hit", p=p.id, x=round(an["x"], 2), y=round(an["y"], 2),
                                       z=info["h"], d=round(dmg, 1), c=crit, dead=dead))
        if not dead:
            return
        self.animals[p.loc].remove(an)
        if an.get("boss"):                                  # награда всем, кто помогал
            self.boss_t[p.loc] = BOSS_RESPAWN
            for pid in set(an["dmg_by"]) | {p.id}:              # победа над боссом засчитывается в сюжет всем участникам
                q_ = self.players.get(pid)
                if q_ is not None and an["k"] not in q_.bosses:
                    q_.bosses.append(an["k"])
            for pid in an["dmg_by"]:
                q_ = self.players.get(pid)
                if q_ is not None and q_ is not p:
                    q_.xp += int(info["xp"] * .5)
                    self.note(q_, f"Босс повержен: {info['name']}! +{int(info['xp'] * .5)} опыта за помощь")
            self.note(p, f"БОСС ПОВЕРЖЕН: {info['name']}! Разделайте трофей (F)")
        old = p.level
        gain = int(info["xp"] * p.xp_mult)
        p.xp += gain
        q = p.quest
        if q and q["k"] == an["k"] and q["have"] < q["need"]:
            q["have"] += 1
            self.note(p, f"Заказ: {q['have']}/{q['need']} - {info['name']}")
        now = time.time()                                       # туша остаётся на земле - её надо подобрать
        self.carcasses[p.loc].append(dict(id=self.cid, k=an["k"], x=an["x"], y=an["y"], dir=an["dir"], owner=p.id,
                                          lock=now + CARCASS_LOCK, exp=now + CARCASS_TTL, gold=an.get("gold", False)))
        if an.get("gold"):                                       # золотой зверь: жетоны для игрового автомата
            tk = TOKENS_FOR.get(an["k"], 1)
            p.tokens += tk
            self.events[p.loc].append(dict(k="golden", p=p.id, x=round(an["x"], 2), y=round(an["y"], 2), n=tk))
            self.note(p, f"ЗОЛОТОЙ ЗВЕРЬ! +{tk} жетон{'а' if 1 < tk < 5 else ''} для игрового автомата в лагере")
        self.cid += 1
        self.note(p, f"Добыто: {info['name']} (+{gain} опыта). Подойдите и нажмите F, чтобы подобрать.")
        if p.level > old:
            self.note(p, f"Новый уровень: {p.level}!  Очки навыков: {p.points}  (K)")

    def handle(self, p, m):
        t = m.get("t")
        if t == "in":
            dx, dy = float(m.get("dx", 0)), float(m.get("dy", 0))
            n = math.hypot(dx, dy)
            p.dx, p.dy = (dx / n, dy / n) if n > 0 else (0.0, 0.0)
            p.ang, p.pit = float(m.get("ang", 0)), float(m.get("pit", 0))
            p.sprint, p.ads = bool(m.get("sp", False)), bool(m.get("ads", False)) and p.carry < 0
            try:
                p.jy = max(0.0, min(1.6, float(m.get("jy", 0.0))))
            except (TypeError, ValueError):
                p.jy = 0.0
        elif t == "shoot":
            self.shoot(p, float(m.get("ang", 0)), max(-1.4, min(1.4, float(m.get("pit", 0)))), bool(m.get("ads", False)))
        elif t == "buy":                                   # купить или взять в руки
            k = m.get("w")
            w = WEAPONS.get(k)
            if not w:
                return
            if k in p.owned:
                p.weapon = k
                p.carry = -1                                   # оружие берём в руки - добыча убирается в сумку
            elif not p.in_camp():
                self.note(p, "Покупать можно только в лагере")
            elif p.level < w["level"]:
                self.note(p, f"Нужен уровень {w['level']}")
            elif p.gold < p.price_of(k):
                self.note(p, "Не хватает денег")
            else:
                p.gold -= p.price_of(k)
                p.owned.add(k)
                p.weapon = k
                self.note(p, f"Куплено: {w['name']}")
        elif t == "carry":                                 # взять добычу из сумки в руки (i = номер клетки) или убрать обратно (-1)
            try:
                i = int(m.get("i", -1))
            except (TypeError, ValueError):
                i = -1
            if i < 0:
                p.carry = -1
            elif i < len(p.bag) and item_parts(p.bag[i])[0] in ANIMALS and p.dead <= 0:
                p.carry = i
                p.ads = False
        elif t == "spin":
            if math.hypot(p.x - SLOT_POS[0], p.y - SLOT_POS[1]) > 4.5:
                self.note(p, "Подойдите к игровому автомату в лагере")
            elif p.tokens < SPIN_COST:
                self.note(p, f"Нужно {SPIN_COST} жетона - их дают за золотых зверей")
            else:
                p.tokens -= SPIN_COST
                k = roll_skin()
                dup = k in p.skins
                if dup:
                    p.tokens += 1                                 # повтор: возвращаем жетон
                else:
                    p.skins.append(k)
                    p.equip.setdefault(SKINS[k][0], k)            # первый скин на это оружие надевается сразу
                self.events[p.loc].append(dict(k="spin", p=p.id, skin=k, dup=int(dup), x=round(p.x, 2), y=round(p.y, 2)))
        elif t == "equip":
            w, k = m.get("w"), m.get("skin")
            if w in WEAPONS:
                if k is None:
                    p.equip.pop(w, None)
                elif k in p.skins and SKINS[k][0] == w:
                    p.equip[w] = k
        elif t == "quit":                                  # игра-хозяин закрывает свой сервер (отдельный процесс)
            if self.token and m.get("token") == self.token:
                threading.Thread(target=self.stop, daemon=True).start()
        elif t == "radar":
            n = NPCS["radio"]
            if math.hypot(p.x - n["x"], p.y - n["y"]) > 7:
                self.note(p, "Подойдите к Радисту Фёдору")
            elif p.radar:
                self.note(p, "Боевой радар у вас уже есть")
            elif p.gold < RADAR_PRICE:
                self.note(p, f"Не хватает денег: радар стоит ${RADAR_PRICE}")
            else:
                p.gold -= RADAR_PRICE
                p.radar = True
                self.events[p.loc].append(dict(k="chest", p=p.id, x=round(p.x, 2), y=round(p.y, 2)))
                self.note(p, "Куплен БОЕВОЙ РАДАР! Ворота арен боссов открыты для вас, боссы видны на радаре")
        elif t == "quest":
            a, n = m.get("a"), NPCS["master"]
            if math.hypot(p.x - n["x"], p.y - n["y"]) > 7:
                self.note(p, "Подойдите к Охотоведу Тамаре")
            elif a == "take":
                if p.quest:
                    self.note(p, "У вас уже есть заказ")
                else:
                    pool = sorted({k for L in LOCS.values() if p.level >= L["level"] for k in L["spawn"]})
                    k = random.choice(pool)
                    need = random.randint(*QUEST_NEED.get(k, (2, 4)))
                    info = ANIMALS[k]
                    p.quest = dict(k=k, need=need, have=0, gold=int(need * info["value"] * 1.7 + 30),
                                   xp=int(need * info["xp"] * .7))
                    self.note(p, f"Заказ принят: {info['name']} x{need}")
            elif a == "turn":
                q = p.quest
                if not q:
                    self.note(p, "Нет активного заказа")
                elif q["have"] < q["need"]:
                    self.note(p, "Заказ ещё не выполнен")
                else:
                    old = p.level
                    p.gold += q["gold"]
                    p.xp += q["xp"]
                    p.quest = None
                    self.note(p, f"Заказ выполнен: +${q['gold']} и {q['xp']} опыта")
                    if p.level > old:
                        self.note(p, f"Новый уровень: {p.level}!  Очки навыков: {p.points}  (K)")
            elif a == "drop":
                p.quest = None
                self.note(p, "Заказ отменён")
        elif t == "loot":
            c = next((c for c in self.chests[p.loc] if c["id"] == m.get("id")), None)
            now = time.time()
            if c is None or math.hypot(c["x"] - p.x, c["y"] - p.y) > 3.5:
                self.note(p, "Сундук слишком далеко")
            elif now - c["opened"].get(p.name, -1e9) <= CHEST_RESPAWN:
                self.note(p, f"Сундук пуст. Загляните через {int(CHEST_RESPAWN - (now - c['opened'][p.name])) // 60 + 1} мин")
            else:
                c["opened"][p.name] = now
                tier = TIER[p.loc]
                try:
                    q = max(.6, min(1.3, float(m.get("q", 1.0))))      # качество взлома замка (мини-игра на клиенте)
                except (TypeError, ValueError):
                    q = 1.0
                gold, xp = int(random.randint(60, 160) * tier * q), int(random.randint(30, 80) * tier * q)
                extra = ""
                if random.random() < .3 + .1 * tier + .5 * (q - 1.0):
                    key = random.choice(list(LOOT))
                    if len(p.bag) < p.cap:
                        p.bag.append(f"loot:{key}|{100 + 20 * (tier - 1)}")
                        extra = f" и «{LOOT[key][0]}»"
                    else:
                        gold += LOOT[key][1] // 2
                old = p.level
                p.gold += gold
                p.xp += xp
                self.events[p.loc].append(dict(k="chest", p=p.id, x=round(c["x"], 2), y=round(c["y"], 2)))
                self.note(p, f"Сундук ({c['name']}), качество взлома {int(q * 100)}%: +${gold}, +{xp} опыта{extra}")
                if p.level > old:
                    self.note(p, f"Новый уровень: {p.level}!  Очки навыков: {p.points}  (K)")
        elif t == "pickup":
            near, nd = None, PICKUP_R
            for c in self.carcasses[p.loc]:
                d = math.hypot(c["x"] - p.x, c["y"] - p.y)
                if d < nd:
                    near, nd = c, d
            now = time.time()
            if near is None:
                self.note(p, "Рядом нет добычи")
            elif near["owner"] != p.id and now < near["lock"]:
                self.note(p, f"Эта добыча чужая ещё {int(near['lock'] - now) + 1} с")
            elif len(p.bag) >= p.cap:
                self.note(p, "Сумка полна! Продайте добычу в лагере")
            else:
                self.carcasses[p.loc].remove(near)
                try:
                    q = max(55, min(125, int(float(m.get("q", 1.0)) * 100)))
                except (TypeError, ValueError):
                    q = 100
                p.bag.append(f"{near['k']}|{q}" + ("|g" if near.get("gold") else ""))
                self.events[p.loc].append(dict(k="pick", p=p.id, x=round(near["x"], 2), y=round(near["y"], 2)))
                self.note(p, f"Разделано: {ANIMALS[near['k']]['name']}, качество {q}%")
        elif t == "skill":
            k = m.get("k")
            s = SKILLS.get(k)
            if not s:
                return
            if p.sk[k] >= s["max"]:
                self.note(p, "Навык уже на максимуме")
            elif any(p.sk[q] < 1 for q in s["req"]):
                self.note(p, "Сначала изучите связанные навыки")
            elif p.points < 1:
                self.note(p, "Нет очков навыков - они даются за уровни")
            else:
                p.sk[k] += 1
                self.note(p, f"Навык «{s['name']}»: ранг {p.sk[k]}")
        elif t == "respec":
            if sum(p.sk.values()) == 0:
                self.note(p, "Нечего сбрасывать")
            elif p.gold < RESPEC_COST:
                self.note(p, f"Для сброса нужно ${RESPEC_COST}")
            else:
                p.gold -= RESPEC_COST
                p.sk = {k: 0 for k in SKILLS}
                self.note(p, "Навыки сброшены - распределите очки заново")
        elif not p.in_camp():
            self.note(p, "Это можно делать только в лагере")
        elif t == "sell":
            if not p.bag:
                return self.note(p, "Сумка пуста")
            total = sum(p.value_of(a) for a in p.bag)
            p.gold += total
            self.note(p, f"Продано {len(p.bag)} шт. за ${total}")
            p.bag = []
            p.carry = -1
        elif t == "travel":
            to = m.get("to")
            if to not in LOCS or to == p.loc:
                return
            if p.level < LOCS[to]["level"]:
                return self.note(p, f"Локация откроется на уровне {LOCS[to]['level']}")
            need = BOSS_GATE.get(to)
            if need and need not in p.bosses:
                return self.note(p, f"Путь в локацию «{LOCS[to]['name']}» закрыт: сначала победите босса «{ANIMALS[need]['name']}»")
            p.loc = to
            p.x, p.y = camp_spawn()
            self.note(p, f"Вы прибыли: {LOCS[to]['name']}")

    # ---------- сеть ----------
    def send(self, p, obj):
        try:
            p.conn.sendall((json.dumps(obj, separators=(",", ":")) + "\n").encode())
        except OSError:
            self.players.pop(p.id, None)

    def add(self, conn, name):
        p = Player(self.next_id, name, conn)
        self.next_id += 1
        if p.name in self.saves:
            p.restore(self.saves[p.name])
        self.players[p.id] = p
        self.send(p, dict(t="w", id=p.id, seed=self.seed))
        self.note(p, "Добро пожаловать в лагерь! TAB - магазин, K - навыки, E - продать добычу.")
        return p

    def client(self, conn):
        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        p = None
        try:
            for line in conn.makefile("r", encoding="utf-8"):
                try:
                    m = json.loads(line)
                    with self.lock:
                        if p is None:
                            if m.get("t") == "join":
                                p = self.add(conn, str(m.get("name", "")))
                        elif p.id in self.players:
                            self.handle(p, m)
                except (ValueError, TypeError, AttributeError):
                    continue
        except OSError:
            pass
        finally:
            with self.lock:
                if p:
                    self.players.pop(p.id, None)
                    self.saves[p.name] = p.dump()
                    self.write_save()
            conn.close()

    def write_save(self):
        try:
            who = self.owner or next(iter(self.saves), None)
            live = next((p for p in self.players.values() if p.name == who), None)
            d = live.dump() if live else self.saves.get(who, {})
            meta = dict(owner=who or "Охотник", level=level_of(int(d.get("xp", 0))), gold=int(d.get("gold", 0)),
                        last=time.time(), made=self.meta_made, loc=live.loc if live else "forest")
            chests = {f"{loc}:{c['id']}": c["opened"] for loc in LOCS for c in self.chests[loc] if c["opened"]}
            _atomic_write(self.save_file, dict(v=2, seed=self.seed, players=self.saves, chests=chests, meta=meta))
        except (OSError, TypeError):
            pass

    def accept_loop(self):
        while self.running:
            try:
                conn, _ = self.sock.accept()
            except OSError:
                break
            if not self.running:                           # это «будящее» соединение при остановке сервера
                conn.close()
                break
            threading.Thread(target=self.client, args=(conn,), daemon=True).start()

    def game_loop(self):
        last, saved = time.time(), time.time()
        while self.running:
            now = time.time()
            self.tick(min(0.2, now - last))
            last = now
            if now - saved > 30:                           # автосохранение
                saved = now
                with self.lock:
                    for p in self.players.values():
                        self.saves[p.name] = p.dump()
                    self.write_save()
            time.sleep(max(0.0, TICK - (time.time() - now)))

    def start(self):
        self.sock = socket.socket()
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("0.0.0.0", self.port))             # OSError, если порт занят
        self.sock.listen(8)
        threading.Thread(target=self.accept_loop, daemon=True).start()
        threading.Thread(target=self.game_loop, daemon=True).start()

    def stop(self):
        with self.lock:
            for p in list(self.players.values()):
                self.saves[p.name] = p.dump()
            self.write_save()
        self.running = False
        sock = self.sock
        if sock:                                           # accept() в другом потоке нужно разбудить, иначе порт останется занят
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                socket.create_connection(("127.0.0.1", self.port), timeout=.3).close()
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass
        for p in list(self.players.values()):
            try:
                p.conn.close()
            except (OSError, AttributeError):
                pass


def run_server(port=PORT, save_file=None, owner=None):
    s = Server(port, save_file, owner)
    s.start()
    return s


def main_process():
    """Сервер как отдельный процесс (так его запускает игра-хозяин): он работает на своём ядре процессора и не мешает
    отрисовке. Сам закрывается, если игра пропала (нет игроков 20 секунд) - висящих процессов не остаётся."""
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=PORT)
    ap.add_argument("--save", default=None)
    ap.add_argument("--owner", default=None)
    ap.add_argument("--token", default=None)
    ap.add_argument("--idle-exit", type=float, default=0.0)
    ap.add_argument("--slots", default=None)
    a = ap.parse_args()
    if a.slots:
        globals()["SLOTS_DIR"] = a.slots
    srv = run_server(a.port, a.save, a.owner)
    srv.token = a.token
    print(f"HOW TO HUNT: сервер запущен на порту {a.port}. Ctrl+C - выход.", flush=True)
    idle, seen = 0.0, False
    try:
        while srv.running:
            time.sleep(.5)
            if a.idle_exit:
                seen = seen or srv.next_id > 1                # кто-то уже подключался (даже на мгновение)
                if srv.players:
                    idle = 0.0
                else:
                    idle += .5
                    if idle > (a.idle_exit if seen else a.idle_exit * 3):
                        print("Игроков нет - сервер закрывается", flush=True)
                        srv.stop()
                        break
    except KeyboardInterrupt:
        srv.stop()


if __name__ == "__main__":
    main_process()
