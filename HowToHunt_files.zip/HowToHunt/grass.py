"""HOW TO HUNT - густая колышущаяся трава.

Каждая травинка - изогнутая лента из трёх треугольников с градиентом цвета (тёмный низ, светлая верхушка).
Травинки собраны в ячейки по 10 метров, каждая ячейка - один меш. Колыхание: ячейка слегка «сдвигается» вверх по высоте
(shear), поэтому корни стоят на месте, а верхушки качаются волнами по ветру - без шейдеров и без нагрузки на Python.
Вершины строятся пачкой (numpy, если есть; иначе чистый Python с меньшей плотностью).
"""
import math
import random
import struct

try:
    import numpy as np
except Exception:                                   # numpy ставится вместе с игрой, но не обязателен
    np = None

from ursina import Entity, destroy

_UP = None


def _up_axis():
    """Какая ось Panda3D у движка «вверх»: 1 (Y, система y-up) или 2 (Z, система z-up). Определяем пробой, а не догадкой."""
    global _UP
    if _UP is None:
        try:
            probe = Entity()
            probe.y = 1                                   # y в Ursina - это «вверх»
            p = probe.getPos()
            _UP = 1 if abs(p[1]) > .5 else 2
            destroy(probe)
        except Exception:
            _UP = 1
    return _UP

CELL = 40.0                                                        # крупные ячейки: мало вызовов отрисовки, травинки считает видеокарта
LEVELS = {0: 0, 1: 22000, 2: 50000, 3: 90000, 4: 150000}       # травинок на «зелёную» локацию (до учёта размера карты)
VIEW_R = {0: 45.0, 1: 65.0, 2: 90.0}                             # дальше трава не рисуется (её всё равно скрывает туман)
FULL_R = 32.0                                                      # ближе - вся трава, дальше - каждая 4-я травинка (LOD)
FLOWERS = ((240, 84, 84), (250, 222, 70), (244, 244, 250), (182, 122, 240), (255, 150, 60))


def _format():
    from panda3d.core import Geom, GeomVertexArrayFormat, GeomVertexFormat
    arr = GeomVertexArrayFormat()
    f32 = getattr(Geom, "NT_float32", None) or Geom.NTFloat32
    u8 = getattr(Geom, "NT_uint8", None) or Geom.NTUint8
    cp = getattr(Geom, "C_point", None) or Geom.CPoint
    cc = getattr(Geom, "C_color", None) or Geom.CColor
    arr.addColumn("vertex", 3, f32, cp)
    arr.addColumn("color", 4, u8, cc)
    fmt = GeomVertexFormat()
    fmt.addArray(arr)
    return GeomVertexFormat.registerFormat(fmt)


def _make_node(name, fmt, data, nverts):
    """GeomNode из готового буфера вершин (16 байт на вершину: x y z float32 + rgba uint8)."""
    from panda3d.core import Geom, GeomNode, GeomTriangles, GeomVertexData
    nverts = int(nverts)                            # numpy-числа Panda3D не принимает - нужен обычный int
    vdata = GeomVertexData(name, fmt, getattr(Geom, "UH_static", None) or Geom.UHStatic)
    vdata.setNumRows(nverts)
    vdata.modifyArray(0).modifyHandle().copyDataFrom(data)
    prim = GeomTriangles(getattr(Geom, "UH_static", None) or Geom.UHStatic)
    prim.addConsecutiveVertices(0, nverts)
    prim.closePrimitive()
    geom = Geom(vdata)
    geom.addPrimitive(prim)
    node = GeomNode(name)
    node.addGeom(geom)
    return node


# ------------------------------------------------------------------ генерация травинок
def _blades_numpy(n_clumps, per, rng, w, h, base, dry, thick, holes, camp, camp_r, flowers=.07):
    """Векторизованная генерация: возвращает массив (кол-во травинок, 9 вершин, 3 коорд.) и цвета."""
    cx = rng.uniform(3, w - 3, n_clumps)
    cz = rng.uniform(3, h - 3, n_clumps)
    # «поляны»: плотность и высота меняются плавными пятнами
    patch = .5 + .5 * np.sin(cx * .045 + 1.3) * np.sin(cz * .06 + .7)
    keep = rng.random(n_clumps) < (.3 + .7 * patch)
    keep &= np.hypot(cx - camp[0], cz - camp[1]) > camp_r + 1.5            # вытоптанный лагерь
    for hx, hz, rx, rz in holes:                                           # пруды и озёра
        keep &= ((cx - hx) / rx) ** 2 + ((cz - hz) / rz) ** 2 > 1
    cx, cz, patch = cx[keep], cz[keep], patch[keep]
    m = len(cx)
    tall = 1.0 + (.9 if thick else .35) * patch + (rng.random(m) < .08) * .7           # редкие высокие пучки
    k = np.repeat(np.arange(m), per)                                                    # номер пучка для каждой травинки
    n = len(k)
    ox, oz = rng.normal(0, .13, n), rng.normal(0, .13, n)
    x, z = cx[k] + ox, cz[k] + oz
    hh = np.clip(rng.uniform(.35, .85, n) * tall[k] * (.55 if dry else 1.0), .12, 1.7)
    ww = rng.uniform(.045, .085, n) * (hh / .6) ** .35
    th = rng.uniform(0, 2 * np.pi, n)
    lean = rng.uniform(.05, .55, n) * (1 + .4 * (dry))                                  # наклон: торчит и клонится
    dx, dz = np.cos(th), np.sin(th)
    sx, sz = -dz, dx                                                                    # поперёк ленты
    b1, b2 = lean * hh * .22, lean * hh * .95
    # ряды: основание (2 точки), середина (2 точки), кончик (1 точка)
    p0l = np.stack([x - sx * ww / 2, np.zeros(n), z - sz * ww / 2], 1)
    p0r = np.stack([x + sx * ww / 2, np.zeros(n), z + sz * ww / 2], 1)
    p1l = np.stack([x + dx * b1 - sx * ww * .33, hh * .52, z + dz * b1 - sz * ww * .33], 1)
    p1r = np.stack([x + dx * b1 + sx * ww * .33, hh * .52, z + dz * b1 + sz * ww * .33], 1)
    p2 = np.stack([x + dx * b2, hh, z + dz * b2], 1)
    verts = np.stack([p0l, p0r, p1r, p0l, p1r, p1l, p1l, p1r, p2], 1).astype("<f4")      # (n, 9, 3)
    # цвета: градиент от тёмного корня к светлой верхушке, лёгкий разброс оттенка
    var = rng.uniform(.82, 1.18, n)[:, None] * (.9 + .2 * patch[k])[:, None]
    base_c = np.array(base, dtype="f4")[None, :] * var
    tipmix = np.array((22, 34, -6) if not dry else (28, 22, 6), dtype="f4")[None, :]
    c0 = base_c * .46
    c1 = base_c * .86
    c2 = base_c * 1.1 + tipmix
    cols = np.stack([c0, c0, c1, c0, c1, c1, c1, c1, c2], 1)                               # (n, 9, 3)
    if not dry:                                                                          # цветы на кончиках некоторых пучков
        bloom = (rng.random(m) < flowers)[k] & (np.arange(n) % per < 2)
        fl = np.array(FLOWERS, dtype="f4")[rng.integers(0, len(FLOWERS), m)][k]
        cols[bloom, 8] = fl[bloom]
        cols[bloom, 7] = fl[bloom] * .8 + base_c[bloom] * .2
    cols = np.clip(cols, 0, 255).astype("u1")
    rgba = np.concatenate([cols, np.full((n, 9, 1), 255, "u1")], 2)
    return verts, rgba, x, z


def _blades_python(n_clumps, per, rnd, w, h, base, dry, thick, holes, camp, camp_r):
    """Тот же алгоритм на чистом Python (запасной путь, плотность меньше)."""
    out = []
    for _ in range(n_clumps):
        cx, cz = rnd.uniform(3, w - 3), rnd.uniform(3, h - 3)
        patch = .5 + .5 * math.sin(cx * .045 + 1.3) * math.sin(cz * .06 + .7)
        if rnd.random() > .3 + .7 * patch or math.hypot(cx - camp[0], cz - camp[1]) <= camp_r + 1.5:
            continue
        if any(((cx - hx) / rx) ** 2 + ((cz - hz) / rz) ** 2 <= 1 for hx, hz, rx, rz in holes):
            continue
        tall = 1.0 + (.9 if thick else .35) * patch + (rnd.random() < .08) * .7
        for _ in range(per):
            x, z = cx + rnd.gauss(0, .13), cz + rnd.gauss(0, .13)
            hh = min(1.7, max(.12, rnd.uniform(.35, .85) * tall * (.55 if dry else 1.0)))
            ww = rnd.uniform(.045, .085) * (hh / .6) ** .35
            th = rnd.uniform(0, 6.2832)
            lean = rnd.uniform(.05, .55) * (1.4 if dry else 1.0)
            dx, dz = math.cos(th), math.sin(th)
            sx, sz = -dz, dx
            b1, b2 = lean * hh * .22, lean * hh * .95
            v = ((x - sx * ww / 2, 0, z - sz * ww / 2), (x + sx * ww / 2, 0, z + sz * ww / 2),
                 (x + dx * b1 + sx * ww * .33, hh * .52, z + dz * b1 + sz * ww * .33),
                 (x + dx * b1 - sx * ww * .33, hh * .52, z + dz * b1 - sz * ww * .33), (x + dx * b2, hh, z + dz * b2))
            f = rnd.uniform(.82, 1.18) * (.9 + .2 * patch)
            c0 = [min(255, int(c * f * .46)) for c in base]
            c1 = [min(255, int(c * f * .86)) for c in base]
            tip = (28, 22, 6) if dry else (22, 34, -6)
            c2 = [max(0, min(255, int(c * f * 1.1 + t))) for c, t in zip(base, tip)]
            out.append((x, z, [v[0], v[1], v[2], v[0], v[2], v[3], v[3], v[2], v[4]], [c0, c0, c1, c0, c1, c1, c1, c1, c2]))
    return out


class GrassField:
    def __init__(self, root, w, h, base, dry=False, thick=False, level=3, holes=(), camp=(0, 0), camp_r=14, seed=1, flowers=.07, area=1.0):
        self.root, self.cells, self.blades = root, [], 0
        self.state = {}                              # индекс ячейки -> включена ли
        self.level = level
        try:
            self.flowers, self.area = flowers, area
            self._build(root, w, h, base, dry, thick, level, holes, camp, camp_r, seed)
        except Exception as e:                       # трава - украшение: при любой ошибке игра идёт без неё
            print("Трава не построена:", e)
            for cell, _, _ in self.cells:
                try:
                    cell.enabled = False
                except Exception:
                    pass
            self.cells, self.state = [], {}

    def _build(self, root, w, h, base, dry, thick, level, holes, camp, camp_r, seed):
        total = int(LEVELS.get(level, 0) * getattr(self, "area", 1.0))
        if not total:
            return
        try:
            fmt = _format()
        except Exception as e:
            print("Трава недоступна:", e)
            return
        per = 7
        if dry:
            total = int(total * .38)
        if thick:
            total = int(total * 1.15)
        if np is None:
            total = int(total * .28)                 # без numpy строим меньше травы, чтобы загрузка не затягивалась
        nclumps = total // per
        gx, gz = int(w // CELL) + 1, int(h // CELL) + 1
        buckets = {}
        if np is not None:
            rng = np.random.default_rng(seed)
            verts, rgba, x, z = _blades_numpy(nclumps, per, rng, w, h, base, dry, thick, holes, camp, camp_r, self.flowers)
            if _up_axis() == 2:
                verts = np.ascontiguousarray(verts[..., [0, 2, 1]])
            cell_id = (np.floor(x / CELL).astype(int).clip(0, gx - 1) * gz + np.floor(z / CELL).astype(int).clip(0, gz - 1))
            order = np.argsort(cell_id, kind="stable")
            cell_id, verts, rgba = cell_id[order], verts[order], rgba[order]
            bounds = np.flatnonzero(np.diff(cell_id)) + 1
            starts = np.concatenate([[0], bounds])
            ends = np.concatenate([bounds, [len(cell_id)]])
            dt = np.dtype([("p", "<f4", 3), ("c", "u1", 4)])
            for s, e in zip(starts, ends):
                buf = np.empty((e - s, 9), dt)
                buf["p"] = verts[s:e]
                buf["c"] = rgba[s:e]
                lod = buf[::4]                                    # дальний уровень: каждая 4-я травинка
                buckets[int(cell_id[s])] = (buf.tobytes(), int(e - s) * 9, lod.tobytes(), int(len(lod)) * 9)
        else:
            blades = _blades_python(nclumps, per, random.Random(seed), w, h, base, dry, thick, holes, camp, camp_r)
            groups = {}
            for x, z, vs, cs in blades:
                cid = min(gx - 1, int(x // CELL)) * gz + min(gz - 1, int(z // CELL))
                groups.setdefault(cid, []).append((vs, cs))
            for cid, items in groups.items():
                chunks = []
                for vs, cs in items:
                    for p, c in zip(vs, cs):
                        a, b = (p[1], p[2]) if _up_axis() == 1 else (p[2], p[1])
                        chunks.append(struct.pack("<3f4B", p[0], a, b, c[0], c[1], c[2], 255))
                lodc = [c for i, c in enumerate(chunks) if (i // 9) % 4 == 0]
                buckets[cid] = (b"".join(chunks), len(items) * 9, b"".join(lodc), len(lodc))
        for cid, (data, nv, ldata, lnv) in buckets.items():
            cx, cz = (cid // gz + .5) * CELL, (cid % gz + .5) * CELL
            cell = root.attachNewNode("grass%d" % cid)
            full = cell.attachNewNode(_make_node("g%d" % cid, fmt, data, nv))
            lod = cell.attachNewNode(_make_node("l%d" % cid, fmt, ldata, lnv)) if lnv else None
            try:
                cell.setTwoSided(True)
                cell.setLightOff()
                cell.hide()                                       # покажем, когда игрок подойдёт
                if lod is not None:
                    lod.hide()
            except Exception:
                pass
            self.cells.append((cell, cx, cz, full, lod))
            self.state[len(self.cells) - 1] = 0                  # 0 - скрыта, 1 - дальняя (редкая), 2 - ближняя (вся)
        self.blades = sum(b[1] for b in buckets.values()) // 9

    def update(self, t, eye, wind, sway=True, view=1, sway_r=32.0, detail=1.0):
        """Раз в кадр. Видимость и уровень детализации ячеек пересчитываются раз в 10 кадров:
        вблизи - вся трава, дальше - каждая 4-я травинка, ещё дальше - ничего. Колышется только ближняя трава.
        detail (0..1) - авто-качество: при низком FPS дальность травы сокращается."""
        if not self.cells:
            return
        self.frame = getattr(self, "frame", 0) + 1
        if self.frame % 10 == 1 or not hasattr(self, "near"):
            vr = max(28.0, VIEW_R.get(view, 65.0) * (.45 + .55 * detail))
            fr = min(vr, FULL_R * (.6 + .4 * detail))
            r2, f2 = vr * vr, fr * fr
            self.near = []
            for i, (cell, cx, cz, full, lod) in enumerate(self.cells):
                d2 = (cx - eye[0]) ** 2 + (cz - eye[2]) ** 2 - CELL * CELL * .5        # до ближнего края ячейки
                st = 2 if d2 < f2 or lod is None and d2 < r2 else (1 if d2 < r2 else 0)
                if st != self.state[i]:
                    try:
                        if st == 0:
                            cell.hide()
                        else:
                            cell.show()
                            if lod is not None:
                                (full.show() if st == 2 else full.hide())
                                (lod.hide() if st == 2 else lod.show())
                    except Exception:
                        pass
                    self.state[i] = st
                if st == 2:
                    self.near.append((cell, cx, cz))
        if not sway or detail < .5:
            return
        amp = .035 + .10 * min(1.4, wind)                 # наклон верхушки в метрах на метр высоты: «чуть-чуть»
        up = _up_axis()
        from panda3d.core import Mat4
        for cell, cx, cz in self.near:
            wave = math.sin(t * 1.35 + cx * .07 + cz * .045) * .65 + math.sin(t * 2.9 - cx * .16 + cz * .1) * .35
            gust = .5 + .5 * math.sin(t * .37 + cx * .02)
            kx = amp * (wave * (.55 + .45 * gust) + .35 * wind * gust)
            kz = amp * .55 * math.sin(t * 1.1 + cz * .06 - cx * .03)
            # смещение точки зависит ТОЛЬКО от её высоты: x += kx*высота, z += kz*высота
            m = Mat4(1, 0, 0, 0, kx, 1, kz, 0, 0, 0, 1, 0, 0, 0, 0, 1) if up == 1 else Mat4(1, 0, 0, 0, 0, 1, 0, 0, kx, kz, 1, 0, 0, 0, 0, 1)
            try:
                cell.setMat(m)
            except Exception:
                return
