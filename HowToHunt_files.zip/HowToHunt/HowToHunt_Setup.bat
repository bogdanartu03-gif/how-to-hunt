@echo off
chcp 65001 >nul
title HOW TO HUNT - установка
cd /d "%~dp0"
set "MODE=%~1"

call :findpy
if defined PY goto run

echo.
echo [!] Python не найден. Устанавливаю автоматически, нужен интернет...
where winget >nul 2>nul
if not errorlevel 1 (
    echo Устанавливаю через winget...
    winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
    call :findpy
)
if defined PY goto run

echo Скачиваю установщик Python с python.org...
set "PYSETUP=%TEMP%\python-3.12.10-amd64.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile '%PYSETUP%'"
if exist "%PYSETUP%" (
    echo Устанавливаю Python, это займёт около минуты...
    "%PYSETUP%" /passive InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_test=0
    call :findpy
)
if defined PY goto run

echo.
echo Не удалось установить Python автоматически.
echo Скачайте его вручную: https://www.python.org/downloads/
echo При установке отметьте галочку "Add python.exe to PATH", затем запустите этот файл снова.
pause
exit /b 1

:run
"%PY%" launcher.py %MODE%
if errorlevel 1 pause
exit

:findpy
set "PY="
for %%V in (3.12 3.13 3.11 3.10) do (
    if not defined PY (
        for /f "delims=" %%P in ('py -%%V -c "import sys;print(sys.executable)" 2^>nul') do set "PY=%%P"
    )
)
if not defined PY if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PY=%LocalAppData%\Programs\Python\Python312\python.exe"
if not defined PY (
    for /f "delims=" %%P in ('python -c "import sys;print(sys.executable)" 2^>nul') do set "PY=%%P"
)
goto :eof
