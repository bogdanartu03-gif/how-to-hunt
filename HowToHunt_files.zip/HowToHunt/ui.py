"""HOW TO HUNT - элементы интерфейса: палитра, панели с рамкой, кнопки, поле ввода, иконки оружия."""
from ursina import Entity, Text
from ursina.color import Color


def C(r, g, b, a=255):
    return Color(r / 255, g / 255, b / 255, a / 255)


GOLD, CREAM, DIM = C(255, 210, 74), C(240, 234, 210), C(150, 162, 152)
PANEL, PANEL2, FIELD = C(8, 20, 14, 225), C(14, 32, 23, 240), C(6, 14, 10, 245)
BTN, BTN_OFF, RED, WHITE = C(38, 104, 62), C(48, 54, 52), C(225, 85, 72), C(255, 255, 255)
EDGE = C(255, 210, 74, 80)
CLICK = [None]                       # функция «щелчок кнопки» (звук), её ставит приложение
ACTIVE = [None]                      # поле ввода, на котором стоит фокус


def shade(col, k):
    return Color(min(1, col.r * k), min(1, col.g * k), min(1, col.b * k), col.a)


def qm(w, h, r=.02):
    """Скруглённый прямоугольник (если не получилось - обычный quad)."""
    if r <= 0:
        return "quad"
    try:
        from ursina.models.procedural.quad import Quad
        return Quad(radius=min(r, h * .5, w * .5), aspect=w / h)
    except Exception:
        return "quad"


def panel(parent, x, y, w, h, col, r=.02, z=0.0):
    return Entity(parent=parent, model=qm(w, h, r), scale=(w, h), position=(x, y, z), color=col)


def frame(parent, x, y, w, h, col=PANEL2, r=.03, z=0.0):
    """Панель с тонкой золотистой рамкой."""
    panel(parent, x, y, w + .012, h + .012, EDGE, r + .004, z + .004)
    return panel(parent, x, y, w, h, col, r, z)


def label(parent, s, x, y, size=1.0, col=CREAM, left=False, z=-.02):
    return Text(text=s, parent=parent, position=(x, y, z), origin=(-.5, 0) if left else (0, 0), scale=size, color=col)


def set_text(t, s):
    if getattr(t, "hth_cache", None) != s:
        t.text = s
        t.hth_cache = s


class UIButton:
    def __init__(self, parent, text, x, y, w, h, on_click, col=BTN, size=1.2):
        self.root = Entity(parent=parent, position=(x, y, -.01))
        self.col, self.cb, self.off, self.hover = col, on_click, False, False
        self.bg = Entity(parent=self.root, model=qm(w, h, h * .3), scale=(w, h), color=col, collider="box")
        self.txt = Text(text=text, parent=self.root, origin=(0, 0), position=(0, 0, -.02), scale=size, color=CREAM)
        self.bg.on_click = self._click
        self.bg.on_mouse_enter = self._enter
        self.bg.on_mouse_exit = self._exit

    def _click(self):
        if not self.off and self.cb:
            if CLICK[0]:
                CLICK[0]()
            self.cb()

    def _enter(self):
        self.hover = True
        self.paint()

    def _exit(self):
        self.hover = False
        self.paint()

    def paint(self):
        self.bg.color = BTN_OFF if self.off else (shade(self.col, 1.35) if self.hover else self.col)
        self.root.scale = 1.035 if (self.hover and not self.off) else 1

    def set(self, text=None, off=None, col=None):
        if text is not None:
            set_text(self.txt, text)
        if col is not None:
            self.col = col
        if off is not None:
            self.off = off
            self.txt.color = DIM if off else CREAM
        self.paint()


class TextBox:
    def __init__(self, parent, x, y, w, h, value="", limit=16, addr=False):
        self.root = Entity(parent=parent, position=(x, y, -.01))
        self.value, self.limit, self.addr = value, limit, addr
        self.bg = Entity(parent=self.root, model=qm(w, h, h * .3), scale=(w, h), color=FIELD, collider="box")
        self.txt = Text(text=value, parent=self.root, origin=(-.5, 0), position=(-w / 2 + .02, 0, -.02), scale=1.3, color=CREAM)
        self.bg.on_click = self.focus

    def focus(self):
        if ACTIVE[0] is not None:
            ACTIVE[0].blur()
        ACTIVE[0] = self
        self.bg.color = C(24, 60, 40, 250)

    def blur(self):
        self.bg.color = FIELD
        set_text(self.txt, self.value)
        if ACTIVE[0] is self:
            ACTIVE[0] = None

    def type(self, ch):
        if len(ch) == 1 and ch.isprintable() and ch not in "<>" and len(self.value) < self.limit:
            if not self.addr or ch.isalnum() or ch in ".:-_":
                self.value += ch

    def backspace(self):
        self.value = self.value[:-1]

    def tick(self, blink):
        set_text(self.txt, self.value + ("|" if blink else " "))


# силуэты оружия из прямоугольников: (dx, dy, w, h) в долях единицы интерфейса
ICONS = {
    "bow": [(-.020, .036, .006, .016), (-.026, .018, .006, .016), (-.028, 0, .006, .016), (-.026, -.018, .006, .016),
            (-.020, -.036, .006, .016), (.004, 0, .0025, .082), (-.012, 0, .05, .0025)],
    "rifle": [(.014, .004, .074, .007), (-.018, 0, .04, .014), (-.046, -.004, .026, .02), (-.016, -.016, .008, .018)],
    "shotgun": [(.012, .004, .074, .011), (.006, -.006, .03, .01), (-.02, 0, .04, .016), (-.048, -.004, .028, .022)],
    "sniper": [(.018, .004, .1, .006), (-.016, 0, .04, .014), (-.048, -.004, .026, .02), (0, .014, .03, .011),
               (-.016, -.016, .008, .018)],
}


def weapon_icon(parent, kind, x, y, col=CREAM, z=-.02):
    return [panel(parent, x + dx, y + dy, w, h, col, r=0, z=z) for dx, dy, w, h in ICONS[kind]]
