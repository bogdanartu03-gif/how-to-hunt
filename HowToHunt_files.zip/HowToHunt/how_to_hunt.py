"""HOW TO HUNT - 3D-клиент (Ursina / Panda3D).   Запуск: python how_to_hunt.py
Управление: WASD - ходьба, Shift - бег, мышь - прицел, ЛКМ - выстрел, ПКМ - прицелиться,
            F - подобрать добычу, 1-4 - оружие, TAB - лавка (в лагере), E - продать, K - навыки, ESC - пауза.
Ключ запуска --low включает пресет «Низкая» графики.
"""
import gc
import getpass
import json
import math
import os
import random
import shutil
import socket
import subprocess
import sys
import textwrap
import threading
import time as pytime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from ursina import Entity, Text, Ursina, Vec3, application, camera, destroy, held_keys, mouse, scene, window
from ursina.color import Color

import fx
import server as srv
USE_SERVER_PROCESS = True
import sfx
import ui
import world3d as w3
from server import (ARENA_R, BOSS_GATE, CARRY_SLOW, LOOT, RADAR_PRICE, RARITY, SKINS, SLOT_POS, SPIN_COST, STORY, item_gold, item_parts, ADS_SPEED, ANIMALS, BRANCHES, CAMP, H, LOCS, NPCS, PICKUP_R, PORT, SKILLS, TALK_R, W,
                    WEAPONS)
from ui import (ACTIVE, BTN, C, CREAM, DIM, GOLD, PANEL, PANEL2, RED, WHITE, TextBox, UIButton, frame, label, panel,
                set_text, shade, weapon_icon)

HOME = os.path.join(os.path.expanduser("~"), ".how_to_hunt")
SETTINGS_FILE = os.path.join(HOME, "settings.json")
EYE = srv.EYE

# ====================================================================== настройки
DEFAULTS = dict(name="", addr="127.0.0.1", sens=40, fov=90, vol=70, music=40, shadows=2, view=1, density=2, aa=1,
                vsync=0, fog=1, vignette=1, particles=2, clouds=1, tod="cycle", bob=1, fps=0, precip=2, lightning=1, grass=3, sway=1, tut=0, tut_done=[],
                master=100, amb=70, inv_y=0, ads_sens=70, aim_mode=0, fps_cap=0, keys={}, auto_q=1, perf_v=0, mt=1, last_slot=0, proc=1)
PRESETS = [("Низкая", dict(grass=1, sway=0, shadows=0, view=0, density=0, aa=0, particles=0, clouds=0, precip=0, lightning=0)),
           ("Средняя", dict(grass=2, sway=1, shadows=1, view=1, density=1, aa=0, particles=1, clouds=1, precip=1, lightning=1)),
           ("Высокая", dict(grass=3, sway=1, shadows=2, view=2, density=2, aa=1, particles=2, clouds=1, precip=2, lightning=1)),
           ("Ультра", dict(grass=4, sway=1, shadows=3, view=2, density=3, aa=1, particles=2, clouds=1, precip=2, lightning=1))]
ONOFF = [(0, "Выкл"), (1, "Вкл")]
# (ключ, название, варианты, нужен ли перезапуск)
PCT = [(v, f"{v}%") for v in range(0, 110, 10)]
GFX = [
    ("shadows", "Тени и освещение", [(0, "Выкл"), (1, "Средние"), (2, "Высокие"), (3, "Ультра")], True),
    ("view", "Дальность прорисовки", [(0, "Близко"), (1, "Средне"), (2, "Далеко")], False),
    ("density", "Растительность", [(0, "Мало"), (1, "Средне"), (2, "Много"), (3, "Максимум")], True),
    ("grass", "Густота травы", [(0, "Нет"), (1, "Мало"), (2, "Средне"), (3, "Много"), (4, "Максимум")], True),
    ("sway", "Колыхание травы", ONOFF, False),
    ("aa", "Сглаживание (MSAA)", ONOFF, True),
    ("vsync", "Верт. синхронизация", ONOFF, True),
    ("fps_cap", "Ограничение FPS", [(0, "Нет"), (30, "30"), (60, "60"), (90, "90"), (120, "120"), (144, "144")], False),
    ("fov", "Поле зрения", [(v, f"{v}°") for v in range(60, 125, 5)], False),
    ("fog", "Туман", ONOFF, False),
    ("vignette", "Виньетка", ONOFF, False),
    ("particles", "Частицы и эффекты", [(0, "Выкл"), (1, "Средне"), (2, "Много")], False),
    ("clouds", "Облака", ONOFF, False),
    ("precip", "Дождь и снег", [(0, "Выкл"), (1, "Средне"), (2, "Много")], False),
    ("lightning", "Вспышки молний", ONOFF, False),
    ("tod", "Время суток", [("cycle", "Цикл"), ("day", "День"), ("dusk", "Вечер"), ("night", "Ночь")], False),
    ("auto_q", "Авто-качество (держать 60 FPS)", ONOFF, False),
    ("mt", "Многопоточная отрисовка", ONOFF, True),
    ("proc", "Сервер в отдельном процессе", ONOFF, False),
    ("fps", "Счётчик FPS", ONOFF, False),
]
SND = [
    ("master", "Общая громкость", PCT, False),
    ("vol", "Выстрелы и эффекты", PCT, False),
    ("music", "Музыка", PCT, False),
    ("amb", "Окружение (ветер, дождь, костёр)", PCT, False),
]
CTRL = [
    ("sens", "Чувствительность мыши", [(v, str(v)) for v in range(10, 105, 5)], False),
    ("ads_sens", "Чувствит. в прицеле", [(v, f"{v}%") for v in range(30, 105, 5)], False),
    ("inv_y", "Инверсия мыши по Y", ONOFF, False),
    ("aim_mode", "Прицеливание (ПКМ)", [(0, "Удерживать"), (1, "Переключать")], False),
    ("bob", "Покачивание камеры", ONOFF, False),
]
OPTIONS = GFX + SND + CTRL
TABS = [("gfx", "ГРАФИКА", GFX), ("snd", "ЗВУК", SND), ("ctl", "УПРАВЛЕНИЕ", CTRL)]
KEY_DEFAULTS = dict(forward="w", back="s", left="a", right="d", sprint="shift", jump="space", inv="i", carry="g", pickup="f", interact="e", shop="tab",
                    skills="k", tasks="h", help="f1")
KEY_NAMES = [("forward", "Вперёд"), ("back", "Назад"), ("left", "Влево"), ("right", "Вправо"), ("sprint", "Бег"), ("jump", "Прыжок"), ("inv", "Сумка с добычей"), ("carry", "Взять / положить добычу"),
             ("pickup", "Разделать / подобрать"), ("interact", "Говорить / продать"), ("shop", "Лавка"),
             ("skills", "Навыки"), ("tasks", "Задания"), ("help", "Обучение")]
KEY_LABEL = {"shift": "SHIFT", "tab": "TAB", "space": "ПРОБЕЛ", "control": "CTRL", "alt": "ALT", "enter": "ENTER",
             "backspace": "BACKSPACE", "caps lock": "CAPS"}


def key_label(k):
    return KEY_LABEL.get(k, k.upper())


DENSITY = [.45, .75, 1.0, 1.4]
SHADOW_RES = {1: 1024, 2: 2048, 3: 4096}
SHOT = {"bow": "bow", "rifle": "rifle", "shotgun": "shotgun", "sniper": "sniper"}
ZOOM = {"bow": .72, "rifle": .6, "shotgun": .85, "sniper": .22}
ADS_POS = {"bow": (-.15, -.11, .5), "rifle": (0, -.115, .42), "shotgun": (0, -.12, .42), "sniper": (0, -.1, .4)}


class Settings(dict):
    """Настройки игрока. ov - временные «потолки» качества от автоподстройки под 60 FPS: чтение возвращает их,
    а в файл (json.dump берёт сами значения словаря) всегда уходят выбранные игроком настройки."""

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.ov = {}

    def __getitem__(self, k):
        ov = self.__dict__.get("ov")
        if ov and k in ov:
            return ov[k]
        return dict.__getitem__(self, k)

    def get(self, k, d=None):
        ov = self.__dict__.get("ov")
        if ov and k in ov:
            return ov[k]
        return dict.get(self, k, d)


def load_settings():
    s = Settings(DEFAULTS)
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            s.update(json.load(f))
    except (OSError, ValueError):
        pass
    if not s["name"]:
        s["name"] = os.environ.get("USERNAME") or os.environ.get("USER") or getpass.getuser() or "Охотник"
    if not s.get("perf_v"):                       # обновление с оптимизацией: один раз ставим лёгкий пресет «Средняя»
        s.update(PRESETS[1][1])
        s.update(perf_v=1, auto_q=1)
    if s.get("perf_v", 0) < 2:                    # многопоточная отрисовка и сервер в отдельном процессе - теперь по умолчанию
        s.update(perf_v=2, mt=1, proc=1)
    if s.get("perf_v", 0) < 3:                    # VSync выключена: с ней FPS «прилипал» к 60/30/20 и не рос от снижения графики
        s.update(perf_v=3, vsync=0)
    if "--low" in sys.argv:
        s.update(PRESETS[0][1])
    s["tut_done"] = list(s.get("tut_done", []))
    s["keys"] = {**KEY_DEFAULTS, **{k: v for k, v in (s.get("keys") or {}).items() if k in KEY_DEFAULTS}}
    return s


def save_settings(s):
    try:
        os.makedirs(HOME, exist_ok=True)
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False)
    except OSError:
        pass


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))              # пакеты не отправляются, нужен только локальный адрес
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"


def font_candidates():
    """Способы указать шрифт движку - от самого надёжного к запасным."""
    src = os.path.join(HERE, "assets", "DejaVuSans.ttf")
    if not os.path.exists(src):
        return []
    out = ["DejaVuSans.ttf"]                         # по имени: движок сам ищет файл в папке игры (assets)
    path = src
    try:                                             # копия в ~/.how_to_hunt: путь без русских букв и пробелов
        os.makedirs(HOME, exist_ok=True)
        dst = os.path.join(HOME, "DejaVuSans.ttf")
        if not os.path.exists(dst) or os.path.getsize(dst) != os.path.getsize(src):
            shutil.copyfile(src, dst)
        path = dst
    except OSError:
        pass
    out.append(path)
    try:
        from panda3d.core import Filename
        out.append(Filename.from_os_specific(path).get_fullpath())
    except Exception:
        pass
    return out


def setup_font():
    """Подключает шрифт с кириллицей. Каждый вариант проверяется пробным текстом: если движок его не принял,
    пробуем следующий, а в крайнем случае остаётся встроенный шрифт Ursina (игра не падает)."""
    default = Text.default_font
    for cand in font_candidates():
        Text.default_font = cand
        try:
            destroy(Text(text="Проверка шрифта", parent=camera.ui))
            print("Шрифт:", cand)
            return
        except Exception as e:
            print("Шрифт не принят:", cand, "-", e)
    Text.default_font = default


# ====================================================================== сеть
class Net:
    def __init__(self, host, port, name):
        self.sock = socket.create_connection((host, port), timeout=6)
        self.sock.settimeout(None)
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.lock = threading.Lock()
        self.state, self.id, self.alive, self.seed = None, None, True, 0
        self.events, self.msgs = [], []
        self.send(t="join", name=name)
        threading.Thread(target=self.reader, daemon=True).start()

    def send(self, **m):
        try:
            self.sock.sendall((json.dumps(m, separators=(",", ":")) + "\n").encode())
        except OSError:
            self.alive = False

    def reader(self):
        try:
            for line in self.sock.makefile("r", encoding="utf-8"):
                m = json.loads(line)
                with self.lock:
                    if m["t"] == "w":
                        self.id, self.seed = m["id"], m.get("seed", 0)
                    elif m["t"] == "s":
                        self.state = m
                        self.events += m["ev"]
                        self.msgs += m["you"]["msgs"]
        except (OSError, ValueError):
            pass
        self.alive = False

    def close(self):
        self.alive = False
        try:
            self.sock.shutdown(socket.SHUT_RDWR)       # сразу сообщаем серверу, что мы ушли (иначе «призрак» висит онлайн)
        except OSError:
            pass
        try:
            self.sock.close()
        except OSError:
            pass


# ====================================================================== дерево навыков: раскладка
BRANCH_COL = {"marksman": (232, 92, 82), "pathfinder": (110, 205, 118), "trader": (255, 205, 80)}
ICON = dict(a1="✦", a2="➤", a3="◎", a4="✹", a5="★", b1="▲", b2="■", b3="☾", b4="✚", b5="★",
            c1="$", c2="%", c3="◆", c4="★")
TREE_X = {"marksman": -.55, "pathfinder": 0.0, "trader": .55}
TREE_NODE = dict(a1=(0, 0), a2=(-.12, 1), a3=(.12, 1), a4=(-.12, 2), a5=(0, 3),
                 b1=(0, 0), b2=(-.12, 1), b3=(.12, 1), b4=(-.12, 2), b5=(0, 3),
                 c1=(0, 0), c2=(-.12, 1), c3=(.12, 1), c4=(0, 2))
TREE_Y = [.255, .095, -.065, -.225]


def bearing_word(rel):
    """Где лагерь относительно взгляда: rel > 0 - справа."""
    a = abs(rel)
    if a < 25:
        return "впереди"
    if a > 155:
        return "сзади"
    side = "справа" if rel > 0 else "слева"
    return side if 65 <= a <= 115 else ("впереди " if a < 65 else "сзади ") + side
MSG_SOUND = (("Заказ принят", "skill"), ("Заказ выполнен", "levelup"), ("Заказ отменён", "error"), ("Подойдите к", "error"),
             ("У вас уже", "error"), ("Заказ ещё", "error"), ("Нет активного", "error"), ("Куплено", "buy"), ("Продано", "sell"), ("Навыки сброшены", "skill"), ("Навык", "skill"),
             ("Новый уровень", "levelup"), ("Нет ", "error"), ("Не хватает", "error"), ("Сумка", "error"),
             ("Эта добыча", "error"), ("Рядом нет", "error"), ("Сначала", "error"), ("Для сброса", "error"),
             ("Нечего", "error"), ("Это можно", "error"), ("Покупать", "error"), ("Нужен уровень", "error"))


HELP_PAGES = [
    ("Движение и обзор", [
        ("WASD", "Ходьба"), ("Shift", "Бег (быстрее, но во время бега целиться нельзя)"),
        ("Мышь", "Осмотреться и навести прицел"), ("ESC", "Пауза и настройки: графика, звук, управление"), ("F3", "Диагностика (FPS, туман, участки мира) для скриншота"),
        ("F1", "Открыть это обучение в любой момент"), ("H", "Показать или скрыть список заданий")]),
    ("Оружие и стрельба", [
        ("ЛКМ", "Выстрел (в лагере стрелять нельзя)"),
        ("ПКМ", "Прицелиться: зум и точность, но ходьба медленнее"),
        ("1 2 3 4", "Лук, винтовка, дробовик, снайперка"),
        ("Лук", "От бедра неточный - целься с ПКМ, стрела оттягивается"),
        ("Снайперка", "ПКМ включает оптику"), ("Дробовик", "Бьёт дробью - работает только вблизи")]),
    ("Добыча", [
        ("F", "Разделать тушу: мини-игра, от качества зависит цена"),
        ("[F]", "Золотая метка над тушей и точка на радаре"),
        ("Сумка", "Вместимость видна внизу слева, растёт навыком"),
        ("20 с", "Первые 20 секунд туша принадлежит только вам"),
        ("E", "В лагере: поговорить с NPC или продать добычу"),
        ("Радар", "Синий - лагерь, золотой - добыча, зелёный - друзья")]),
    ("Лагерь и NPC", [
        ("Лагерь", "Безопасная зона: здесь не стреляют"),
        ("Палатки", "Войдите внутрь - в них живут NPC"),
        ("E", "Поговорить (подсказка появляется внизу экрана)"),
        ("Макар", "Торговец: купить оружие, продать добычу"),
        ("Тамара", "Охотовед: заказы за деньги и опыт"),
        ("Игнат", "Следопыт: навыки, обучение, советы"),
        ("TAB", "Быстрая лавка в любой точке лагеря")]),
    ("Прогресс", [
        ("Опыт", "Даётся за добычу и выполненные заказы"),
        ("Уровень", "Каждый уровень - очко навыка (и бонус на 5, 10...)"),
        ("K", "Дерево навыков: три ветки, клик - изучить"),
        ("$500", "Сброс навыков, если ошиблись"),
        ("Чаща / Тундра", "Чаща: 3 уровень и победа над Секачом. Тундра: 6 уровень и победа над Шатуном"),
        ("Оружие", "Новое требует уровня и денег")]),
    ("Мир и погода", [
        ("Локации", "Лес → Чаща (3 ур. + Секач) → Тундра (6 ур. + Шатун). Путь дальше открывает победа над боссом"),
        ("Погода", "Меняется сама: дождь, гроза, туман, снег, метель"),
        ("Дождь", "В непогоду звери замечают вас хуже - охота скрытнее"),
        ("Гроза", "Вспышки молний и гром; осадки и вспышки можно выключить"),
        ("Время", "День, закат и ночь сменяют друг друга"),
        ("Звери", "В каждой локации свои; редкие стоят дороже всего")]),
    ("Сюжет", [
        ("Кордон", "Медвежий Угол: три года назад егерь Степан ушёл на север и пропал"),
        ("Хозяева", "В тайге объявились звери-хозяева; их держат за стенами старых арен"),
        ("Глава 1", "Новый егерь: добудь, продай, дорасти до 2 уровня"),
        ("Глава 2", "Голос в эфире: радар у Радиста Фёдора"),
        ("Глава 3-5", "Секач (лес), Шатун (чаща), Белый вожак (тундра) - и тайна Степана"),
        ("H", "Текущая глава видна в панели заданий; ролик - в меню паузы")]),
    ("Сумка и добыча в руках", [
        ("I", "Сумка с добычей: клетки с рисунком зверя, названием, качеством и ценой"),
        ("Клик", "Нажмите на клетку - зверь окажется у вас в руках; повторный клик - убрать обратно"),
        ("G", "Взять в руки последнюю добычу / положить то, что несёте"),
        ("Руки", "Пока несёте зверя, стрелять и целиться нельзя; 1-4 возвращают оружие, зверь уходит в сумку"),
        ("Вес", "Мелочь почти не замедляет, олень и кабан - на 20%, лось и медведь - на 30-35%"),
        ("Друзья", "Они видят зверя у вас на плечах"),
        ("Сокровища", "Трофеи из сундуков в руки не берутся - их продают в лагере (E)")]),
    ("Золотые звери и автомат", [
        ("Золотые", "Изредка зверь рождается золотым: он блестит, пуглив и виден на миникарте жёлтым"),
        ("Жетоны", "Добыл золотого зверя - 1-3 жетона (◆ рядом с деньгами)"),
        ("E", "Игровой автомат «Золотая тайга» в лагере между палатками: 2 жетона за прокрутку"),
        ("Скины", "20 скинов на 4 оружия: обычные, редкие, эпические, легендарные (золотые)"),
        ("Повтор", "Если такой скин уже есть - автомат вернёт 1 жетон"),
        ("◄ ►", "В коллекции автомата выберите скин для каждого оружия - его увидят и друзья")]),
    ("Боссы и сокровища", [
        ("Арена", "В каждой локации круглая арена босса со стеной и одними воротами; ворота закрыты силовым барьером"),
        ("Радар", f"Боевой радар (${RADAR_PRICE}, Радист Фёдор в лагере) открывает ворота и показывает боссов и арену на карте"),
        ("Боссы", "Лес - Матёрый Секач, Чаща - Медведь-шатун, Тундра - Белый вожак"),
        ("HP", "Босс атакует и откидывает. Здоровье внизу слева, вне боя восстанавливается"),
        ("Смерть", "Возвращение в лагерь через 3 с, добыча из сумки теряется"),
        ("Хищники", "Волки и медведи нападают сами; кабаны - если подойти вплотную, кабаны и лоси - если их ранить"),
        ("ПРОБЕЛ", "Прыжок (клавишу можно сменить в настройках)"),
        ("Трофей", "Убитого босса разделайте (F) - это самая дорогая добыча. Босс вернётся через 10 мин"),
        ("E", "Сундук в постройке: взлом замка (мини-игра), награда зависит от качества взлома"),
        ("Меню - ИГРАТЬ", "5 слотов сохранений: у каждого свой мир, охотник и прогресс")]),
    ("Интерфейс", [
        ("Слева", "Уровень, золото, опыт, очки навыков"),
        ("Справа", "Онлайн и адрес для друзей"),
        ("Внизу", "Слоты оружия и сумка с добычей"),
        ("Радар", "В правом нижнем углу"),
        ("ESC", "Настройки: тени, дальность, звук и многое другое"),
        ("Сохранение", "Прогресс хранится у хоста по имени охотника")]),
]
TASKS = [("move", "Пройдите вперёд (WASD)"), ("look", "Осмотритесь мышью"), ("sprint", "Побегите (Shift + W)"),
         ("aim", "Прицельтесь (держите ПКМ)"), ("leave", "Выйдите из лагеря"), ("shoot", "Выстрелите (ЛКМ)"),
         ("kill", "Добудьте зверя"), ("pick", "Разделайте добычу (F)"), ("sell", "Продайте добычу торговцу"),
         ("npc", "Поговорите с NPC в палатке (E)"), ("skill", "Изучите навык (K)")]
NPC_LINES = {
    "trader": ["Заходи, охотник! Ружья, патроны, а добычу куплю по честной цене.", "Свежая шкура - лучший товар. Что принёс?",
               "Торговля идёт, когда есть что продать. Показывай добычу."],
    "master": ["Лес полон зверя, а рук не хватает. Есть работа?", "Выполнишь заказ - получишь деньги и опыт.",
               "Охотовед всегда в деле. Берёшься за заказ?"],
    "tracker": ["Лес учит тех, кто слушает. Спрашивай, не стесняйся.", "Ветер, след, дыхание - вот и вся наука.",
                "Давно в этих краях? Покажу, как тут всё устроено."],
    "radio": ["Приём! Здесь Фёдор. Ловлю всё, что шевелится в этих краях.", "Арены боссов закрыты силовыми воротами. Без радара не войти.",
              "Радар - это глаза охотника. Купишь - увидишь боссов за стеной."],
}
TIPS = ["В дождь, туман и метель звери замечают тебя хуже - самое время подкрасться.",
        "Чаща открывается с 3 уровня: там густо, много лосей и кабанов.",
        "Боссы живут на круглых аренах за стеной. Ворота открывает только боевой радар - купи его у Радиста Фёдора.",
        "Выстрелы снаружи арены гасит щит. Босса можно бить только внутри - не заходи туда без хорошего ружья!",
        "Ищи постройки: в сундуках деньги, опыт и ценные трофеи. Сундук наполняется снова через 8 минут.",
        "Целься с ПКМ: стрела и пуля летят точнее, а зверь не успевает убежать.",
        "Звери замечают тебя издалека. Двигайся спокойно и целься заранее.",
        "Не оставляй добычу надолго: через три минуты туша исчезнет.",
        "Дробовик бьёт только вблизи, зато сразу дробью по цели.",
        "Заказы Охотоведа дают деньги и опыт. Бери заказ перед выходом на охоту.",
        "Каждый уровень даёт очко навыка. Загляни в дерево навыков (K).",
        "Сумка быстро забивается. Навык «Вместительная сумка» сильно выручает.",
        "В тундре водятся песцы, волки и медведи, но она открывается с 6 уровня."]


def bcol(branch, k=1.0):
    r, g, b = BRANCH_COL[branch]
    return Color(min(1, r / 255 * k), min(1, g / 255 * k), min(1, b / 255 * k), 1)


# ====================================================================== приложение
def animal_icon(parent, kind, x, y, box, gold=False):
    """Плоский значок зверя (вид сбоку, голова справа) из прямоугольников по тем же размерам, что у 3D-модели.
    kind=None - значок сокровища (ромб). box - примерная сторона значка в единицах интерфейса."""
    out = []
    if kind is None:
        for ang, col, sz in ((45, C(255, 196, 50), .75), (45, C(255, 236, 150), .4)):
            e = panel(parent, x, y, box * sz, box * sz, col, r=0, z=-.03)
            e.rotation_z = ang
            out.append(e)
        return out
    sp = w3.SPECS[kind]
    bw, bh, bl = sp["body"]
    hw, hh, hl = sp["head"]
    lw, lh = sp["leg"]
    col, dark = (C(244, 196, 58), C(196, 140, 24)) if gold else (C(*sp["col"]), C(*sp["dark"]))
    tail = sp.get("tail", .1)
    neck = sp.get("neck", False)
    head_v = lh + bh + hh * (.1 if neck else -.25)
    total_w = bl + hl * .9 + tail * .6
    top = max(lh + bh, head_v + hh * .5, lh + bh + sp.get("ears", (0, 0))[1]) + (hh * 1.4 if sp.get("antlers") else 0)
    s = box / max(total_w, top * 1.15, .3)
    ox = -(bl / 2 + hl * .45 - (bl + hl * .9 + tail * .6) / 2) * s              # центрируем по горизонтали
    oy = -top * s / 2

    def r(u, v, w, h, c, dz=0.0):
        e = panel(parent, x + ox + u * s, y + oy + v * s, max(w * s, .004), max(h * s, .004), c, r=0, z=-.03 - dz)
        out.append(e)
        return e
    for u in (bl / 2 - lw * .8, bl / 2 - lw * 2.2):                             # ноги: две передние, две задние
        r(u, lh / 2, lw, lh, dark, .001)
    for u in (-bl / 2 + lw * .8, -bl / 2 + lw * 2.2):
        r(u, lh / 2, lw, lh, dark, .001)
    r(0, lh + bh / 2, bl, bh, col, .002)                                        # туловище
    if sp.get("hump"):
        r(bl * .22, lh + bh + bh * .12, bl * .3, bh * .26, col, .002)
    if sp.get("wings"):
        r(-bl * .05, lh + bh * .55, bl * .6, bh * .55, dark, .003)
    if neck:
        r(bl / 2 - bl * .06, lh + bh + hh * .2, bl * .2, hh * 1.3, col, .002)  # шея
    r(bl / 2 + hl * .4, head_v, hl, hh, col, .003)                              # голова
    if sp.get("ears"):
        ew, eh = sp["ears"]
        r(bl / 2 + hl * .15, head_v + hh / 2 + eh / 2, max(ew, .03), eh, dark, .004)
        if kind in ("rabbit", "hare"):
            r(bl / 2 + hl * .35, head_v + hh / 2 + eh / 2, max(ew, .03), eh, dark, .004)
    if sp.get("comb"):
        r(bl / 2 + hl * .3, head_v + hh / 2 + .03, .05, .05, C(200, 40, 40), .004)
    if sp.get("beak"):
        r(bl / 2 + hl * .95, head_v - .005, .06, .035, C(230, 170, 50), .004)
    if sp.get("tusks"):
        r(bl / 2 + hl * .78, head_v - hh * .5, .06, .03, C(240, 236, 220), .004)
    if sp.get("antlers"):
        for k in range(3):
            r(bl / 2 + hl * (.1 + k * .17), head_v + hh * .5 + hh * (.55 - k * .1), .035, hh * (1.1 - k * .15), C(214, 196, 150), .004)
    if sp.get("palmate"):
        r(bl / 2 + hl * .25, head_v + hh * .75, hl * .75, hh * .6, C(198, 178, 130), .004)
    r(-bl / 2 - tail * .35, lh + bh * .78, tail * .8, max(.04, tail * .4), dark, .001)   # хвост
    r(bl / 2 + hl * .62, head_v + hh * .12, max(.025, hh * .12), max(.025, hh * .12), C(20, 18, 18), .005)   # глаз
    return out


class App:
    def __init__(self, base, S):
        self.base, self.S = base, S
        self.t, self.last = 0.0, pytime.perf_counter()
        self.mode, self.overlay = "menu", None
        self.net = self.conn_err = self.me = self.snap = None
        self.worlds, self.cur_loc, self.loading = {}, None, False
        self.animals, self.players, self.carc = {}, {}, {}
        self.tracers, self.floats = [], []
        self.feed, self.feed_dirty = [], True
        self.yaw = self.pitch = self.px = self.pz = 0.0
        self.last_in = self.local_cd = self.recoil = self.flash_t = self.hit_t = 0.0
        self.bob = self.ads_t = self.step_t = self.bird_t = self.banner_t = 0.0
        self.jump_y = self.vy = self.land = 0.0
        self.q_level, self.mist_off, self.prof_on, self.pacc, self.py_ms, self.frame_ms = 0, False, False, {}, 0.0, 0.0
        self.gpu = ""
        self.fps_n, self.fps_t, self.hostile_t = 0, 0.0, 0.0
        self.ads = False
        self.tree_hover = self.near_c = None
        self.menu_msg, self.shown_addr = "", ""
        self.vm = self.flash = self.vm_kind = None
        self.keystroke_ok, self.first_pos, self.icon_key = False, True, None
        self.play_t0, self.lock_t, self.bow_s1 = 0.0, 0.0, None
        self.fire, self.grass, self.npc_ents, self.near_n, self.dlg, self.dlg_line = None, None, {}, None, None, ""
        self.tip_i, self.help_i, self.tasks_on = 0, 0, True
        self.walked = self.look_acc = self.sprint_t = 0.0
        self.tut = set(S["tut_done"])

        self.sfx = sfx.Sfx(base, os.path.join(HOME, "sfx"), S["vol"] / 100, S["music"] / 100, S["amb"] / 100, S["master"] / 100)
        ui.CLICK[0] = lambda: self.sfx.play("click", .6)
        self.rig = Entity()
        self.pit_node = Entity(parent=self.rig)
        camera.parent = self.pit_node
        try:
            camera.clip_plane_near, camera.clip_plane_far = .15, 1100      # было .1 / 10000: в 13 раз точнее буфер глубины
        except Exception:
            pass
        srv.migrate_legacy(self.S["name"])
        self.gpu = self.detect_gpu()
        print("Видеокарта:", self.gpu or "не определена")
        self.sky = fx.GradientSky()
        self.build_lights()
        self.atmo = fx.Atmosphere(self.sky, self.sun, self.amb)
        self.particles = fx.Particles(S["particles"])
        self.smoke = fx.Particles(S["particles"], model="sphere", n=40)
        self.critters = fx.Critters()
        self.chests, self.labels, self.near_ch, self.boss_rec = {}, [], None, None
        self.flash_red = self.spark_t = 0.0
        self.arrows, self.shells, self.decals = [], [], []
        self.shake = self.aim_toggle = 0.0
        self.butch = None
        self.lock, self.jam, self.banks, self.server = None, {}, [], None
        self.server_proc, self.server_token = None, None
        self.arena, self.gates, self.gate_hint_t = None, [], 0.0
        self.mist_t = self.mist_acc = self.hud_acc = 0.0
        self.mist_key = None
        self.del_arm, self.new_idx = None, 0
        self.cull_t = 0.0
        self.precip, self.bolt = fx.Precip(), fx.Lightning()
        self.wx, self.thunder_q, self.dying = "clear", [], []
        self.build_world("forest")
        self.enter_location("forest")
        self.menu_deer = []
        for i, (dx, dz) in enumerate(((8, -12), (-12, -14), (16, -20))):
            d = w3.make_animal("deer" if i != 2 else "wolf")
            d.position = (CAMP[0] + dx, 0, CAMP[1] + dz)
            d.rotation_y = 40 + i * 70
            self.menu_deer.append(d)
        self.ui = Entity(parent=camera.ui)
        self.dim = panel(self.ui, 0, 0, 3, 1.4, C(0, 0, 0, 150), r=0, z=.3)
        self.build_vignette()
        self.build_menu()
        self.build_hud()
        self.build_camp()
        self.build_tree()
        self.build_pause()
        self.build_settings()
        self.build_help()
        self.build_dialog()
        self.build_tasks()
        self.build_butcher()
        self.build_lock()
        self.build_cine()
        self.build_casino()
        self.build_inv()
        self.loading_txt = label(self.ui, "Загрузка...", 0, 0, 2.2, GOLD)
        self.loading_txt.enabled = False
        self.show_menu("main")
        self.setup_keystrokes()
        self.driver = Entity()                 # движок вызывает update/input именно у Entity
        self.driver.update = self.update
        self.driver.input = self.input
        self.quiet_t = 0.0
        for name, kind in (("music", "music"), ("wind", "amb"), ("fire", "amb"), ("rain", "amb")):
            self.sfx.loop(name, kind)
        self.apply_live()

    # ---------------------------------------------------------------- инициализация
    def build_lights(self):
        self.sun = self.amb = None
        if w3.SHADER is None:
            return
        try:
            from ursina.lights import AmbientLight, DirectionalLight
            res = SHADOW_RES[self.S["shadows"]]
            self.sun = DirectionalLight(shadows=True, shadow_map_resolution=(res, res))
            self.sun.look_at(Vec3(1, -1.3, .8))
            self.shadow_box = Entity(model="wireframe_cube", scale=60 if self.S["shadows"] <= 1 else 90, visible=False)
            try:
                self.amb = AmbientLight(color=C(125, 130, 140))
            except Exception:
                self.amb = None
        except Exception as e:
            print("Освещение недоступно, включаю режим без теней:", e)
            w3.SHADER, w3.BAKE = None, True

    def setup_keystrokes(self):
        """Ввод текста с любой раскладки (в т.ч. русской) через keystroke-события Panda3D."""
        try:
            self.base.buttonThrowers[0].node().setKeystrokeEvent("keystroke")
            self.base.accept("keystroke", self.on_keystroke)
            self.keystroke_ok = True
        except Exception as e:
            print("keystroke недоступен, ввод только латиницей:", e)

    def on_keystroke(self, key):
        if ACTIVE[0] is not None:
            ACTIVE[0].type(chr(key) if isinstance(key, int) else str(key))

    def build_world(self, loc):
        self.worlds[loc] = w3.build_location(loc)
        self.freeze_heap()

    @staticmethod
    def freeze_heap():
        """Миллионы объектов мира (вершины, цвета) больше не нужно проверять сборщику мусора Python -
        иначе он раз в несколько секунд перебирает их все и игра «дёргается»."""
        try:
            gc.collect()
            gc.freeze()
        except Exception:
            pass

    def quiet_static(self, budget=None):
        """Ursina каждый кадр перебирает все объекты и проверяет, нет ли у них своей логики. Статичным объектам
        (мир, панели, надписи, частицы) ставим ignore - движок их пропускает. Кнопки и объекты с логикой не трогаем.
        budget - сколько объектов проверить за один вызов (по кадрам, чтобы не было рывка); None - все сразу."""
        try:
            from ursina import scene as sc
            if budget is None or getattr(self, "_qs", None) is None:
                self._qs, self._qi = list(sc.entities), 0
        except Exception:
            return
        ents, i = self._qs, self._qi
        end = len(ents) if budget is None else min(len(ents), i + budget)
        for e in ents[i:end]:
            try:
                if e is self.driver or e.ignore or getattr(e, "collider", None) is not None:
                    continue
                if hasattr(e, "update") or hasattr(e, "input") or getattr(e, "scripts", None) or getattr(e, "animations", None):
                    continue
                e.ignore = True
            except Exception:
                pass
        self._qi = end
        if end >= len(ents):
            self._qs = None

    def enter_location(self, loc):
        for k, r in self.worlds.items():
            r.enabled = (k == loc)
        self.cur_loc = loc
        self.fire = getattr(self.worlds[loc], "hth_fire", None)
        self.grass = getattr(self.worlds[loc], "hth_grass", None)
        self.npc_ents = getattr(self.worlds[loc], "hth_npcs", {})
        self.chests = getattr(self.worlds[loc], "hth_chests", {})
        self.labels = getattr(self.worlds[loc], "hth_labels", [])
        self.banks = getattr(self.worlds[loc], "hth_banks", [])
        self.arena = getattr(self.worlds[loc], "hth_arena", None)
        self.gates = getattr(self.worlds[loc], "hth_gates", [])
        self.mist_key = None

    def build_vignette(self):
        """Затемнение по краям: радиальный градиент, нарисованный Pillow."""
        self.vig = Entity(parent=camera.ui)
        try:
            from PIL import Image
            from ursina import Texture
            w, h = 256, 144
            img = Image.new("RGBA", (w, h))
            px = img.load()
            for y in range(h):
                for x in range(w):
                    d = max(0.0, (math.hypot((x / (w - 1) - .5) * 1.8, (y / (h - 1) - .5) * 2) - .55) / .75)
                    px[x, y] = (0, 0, 0, int(min(1.0, d * d) * 165))
            tex = Texture(img)
            try:
                tex.filtering = "bilinear"
            except Exception:
                pass
            Entity(parent=self.vig, model="quad", texture=tex, scale=(2.0, 1.12), position=(0, 0, .45))
        except Exception as e:
            print("Виньетка недоступна:", e)
        self.vig.enabled = False

    def apply_live(self):
        S = self.S
        try:
            window.fps_counter.enabled = False
        except Exception:
            pass
        self.sfx.set_volumes(S["vol"] / 100, S["music"] / 100, S["amb"] / 100, S["master"] / 100)
        self.vig.enabled = bool(S["vignette"]) and self.mode == "play"
        try:                                                   # ограничение FPS (экономит видеокарту и батарею)
            from panda3d.core import ClockObject
            gc = ClockObject.getGlobalClock()
            if S["fps_cap"]:
                gc.setMode(ClockObject.MLimited)
                gc.setFrameRate(S["fps_cap"])
            else:
                gc.setMode(ClockObject.MNormal)
        except Exception:
            pass

    # ---------------------------------------------------------------- главное меню
    def build_menu(self):
        ui_ = self.ui
        self.pages = {}
        p = self.pages["main"] = Entity(parent=ui_)
        panel(p, -.56, 0, .96, 1.2, C(2, 8, 5, 185), r=0, z=.2)
        panel(p, -.085, 0, .008, 1.2, GOLD, r=0, z=.19)
        for dx, dy, col in ((.006, -.006, C(0, 0, 0, 210)), (0, 0, GOLD)):
            label(p, "HOW TO HUNT", -.84 + dx, .36 + dy, 5.4, col, left=True)
        label(p, "Охотничье приключение  •  мультиплеер  •  3D", -.84, .27, 1.2, CREAM, left=True)
        panel(p, -.56, .23, .56, .004, GOLD, r=0)
        label(p, "Имя охотника (для игры у друга)", -.84, .17, 1.0, DIM, left=True)
        self.name_box = TextBox(p, -.56, .11, .56, .075, self.S["name"], limit=14)
        UIButton(p, "ИГРАТЬ", -.56, 0, .56, .09, self.open_slots, size=1.7)
        UIButton(p, "ПОДКЛЮЧИТЬСЯ", -.56, -.1, .56, .09, lambda: self.show_menu("connect"), C(40, 84, 120), 1.4)
        UIButton(p, "НАСТРОЙКИ", -.56, -.2, .56, .09, self.open_menu_settings, C(70, 70, 82), 1.4)
        UIButton(p, "ОБУЧЕНИЕ", -.56, -.3, .56, .09, self.open_help, C(110, 80, 40), 1.4)
        UIButton(p, "ВЫХОД", -.56, -.4, .56, .09, application.quit, C(120, 50, 46), 1.4)
        label(p, "WASD · Shift · ЛКМ · ПКМ · F · E · TAB · K · F1 - все клавиши в обучении",
              -.84, -.49, .72, DIM, left=True)
        self.menu_err = label(p, "", -.84, -.455, 1.0, RED, left=True)

        p = self.pages["connect"] = Entity(parent=ui_)
        panel(p, -.56, 0, .96, 1.2, C(2, 8, 5, 185), r=0, z=.2)
        panel(p, -.085, 0, .008, 1.2, GOLD, r=0, z=.19)
        label(p, "Подключение к другу", -.84, .30, 2.6, GOLD, left=True)
        label(p, "Адрес сервера (IP или IP:порт)", -.84, .17, 1.0, DIM, left=True)
        self.addr_box = TextBox(p, -.56, .11, .56, .075, self.S["addr"], limit=28, addr=True)
        UIButton(p, "ПОДКЛЮЧИТЬСЯ", -.56, -.02, .56, .09, lambda: self.go(False), size=1.4)
        UIButton(p, "НАЗАД", -.56, -.13, .56, .09, lambda: self.show_menu("main"), C(70, 70, 82), 1.3)
        label(p, "Адрес друга виден у него в игре справа вверху.", -.84, -.23, .9, DIM, left=True)
        self.build_slots()

    # ---------------------------------------------------------------- слоты сохранений
    def build_slots(self):
        ui_ = self.ui
        p = self.pages["slots"] = Entity(parent=ui_)
        panel(p, -.56, 0, .96, 1.2, C(2, 8, 5, 185), r=0, z=.2)
        panel(p, -.085, 0, .008, 1.2, GOLD, r=0, z=.19)
        label(p, "СОХРАНЕНИЯ", -.84, .5, 2.4, GOLD, left=True)
        self.slot_ui = []
        for i in range(srv.SLOT_COUNT):
            y = .34 - i * .165
            frame(p, -.56, y, .9, .14, C(18, 30, 24, 235), r=.02, z=.1)
            t1 = label(p, "", -1.0, y + .033, 1.2, CREAM, left=True)
            t2 = label(p, "", -1.0, y - .03, .85, DIM, left=True)
            bp = UIButton(p, "", -.3, y, .22, .075, lambda i=i: self.slot_play(i), C(60, 120, 70), 1.0)
            bd = UIButton(p, "×", -.135, y, .06, .075, lambda i=i: self.slot_delete(i), C(120, 50, 46), 1.4)
            self.slot_ui.append((t1, t2, bp, bd))
        UIButton(p, "НАЗАД", -.56, -.5, .5, .08, lambda: self.show_menu("main"), C(70, 70, 82), 1.3)
        n = self.pages["new"] = Entity(parent=ui_)
        panel(n, -.56, 0, .96, 1.2, C(2, 8, 5, 185), r=0, z=.2)
        panel(n, -.085, 0, .008, 1.2, GOLD, r=0, z=.19)
        label(n, "Новая игра", -.84, .30, 2.6, GOLD, left=True)
        label(n, "Имя охотника", -.84, .17, 1.0, DIM, left=True)
        self.new_name = TextBox(n, -.56, .11, .56, .075, self.S["name"], limit=14)
        UIButton(n, "НАЧАТЬ ИГРУ", -.56, -.02, .56, .09, self.slot_start_new, size=1.5)
        UIButton(n, "НАЗАД", -.56, -.13, .56, .09, self.open_slots, C(70, 70, 82), 1.3)
        label(n, "Мир создаётся случайно и навсегда остаётся в этом слоте.", -.84, -.23, .85, DIM, left=True)

    def open_slots(self):
        self.del_arm = None
        self.show_menu("slots")
        self.refresh_slots()

    def refresh_slots(self):
        for i, (t1, t2, bp, bd) in enumerate(self.slot_ui):
            info = srv.read_slot(i)
            if info:
                set_text(t1, f"Слот {i + 1}  -  {info['owner']}   ур. {info['level']}")
                when = pytime.strftime("%d.%m.%Y %H:%M", pytime.localtime(info["last"])) if info["last"] else "-"
                set_text(t2, f"${info['gold']}   ·   {srv.LOCS.get(info['loc'], srv.LOCS['forest'])['name']}   ·   {when}")
                bp.set("ИГРАТЬ", col=C(60, 120, 70))
                bd.root.enabled = True
                bd.set("?" if self.del_arm == i else "×", col=C(190, 60, 50) if self.del_arm == i else C(120, 50, 46))
            else:
                set_text(t1, f"Слот {i + 1}  -  пусто")
                set_text(t2, "Новый охотник и новый случайный мир")
                bp.set("НОВАЯ ИГРА", col=C(40, 84, 120))
                bd.root.enabled = False

    def slot_play(self, i):
        if srv.read_slot(i):
            self.S["last_slot"] = i
            save_settings(self.S)
            self.go(True, slot=i)
        else:
            self.new_idx = i
            self.show_menu("new")

    def slot_delete(self, i):
        if self.del_arm == i:                                  # второй щелчок - подтверждение
            srv.delete_slot(i)
            self.del_arm = None
        else:
            self.del_arm = i
        self.refresh_slots()

    def slot_start_new(self):
        name = self.new_name.value.strip() or "Охотник"
        srv.new_slot(self.new_idx, name)
        self.intro_pending = True                              # новая игра начинается со вступительного ролика
        self.S["last_slot"] = self.new_idx
        save_settings(self.S)
        self.go(True, slot=self.new_idx, name=name)

    def show_menu(self, page):
        ACTIVE[0] = None
        for k, e in self.pages.items():
            e.enabled = (k == page)
        self.settings_ui.enabled = False
        self.help_ui.enabled = False
        self.dim.enabled = False
        self.loading_txt.enabled = False
        set_text(self.menu_err, self.menu_msg)
        self.menu_msg = ""

    # ---------------------------------------------------------------- настройки графики и звука
    def build_settings(self):
        st = self.settings_ui = Entity(parent=self.ui)
        frame(st, 0, 0, 1.78, .98, PANEL2, z=.1)
        label(st, "НАСТРОЙКИ", 0, .445, 2.4, GOLD)
        self.tab_btns, self.tab_pages, self.set_vals, self.key_vals = {}, {}, {}, {}
        self.rebind = None
        for i, (tid, title, opts) in enumerate(TABS):
            self.tab_btns[tid] = UIButton(st, title, -.36 + i * .36, .375, .33, .06, lambda t=tid: self.set_tab(t), C(46, 70, 58), 1.1)
            pg = self.tab_pages[tid] = Entity(parent=st)
            y0 = .29
            if tid == "gfx":
                label(pg, "Пресет графики", -.84, y0, 1.05, GOLD, left=True)
                UIButton(pg, "◄", -.40, y0, .05, .05, lambda: self.cycle_preset(-1), C(60, 70, 66), .9)
                self.t_preset = label(pg, "", -.25, y0, 1.05, GOLD)
                UIButton(pg, "►", -.10, y0, .05, .05, lambda: self.cycle_preset(1), C(60, 70, 66), .9)
                y0 -= .07
            per = 9 if tid == "gfx" else len(opts)
            for j, (key, title2, choices, restart) in enumerate(opts):
                col, r = divmod(j, per)
                cx, y = -.44 + col * .88, y0 - r * .066
                label(pg, title2 + (" *" if restart else ""), cx - .40, y, .92, CREAM, left=True)
                UIButton(pg, "◄", cx + .06, y, .05, .05, lambda k=key: self.cycle(k, -1), C(60, 70, 66), .9)
                self.set_vals[key] = label(pg, "", cx + .21, y, .92, GOLD)
                UIButton(pg, "►", cx + .36, y, .05, .05, lambda k=key: self.cycle(k, 1), C(60, 70, 66), .9)
            if tid == "ctl":                                   # переназначение клавиш - правая колонка
                label(pg, "Клавиши (нажмите кнопку и затем нужную клавишу)", .06, y0 + .005, .8, DIM, left=True)
                for j, (act, nm) in enumerate(KEY_NAMES):
                    y = y0 - .04 - j * .046
                    label(pg, nm, .06, y, .85, CREAM, left=True)
                    self.key_vals[act] = UIButton(pg, "", .7, y, .26, .04, lambda a_=act: self.start_rebind(a_), C(46, 60, 54), .85)
                UIButton(pg, "КЛАВИШИ ПО УМОЛЧАНИЮ", -.44, -.2, .5, .055, self.reset_keys, C(90, 60, 40), .85)
            if tid == "snd":
                label(pg, "Громкость меняется сразу. «Окружение» - ветер, дождь, гроза и костёр.", -.84, y0 - .32, .85, DIM, left=True)
            pg.enabled = False
        self.t_restart = label(st, "* применяется после перезапуска игры", -.84, -.36, .85, DIM, left=True)
        UIButton(st, "ГОТОВО", 0, -.43, .4, .065, self.close_settings, size=1.3)
        st.enabled = False
        self.set_tab("gfx")
        self.refresh_settings()

    def set_tab(self, tid):
        self.cur_tab = tid
        self.rebind = None
        for k, pg in self.tab_pages.items():
            pg.enabled = k == tid
            self.tab_btns[k].set(col=C(120, 90, 30) if k == tid else C(46, 70, 58))
        self.t_restart.enabled = tid == "gfx"
        self.refresh_settings()

    def refresh_settings(self):
        for key, title, choices, restart in OPTIONS:
            lab = dict(choices).get(self.S[key], str(self.S[key]))
            set_text(self.set_vals[key], lab)
        name = next((n for n, d in PRESETS if all(self.S[k] == v for k, v in d.items())), "Свой")
        set_text(self.t_preset, name)
        for act, b in self.key_vals.items():
            b.set("нажмите клавишу..." if self.rebind == act else key_label(self.S["keys"][act]),
                  col=C(150, 110, 40) if self.rebind == act else C(46, 60, 54))

    def start_rebind(self, act):
        self.rebind = act
        self.refresh_settings()

    def finish_rebind(self, key):
        """Назначает клавишу; если она уже занята другим действием - меняет их местами."""
        key = {"left shift": "shift", "right shift": "shift", "left control": "control", "right control": "control",
               "left alt": "alt", "right alt": "alt"}.get(key, key)
        act, keys = self.rebind, self.S["keys"]
        self.rebind = None
        if key != "escape":
            other = next((a for a, k in keys.items() if k == key and a != act), None)
            if other:
                keys[other] = keys[act]
            keys[act] = key
            save_settings(self.S)
        self.refresh_settings()

    def reset_keys(self):
        self.S["keys"] = dict(KEY_DEFAULTS)
        save_settings(self.S)
        self.refresh_settings()

    def cycle(self, key, d):
        vals = [v for v, _ in next(c for k, _, c, _ in OPTIONS if k == key)]
        i = vals.index(self.S[key]) if self.S[key] in vals else 0
        self.S[key] = vals[(i + d) % len(vals)]
        save_settings(self.S)
        self.refresh_settings()
        self.apply_live()

    def cycle_preset(self, d):
        i = next((j for j, (n, dct) in enumerate(PRESETS) if all(self.S[k] == v for k, v in dct.items())), 2)
        self.S.update(PRESETS[(i + d) % len(PRESETS)][1])
        save_settings(self.S)
        self.refresh_settings()
        self.apply_live()

    def open_menu_settings(self):
        for e in self.pages.values():
            e.enabled = False
        self.settings_ui.enabled = True
        self.dim.enabled = True
        self.refresh_settings()

    def close_settings(self):
        self.settings_ui.enabled = False
        if self.mode == "play":
            self.set_overlay("pause")
        else:
            self.show_menu("main")

    # ---------------------------------------------------------------- HUD
    def build_hud(self):
        h = self.hud = Entity(parent=self.ui)
        frame(h, -.69, .415, .39, .14, PANEL, r=.025)
        Entity(parent=h, model="circle", scale=.092, position=(-.845, .415, -.01), color=GOLD)
        Entity(parent=h, model="circle", scale=.074, position=(-.845, .415, -.02), color=C(18, 38, 28))
        self.t_lvl = label(h, "1", -.845, .415, 1.7, GOLD, z=-.03)
        Entity(parent=h, model="circle", scale=.028, position=(-.775, .452, -.02), color=GOLD)
        self.t_gold = label(h, "0", -.752, .452, 1.7, GOLD, left=True)
        self.t_xp = label(h, "", -.775, .405, .8, DIM, left=True)
        self.t_tok = label(h, "", -.6, .405, .8, C(255, 214, 80), left=True)
        self.t_carry = label(h, "", 0, -.255, 1.0, GOLD)
        panel(h, -.645, .372, .27, .013, C(30, 44, 36), r=.006, z=-.005)
        self.xp_bar = panel(h, -.78, .372, .27, .013, C(110, 210, 130), r=.006, z=-.01)
        self.xp_bar.origin = (-.5, 0)
        self.t_pts = label(h, "", -.87, .325, 1.0, GOLD, left=True)

        frame(h, .715, .405, .34, .18, PANEL, r=.025)
        self.t_loc = label(h, "", .56, .465, 1.0, GOLD, left=True)
        self.t_players = Text(text="", parent=h, origin=(-.5, .5), position=(.56, .435, -.02), scale=.95, color=CREAM)
        self.t_addr = label(h, "", .56, .335, .72, DIM, left=True)
        self.t_fps = label(h, "", .56, .287, .82, C(120, 230, 120), left=True)
        self.t_gpu = label(h, "", .56, .252, .72, DIM, left=True)
        self.t_prof = label(h, "", .56, .21, .72, C(190, 220, 255), left=True)

        frame(h, -.69, -.455, .39, .075, PANEL, r=.025)
        Entity(parent=h, model="circle", scale=.03, position=(-.855, -.455, -.02), color=C(150, 112, 62))
        self.t_bag = label(h, "", -.83, -.455, 1.15, CREAM, left=True)

        self.slots = []
        for i, k in enumerate(WEAPONS):
            x = -.255 + i * .17
            bg = panel(h, x, -.45, .16, .095, PANEL, r=.015)
            bar = panel(h, x - .075, -.487, .15, .007, C(255, 130, 80), r=.003, z=-.01)
            bar.origin = (-.5, 0)
            icon = weapon_icon(h, k, x, -.43, DIM)
            label(h, str(i + 1), x - .067, -.41, .8, DIM, left=True)
            nm = label(h, WEAPONS[k]["name"], x, -.468, .68, CREAM)
            self.slots.append((bg, bar, icon, nm))

        self.t_hint = label(h, "", 0, .47, 1.15, GOLD)
        self.feed_txt = [label(h, "", -.87, -.355 + i * .034, 1.0, C(255, 244, 200), left=True) for i in range(6)]
        self.xlines = [panel(h, dx, dy, w, hh, C(255, 255, 255, 215), r=0, z=-.02)
                       for dx, dy, w, hh in ((.024, 0, .018, .004), (-.024, 0, .018, .004), (0, .024, .004, .018), (0, -.024, .004, .018))]
        self.xdot = panel(h, 0, 0, .006, .006, C(255, 80, 60, 240), r=0, z=-.02)
        self.xdot.enabled = False
        self.hitmark = label(h, "X", 0, 0, 2.6, WHITE)
        self.hitmark.enabled = False
        self.cd_bar = panel(h, -.04, -.055, .08, .006, C(255, 140, 80, 230), r=.003, z=-.02)
        self.cd_bar.origin = (-.5, 0)
        self.t_ads = label(h, "ПКМ - прицелиться", 0, -.085, .9, DIM)
        frame(h, -.69, -.385, .39, .045, PANEL, r=.02)
        label(h, "HP", -.865, -.385, .85, C(255, 120, 110), left=True)
        panel(h, -.66, -.385, .29, .016, C(60, 24, 22), r=.008, z=-.005)
        self.hp_bar = panel(h, -.805, -.385, .29, .016, C(220, 60, 50), r=.008, z=-.01)
        self.hp_bar.origin = (-.5, 0)
        self.t_hp = label(h, "100", -.5, -.385, .85, CREAM, left=True)
        self.dbg = Text(parent=self.ui, text="", position=(-.86, .43), origin=(-.5, .5), scale=.8, color=C(200, 255, 200))
        self.dbg.enabled = False
        self.boss_ui = Entity(parent=h)
        frame(self.boss_ui, 0, .395, .7, .07, PANEL, r=.02)
        self.t_boss = label(self.boss_ui, "", 0, .41, 1.05, C(255, 110, 90))
        panel(self.boss_ui, 0, .382, .6, .014, C(60, 20, 18), r=.007, z=-.005)
        self.boss_bar = panel(self.boss_ui, -.3, .382, .6, .014, C(230, 50, 40), r=.007, z=-.01)
        self.boss_bar.origin = (-.5, 0)
        self.boss_ui.enabled = False
        self.red = panel(self.ui, 0, 0, 2.2, 1.3, C(200, 0, 0, 0), r=0, z=.42)
        self.death_ui = Entity(parent=self.ui)
        panel(self.death_ui, 0, 0, 2.2, 1.3, C(60, 0, 0, 170), r=0, z=.35)
        label(self.death_ui, "ВЫ ПОГИБЛИ", 0, .06, 4.5, C(255, 90, 80))
        self.t_death = label(self.death_ui, "", 0, -.04, 1.4, CREAM)
        self.death_ui.enabled = False
        self.banner = label(h, "", 0, .27, 5.0, GOLD)
        self.banner.enabled = False

        self.prompt = Entity(parent=h)
        frame(self.prompt, 0, -.31, .52, .075, PANEL, r=.025)
        panel(self.prompt, -.215, -.31, .05, .05, GOLD, r=.01, z=-.02)
        self.t_key = label(self.prompt, "F", -.215, -.31, 1.5, C(20, 30, 24), z=-.04)
        self.t_prompt = label(self.prompt, "", -.17, -.31, 1.15, CREAM, left=True)
        self.prompt.enabled = False

        rx, ry = .76, -.3                                              # радар
        Entity(parent=h, model="circle", scale=.27, position=(rx, ry, -.004), color=ui.EDGE)
        Entity(parent=h, model="circle", scale=.255, position=(rx, ry, -.005), color=C(8, 20, 14, 215))
        Entity(parent=h, model="circle", scale=.012, position=(rx, ry, -.02), color=WHITE)
        panel(h, rx, ry + .02, .003, .03, WHITE, r=0, z=-.02)
        self.radar_c = (rx, ry)
        self.blips = [Entity(parent=h, model="circle", scale=.014, position=(rx, ry, -.015), enabled=False) for _ in range(30)]
        label(h, "лагерь · добыча · друзья", rx, ry - .15, .6, DIM)
        self.t_arena = label(h, "", rx, ry - .19, .85, C(255, 150, 60))

        sc = self.scope = Entity(parent=self.ui)                     # прицел снайперки
        dark = C(0, 0, 0, 255)
        for sx in (-1, 1):
            panel(sc, sx * .69, 0, .5, 1.3, dark, r=0, z=-.05)
        for i in range(40):
            a = i * 2 * math.pi / 40
            Entity(parent=sc, model="circle", scale=.36, position=(math.cos(a) * .625, math.sin(a) * .625, -.05), color=dark)
        panel(sc, 0, 0, .88, .003, C(0, 0, 0, 230), r=0, z=-.06)
        panel(sc, 0, 0, .003, .88, C(0, 0, 0, 230), r=0, z=-.06)
        Entity(parent=sc, model="circle", scale=.008, position=(0, 0, -.07), color=RED)
        sc.enabled = False
        h.enabled = False

    def refresh_feed(self):
        self.feed = [f for f in self.feed if self.t - f[0] < 7][-6:]
        for i, tx in enumerate(self.feed_txt):
            set_text(tx, self.feed[len(self.feed) - 1 - i][1] if i < len(self.feed) else "")

    def update_hud(self, dt):
        me, S = self.me, self.S
        set_text(self.t_lvl, str(me["lv"]))
        set_text(self.t_gold, str(me["gold"]))
        set_text(self.t_xp, f"XP {me['xp'] - me['cur']} / {me['nxt'] - me['cur']}")
        self.xp_bar.scale_x = .27 * max(.001, min(1, (me["xp"] - me["cur"]) / max(1, me["nxt"] - me["cur"])))
        if me["pts"] > 0:
            set_text(self.t_pts, f"Очки навыков: {me['pts']}  (K)")
            self.t_pts.color = GOLD if int(self.t * 2) % 2 == 0 else CREAM
        else:
            set_text(self.t_pts, "")
        set_text(self.t_loc, f"{LOCS[self.cur_loc]['name']} · {fx.WX_RU.get(self.wx, '')}   онлайн: {self.snap['n']}")
        set_text(self.t_players, "\n".join(("• " if p[0] == self.net.id else "  ") + p[1] for p in self.snap["pl"][:6]))
        set_text(self.t_addr, f"Адрес для друзей: {self.shown_addr}")
        set_text(self.t_bag, f"Добыча: {len(me['bag'])}/{me['cap']}  (I)    ${me['bagval']}")
        self.t_bag.color = RED if len(me["bag"]) >= me["cap"] else CREAM
        wk = me["w"]
        key = (tuple(me["owned"]), wk)
        for i, k in enumerate(WEAPONS):
            bg, bar, icon, nm = self.slots[i]
            if key != self.icon_key:
                owned, cur = k in me["owned"], wk == k
                bg.color = C(60, 90, 40, 235) if cur else PANEL
                nm.color = CREAM if owned else C(100, 108, 102)
                for q in icon:
                    q.color = GOLD if cur else (CREAM if owned else C(80, 88, 84))
            bar.scale_x = .15 * (min(1, self.local_cd / (WEAPONS[k]["cd"] * me["cdm"])) if wk == k else 0) + .0001
        self.icon_key = key
        self.cd_bar.scale_x = .08 * min(1, self.local_cd / max(.1, WEAPONS[wk]["cd"] * me["cdm"])) + .0001
        if me["camp"]:
            set_text(self.t_hint, "TAB - лавка     E - продать добычу     K - навыки")
        else:
            rel = (math.degrees(math.atan2(CAMP[0] - self.px, CAMP[1] - self.pz)) - self.yaw + 180) % 360 - 180
            set_text(self.t_hint, f"Лагерь: {int(math.hypot(CAMP[0] - self.px, CAMP[1] - self.pz))} м, {bearing_word(rel)}")
        scoped = wk == "sniper" and self.ads_t > .8
        self.scope.enabled = scoped
        for q in self.xlines:
            q.enabled = not self.ads and not scoped
        self.xdot.enabled = self.ads and not scoped
        self.cd_bar.enabled = not scoped
        self.t_ads.enabled = (not self.ads) and (self.t - self.play_t0 < 90)
        if self.hit_t > 0:
            self.hit_t -= dt
            self.hitmark.enabled = self.hit_t > 0
        if self.banner_t > 0:
            self.banner_t -= dt
            self.banner.enabled = self.banner_t > 0
            self.banner.color = Color(1, .82, .29, min(1, self.banner_t))
            self.banner.y = .27 + (2.6 - self.banner_t) * .02
        set_text(self.t_tok, f"◆ {me.get('tok', 0)}")
        cit = self.carry_item()
        if cit:
            kk = item_parts(cit)[0]
            set_text(self.t_carry, f"В РУКАХ: {ANIMALS[kk]['name']}   ·   скорость {int(CARRY_SLOW.get(kk, .85) * 100)}%   ·   G - положить")
        else:
            set_text(self.t_carry, "")
        hp = me.get("hp", 100)
        self.hp_bar.scale_x = .29 * max(.001, hp / 100)
        set_text(self.t_hp, str(int(hp)))
        self.flash_red = max(0.0, self.flash_red - dt * 1.5)
        self.red.color = Color(.8, 0, 0, self.flash_red * .45 + (.12 if 0 < hp < 30 else 0) * (.6 + .4 * math.sin(self.t * 6)))
        dead = me.get("dead", 0)
        self.death_ui.enabled = dead > 0
        if dead > 0:
            set_text(self.t_death, f"Возвращение в лагерь через {math.ceil(dead)} с")
        br = self.boss_rec
        in_arena = self.arena is not None and math.hypot(self.arena["x"] - self.px, self.arena["z"] - self.pz) < ARENA_R
        show = br is not None and (in_arena or me.get("radar")) and math.hypot(br["x"] - self.px, br["z"] - self.pz) < 75
        self.boss_ui.enabled = show
        if show:
            mx = ANIMALS[br["k"]]["hp"]
            set_text(self.t_boss, f"{ANIMALS[br['k']]['name'].upper()}   {int(max(0, br['hp']))} / {mx}")
            self.boss_bar.scale_x = .6 * max(.001, br["hp"] / mx)
        nc, nn, nch = self.near_c, self.near_n, self.near_ch
        self.prompt.enabled = (nc is not None or nn is not None or nch is not None or self.near_slot) and not me.get("dead")
        if nn is not None:
            set_text(self.t_key, "E")
            set_text(self.t_prompt, f"Поговорить: {NPCS[nn]['name']}")
        elif self.near_slot and nc is None:
            set_text(self.t_key, "E")
            set_text(self.t_prompt, f"Игровой автомат «Золотая тайга»  ·  жетонов: {me.get('tok', 0)}")
        elif nch is not None and nc is None:
            set_text(self.t_key, "E")
            set_text(self.t_prompt, f"Открыть сундук: {self.chests[nch]['name']}")
        elif nc is not None:
            set_text(self.t_key, "F")
            nm_ = ANIMALS[nc["k"]]["name"]
            if nc["lock"]:
                set_text(self.t_prompt, f"{nm_}: чужая добыча, подождите")
            elif len(me["bag"]) >= me["cap"]:
                set_text(self.t_prompt, "Сумка полна - продайте добычу в лагере")
            else:
                set_text(self.t_prompt, f"Подобрать: {nm_}")
        if int(self.t * 4) != getattr(self, "_fd", -1) or self.feed_dirty:
            self._fd, self.feed_dirty = int(self.t * 4), False
            self.refresh_feed()
        self.radar_t = getattr(self, "radar_t", 0.0) - dt
        if self.radar_t <= 0:                                    # радар 15 раз в секунду - глазу хватает
            self.radar_t = 1 / 15
            self.update_radar()

    def update_radar(self):
        rx, ry = self.radar_c
        R, rad = 45.0, .115
        yr = math.radians(self.yaw)
        items = [(CAMP[0], CAMP[1], C(90, 170, 255), True)]
        items += [(r["x"], r["z"], GOLD if not r["lock"] else DIM, False) for r in self.carc.values()]
        items += [(r["x"], r["z"], C(120, 230, 120), False) for r in self.players.values()]
        items += [(c["x"], c["z"], C(255, 160, 60), False) for c in self.chests.values() if c["avail"]]
        items += [(r["x"], r["z"], C(255, 225, 60), False) for r in self.animals.values() if getattr(r["e"], "hth_gold", False)]
        items += [(r["x"], r["z"], C(255, 70, 60), False) for r in self.animals.values() if r.get("st") == 5 and not r["k"].startswith("boss_")]
        has_radar = bool(self.me.get("radar"))
        if has_radar and self.arena is not None:                 # боевой радар: арена (стрелка у края карты) и босс
            items.insert(0, (self.arena["gx"], self.arena["gz"], C(255, 150, 40), True))
            if self.boss_rec is not None:
                items.insert(0, (self.boss_rec["x"], self.boss_rec["z"], C(255, 40, 40), True))
        d_ = self.arena_dir() if has_radar else None
        set_text(self.t_arena, f"АРЕНА {d_[1]} {int(d_[0])} м" if d_ else "")
        for i, q in enumerate(self.blips):
            if i >= len(items):
                q.enabled = False
                continue
            x, z, col, clamp = items[i]
            dx, dz = x - self.px, z - self.pz
            sx, sy = dx * math.cos(yr) - dz * math.sin(yr), dx * math.sin(yr) + dz * math.cos(yr)
            d = math.hypot(sx, sy)
            if d > R:
                if not clamp:
                    q.enabled = False
                    continue
                sx, sy = sx / d * R, sy / d * R
            q.enabled = True
            q.position = (rx + sx / R * rad, ry + sy / R * rad, -.015)
            q.color = col
            q.scale = .02 if clamp else .014

    # ---------------------------------------------------------------- лавка (TAB)
    def build_camp(self):
        c = self.camp = Entity(parent=self.ui)
        frame(c, 0, 0, 1.56, .94, PANEL2, z=.1)
        label(c, "ЛАГЕРЬ", 0, .41, 2.8, GOLD)
        label(c, "ОРУЖИЕ", -.38, .315, 1.4, CREAM)
        label(c, "ПРОДАЖА ДОБЫЧИ", .38, .315, 1.4, CREAM)
        label(c, "ПУТЕШЕСТВИЕ", .38, -.065, 1.4, CREAM)
        self.w_rows = {}
        for i, k in enumerate(WEAPONS):
            y = .225 - i * .15
            panel(c, -.38, y, .72, .13, PANEL, r=.02, z=.05)
            weapon_icon(c, k, -.66, y, GOLD)
            nm = label(c, WEAPONS[k]["name"], -.57, y + .03, 1.6, GOLD, left=True)
            w = WEAPONS[k]
            label(c, f"урон {w['dmg']:g}" + (f" x{w['pellets']}" if w["pellets"] > 1 else "") +
                  f"   дальность {w['range']} м   перез. {w['cd']} с", -.57, y - .028, .8, DIM, left=True)
            b = UIButton(c, "", -.15, y, .25, .085, lambda k=k: self.net.send(t="buy", w=k), size=1.05)
            self.w_rows[k] = (nm, b)
        panel(c, .38, .12, .68, .36, PANEL, r=.02, z=.05)
        self.sell_lines = [label(c, "", .06, .255 - i * .04, 1.05, CREAM, left=True) for i in range(5)]
        self.sell_total = label(c, "", .06, .06, 1.3, GOLD, left=True)
        self.b_sell = UIButton(c, "ПРОДАТЬ ВСЁ  (E)", .38, -.0, .62, .07, lambda: self.net.send(t="sell"), size=1.2)
        self.b_loc = {}
        for i, k in enumerate(LOCS):
            self.b_loc[k] = UIButton(c, "", .38, -.13 - i * .085, .66, .07, lambda k=k: self.travel(k), C(40, 84, 120), 1.05)
        UIButton(c, "НАВЫКИ  (K)", -.38, -.40, .3, .07, lambda: self.set_overlay("tree"), C(110, 80, 40), 1.05)
        UIButton(c, "ЗАКРЫТЬ  (TAB)", .38, -.40, .3, .07, lambda: self.set_overlay(None), C(70, 70, 82), 1.05)
        c.enabled = False

    def travel(self, loc):
        self.net.send(t="travel", to=loc)
        self.set_overlay(None)

    def refresh_camp(self):
        me = self.me
        for k, (nm, b) in self.w_rows.items():
            w = WEAPONS[k]
            if k in me["owned"]:
                b.set("В РУКАХ" if me["w"] == k else "ВЗЯТЬ", off=me["w"] == k, col=BTN)
            elif me["lv"] < w["level"]:
                b.set(f"УРОВЕНЬ {w['level']}", off=True)
            else:
                b.set(f"КУПИТЬ ${me['prices'][k]}", off=me["gold"] < me["prices"][k], col=C(120, 90, 30))
        counts = {}
        for a in me["bag"]:
            kind, q = item_parts(a)
            c_ = counts.setdefault(kind, [0, 0])
            c_[0] += 1
            c_[1] += q
        rows = [f"{ANIMALS[k]['name']}  x{n}   (качество {qs // n}%)" for k, (n, qs) in counts.items()][:5]
        for i, tx in enumerate(self.sell_lines):
            set_text(tx, rows[i] if i < len(rows) else ("Сумка пуста" if i == 0 and not rows else ""))
        set_text(self.sell_total, f"Итого: ${me['bagval']}")
        self.b_sell.set(off=not me["bag"])
        for k, b in self.b_loc.items():
            info = LOCS[k]
            if k == self.cur_loc:
                b.set(f"{info['name'].upper()}  -  вы здесь", off=True)
            elif me["lv"] < info["level"]:
                b.set(f"{info['name'].upper()}  -  нужен уровень {info['level']}", off=True)
            elif BOSS_GATE.get(k) and BOSS_GATE[k] not in me.get("bosses", []):
                b.set(f"{info['name'].upper()}  -  победите: {ANIMALS[BOSS_GATE[k]]['name']}", off=True)
            else:
                b.set(f"ОТПРАВИТЬСЯ:  {info['name'].upper()}", off=False)

    # ---------------------------------------------------------------- дерево навыков (K)
    def build_tree(self):
        t = self.tree = Entity(parent=self.ui)
        frame(t, 0, 0, 1.78, .98, PANEL2, z=.1)
        label(t, "ДЕРЕВО НАВЫКОВ", 0, .455, 2.4, GOLD)
        self.nodes, self.links = {}, []
        pos = {}
        for k, s in SKILLS.items():
            dx, lv = TREE_NODE[k]
            pos[k] = (TREE_X[s["branch"]] + dx, TREE_Y[lv])
        for b, name in BRANCHES.items():
            label(t, name, TREE_X[b], .385, 1.5, bcol(b))
            panel(t, TREE_X[b], .03, .5, .75, C(*BRANCH_COL[b], 18), r=.03, z=.08)
        for k, s in SKILLS.items():                                  # связи (бусины)
            for r in s["req"]:
                (x1, y1), (x2, y2) = pos[r], pos[k]
                dist = math.hypot(x2 - x1, y2 - y1)
                n = max(2, int(dist / .022))
                dots = []
                for i in range(1, n):
                    f = i / n
                    if dist * f < .06 or dist * (1 - f) < .06:
                        continue
                    dots.append(Entity(parent=t, model="circle", scale=.009, position=(x1 + (x2 - x1) * f, y1 + (y2 - y1) * f, -.01),
                                       color=C(70, 76, 74)))
                self.links.append((dots, r, k))
        for k, s in SKILLS.items():                                  # узлы
            x, y = pos[k]
            ring = Entity(parent=t, model="circle", scale=.098, position=(x, y, -.02), color=C(70, 76, 74), collider="box")
            Entity(parent=t, model="circle", scale=.078, position=(x, y, -.03), color=C(14, 24, 20))
            glyph = label(t, ICON[k], x, y + .002, 2.2, DIM, z=-.04)
            rank = label(t, "", x, y - .068, .95, DIM, z=-.04)
            name = label(t, s["name"], x, y - .092, .72, DIM, z=-.04)
            ring.on_click = lambda k=k: self.net.send(t="skill", k=k)
            ring.on_mouse_enter = lambda k=k: setattr(self, "tree_hover", k)
            ring.on_mouse_exit = lambda k=k: setattr(self, "tree_hover", None if self.tree_hover == k else self.tree_hover)
            self.nodes[k] = dict(ring=ring, glyph=glyph, rank=rank, name=name, state="locked")
        panel(t, 0, -.415, 1.64, .15, PANEL, r=.02, z=.05)
        self.i_name = label(t, "", -.78, -.375, 1.4, GOLD, left=True)
        self.i_desc = label(t, "", -.78, -.418, 1.0, CREAM, left=True)
        self.i_hint = label(t, "", -.78, -.455, .9, DIM, left=True)
        self.t_points = label(t, "", .43, -.375, 1.4, GOLD)
        self.b_respec = UIButton(t, "", .43, -.425, .36, .06, lambda: self.net.send(t="respec"), C(120, 50, 46), .9)
        UIButton(t, "ЗАКРЫТЬ  (K)", .72, -.425, .17, .06, lambda: self.set_overlay(None), C(70, 70, 82), .8)
        t.enabled = False

    def skill_state(self, k):
        me, s = self.me, SKILLS[k]
        rank = me["sk"][k]
        if rank >= s["max"]:
            return "max"
        if any(me["sk"][r] < 1 for r in s["req"]):
            return "locked"
        return "avail" if me["pts"] > 0 else ("owned" if rank > 0 else "wait")

    def refresh_tree(self):
        me = self.me
        for k, n in self.nodes.items():
            s = SKILLS[k]
            st = n["state"] = self.skill_state(k)
            bc = bcol(s["branch"])
            rank = me["sk"][k]
            if st == "locked":
                ring, ink = C(62, 68, 66), C(100, 106, 102)
            elif st == "max":
                ring, ink = GOLD, GOLD
            elif rank > 0:
                ring, ink = bc, WHITE
            else:
                ring, ink = shade(bc, .62), CREAM
            n["ring"].color = ring
            n["glyph"].color = ink
            n["name"].color = ink if st != "locked" else C(100, 106, 102)
            set_text(n["rank"], f"{rank}/{s['max']}")
            n["rank"].color = ink
        for dots, r, k in self.links:
            c = bcol(SKILLS[k]["branch"]) if me["sk"][r] >= 1 else C(70, 76, 74)
            for d in dots:
                d.color = c
        set_text(self.t_points, f"Очки навыков: {me['pts']}")
        self.b_respec.set(f"СБРОС ${me['respec']}", off=me["gold"] < me["respec"] or sum(me["sk"].values()) == 0)

    def refresh_info(self):
        k = self.tree_hover
        if k is None:
            set_text(self.i_name, "Наведите на навык")
            set_text(self.i_desc, "Очки дают за каждый уровень (и бонусом на 5, 10, 15...). Клик - изучить.")
            set_text(self.i_hint, "")
            return
        s, me = SKILLS[k], self.me
        rank = me["sk"][k]

        def v(r):
            return s["fmt"].format(s["per"] * r, s["per"] * r)

        set_text(self.i_name, f"{s['name']}   ранг {rank}/{s['max']}")
        nxt = ("   →   следующий: " + v(rank + 1)) if rank < s["max"] else "   (максимум)"
        set_text(self.i_desc, f"Сейчас: {v(rank) if rank else 'ещё не изучен'}{nxt}")
        need = ", ".join(SKILLS[r]["name"] for r in s["req"] if me["sk"][r] < 1)
        set_text(self.i_hint, {"max": "Навык на максимуме", "locked": f"Сначала изучите: {need}",
                               "avail": "Клик - изучить (1 очко)", "wait": "Нужно очко навыка - берите уровни!",
                               "owned": "Нужно очко навыка для следующего ранга"}[self.skill_state(k)])

    # ---------------------------------------------------------------- обучение (F1) и задания
    def build_help(self):
        h = self.help_ui = Entity(parent=self.ui)
        frame(h, 0, 0, 1.78, .98, PANEL2, z=.1)
        label(h, "ОБУЧЕНИЕ", 0, .445, 2.4, GOLD)
        self.help_pages = []
        for title, rows in HELP_PAGES:
            pg = Entity(parent=h)
            label(pg, title, 0, .372, 1.7, CREAM)
            panel(pg, 0, .335, 1.5, .004, GOLD, r=0)
            for i, (k, d) in enumerate(rows):
                y = .27 - i * .092
                w = max(.07, .02 * len(k) + .05)
                panel(pg, -.80 + w / 2, y, w + .008, .066, C(255, 210, 74, 90), r=.014, z=-.005)
                panel(pg, -.80 + w / 2, y, w, .058, C(26, 52, 38), r=.012, z=-.01)
                label(pg, k, -.80 + w / 2, y, .95, GOLD, z=-.03)
                label(pg, d, -.43, y, 1.05, CREAM, left=True)
            pg.enabled = False
            self.help_pages.append(pg)
        self.t_page = label(h, "", 0, -.375, 1.0, DIM)
        UIButton(h, "◄ НАЗАД", -.55, -.43, .34, .07, lambda: self.help_go(-1), C(60, 70, 66), 1.0)
        UIButton(h, "ДАЛЕЕ ►", .55, -.43, .34, .07, lambda: self.help_go(1), C(60, 70, 66), 1.0)
        UIButton(h, "ЗАКРЫТЬ", 0, -.43, .34, .07, self.close_help, size=1.1)
        h.enabled = False
        self.help_go(0)

    def help_go(self, d):
        self.help_i = max(0, min(len(HELP_PAGES) - 1, self.help_i + d))
        for i, pg in enumerate(self.help_pages):
            pg.enabled = i == self.help_i
        set_text(self.t_page, f"Страница {self.help_i + 1} из {len(HELP_PAGES)}   (стрелки влево и вправо листают)")

    def open_help(self):
        self.help_i = 0
        self.help_go(0)
        if self.mode == "play":
            self.set_overlay("help")
        else:
            for e in self.pages.values():
                e.enabled = False
            self.settings_ui.enabled = False
            self.help_ui.enabled = True
            self.dim.enabled = True

    def close_help(self):
        self.help_ui.enabled = False
        if self.mode == "play":
            self.set_overlay(None)
        else:
            self.show_menu("main")

    def build_dialog(self):
        d = self.dialog = Entity(parent=self.ui)
        frame(d, 0, -.17, 1.5, .56, PANEL2, z=.1)
        Entity(parent=d, model="circle", scale=.19, position=(-.62, -.07, -.02), color=GOLD)
        Entity(parent=d, model="circle", scale=.165, position=(-.62, -.07, -.03), color=C(20, 40, 30))
        self.d_letter = label(d, "", -.62, -.07, 4.2, GOLD, z=-.05)
        self.d_name = label(d, "", -.48, 0, 1.6, GOLD, left=True)
        self.d_role = label(d, "", -.48, -.045, .9, DIM, left=True)
        self.d_text = Text(text="", parent=d, origin=(-.5, .5), position=(-.48, -.075, -.02), scale=1.1, color=CREAM)
        self.d_btns = [UIButton(d, "", x, -.38, .34, .07, None, size=.95) for x in (-.54, -.18, .18, .54)]
        d.enabled = False

    def open_dialog(self, nid):
        self.dlg = nid
        self.dlg_line = random.choice(NPC_LINES[nid])
        self.done("npc")
        self.set_overlay("npc")
        self.sfx.play("click", .5)
        self.refresh_dialog()

    def refresh_dialog(self):
        n, me = NPCS[self.dlg], self.me
        close = ("УЙТИ", lambda: self.set_overlay(None))
        if self.dlg == "trader":
            extra = f"В сумке: {len(me['bag'])} шт. на ${me['bagval']}." if me["bag"] else "Сумка пуста."
            opts = [("ЛАВКА: ОРУЖИЕ И ПРОДАЖА", lambda: self.set_overlay("camp")), close]
        elif self.dlg == "master":
            q = me["quest"]
            if q is None:
                extra = "Свободный заказ найдётся всегда. Берёшься?"
                opts = [("ВЗЯТЬ ЗАКАЗ", lambda: self.net.send(t="quest", a="take")), close]
            else:
                extra = f"Заказ: добыть {ANIMALS[q['k']]['name']} - {q['have']} из {q['need']}.\nНаграда: ${q['gold']} и {q['xp']} опыта."
                if q["have"] >= q["need"]:
                    opts = [("СДАТЬ ЗАКАЗ", lambda: self.net.send(t="quest", a="turn")), close]
                else:
                    opts = [("ОТКАЗАТЬСЯ", lambda: self.net.send(t="quest", a="drop")), close]
        elif self.dlg == "radio":
            if me.get("radar"):
                extra = "Радар у тебя на поясе: ворота арен для тебя открыты,\nбоссы и арена отмечены красным на карте."
                opts = [("ГДЕ АРЕНА?", self.say_arena), close]
            else:
                extra = (f"Боевой радар открывает ворота арен и показывает боссов.\nЦена: ${RADAR_PRICE}.  У тебя: ${me['gold']}.")
                opts = [(f"КУПИТЬ РАДАР  ${RADAR_PRICE}", lambda: self.net.send(t="radar")), close]
        else:
            extra = "Совет: " + TIPS[self.tip_i % len(TIPS)]
            opts = [("ОБУЧЕНИЕ (КЛАВИШИ)", self.open_help), ("ДЕРЕВО НАВЫКОВ", lambda: self.set_overlay("tree")),
                    ("ДРУГОЙ СОВЕТ", self.next_tip), close]
        set_text(self.d_letter, n["name"].split()[1][0])
        set_text(self.d_name, n["name"])
        set_text(self.d_role, n["role"])
        set_text(self.d_text, "\n".join(textwrap.wrap(self.dlg_line, 76)) + "\n\n" + extra)
        for i, b in enumerate(self.d_btns):
            b.root.enabled = i < len(opts)
            if i < len(opts):
                b.cb = opts[i][1]
                b.set(opts[i][0], off=False)

    def next_tip(self):
        self.tip_i += 1

    def arena_dir(self):
        """Куда и как далеко арена босса в этой локации: (метры, стрелка относительно взгляда, страна света)."""
        a = self.arena
        if a is None:
            return None
        dx, dz = a["gx"] - self.px, a["gz"] - self.pz
        yr = math.radians(self.yaw)
        sx, sy = dx * math.cos(yr) - dz * math.sin(yr), dx * math.sin(yr) + dz * math.cos(yr)
        ang = math.degrees(math.atan2(sx, sy)) % 360
        arrow = "↑↗→↘↓↙←↖"[int((ang + 22.5) // 45) % 8]
        world = math.degrees(math.atan2(dx, dz)) % 360
        side = ("север", "северо-восток", "восток", "юго-восток", "юг", "юго-запад", "запад", "северо-запад")[int((world + 22.5) // 45) % 8]
        return math.hypot(dx, dz), arrow, side

    def say_arena(self):
        d = self.arena_dir()
        if d is None:
            return self.on_message("В этой локации радар арену не нашёл")
        self.on_message(f"Арена босса: {int(d[0])} м на {d[2]}. Ворота с этой стороны арены")

    def build_tasks(self):
        t = self.tasks = Entity(parent=self.hud)
        frame(t, -.69, .035, .42, .46, PANEL, r=.025)
        self.t_tasks_title = label(t, "", -.88, .24, .95, GOLD, left=True)
        self.task_rows = [label(t, "", -.88, .195 - i * .034, .85, CREAM, left=True) for i in range(len(TASKS))]

    def update_tasks(self):
        ch = self.me.get("story", 0) if self.me else 0
        if self.tasks_on and len(self.tut) >= len(TASKS) and self.intro is None:      # сюжет
            self.tasks.enabled = True
            if ch < len(STORY):
                set_text(self.t_tasks_title, f"СЮЖЕТ  ·  ГЛАВА {ch + 1} из {len(STORY)}   (H - скрыть)")
                lines = textwrap.wrap(f"{STORY[ch]['title']}: {STORY[ch]['goal']}", 40)
            else:
                set_text(self.t_tasks_title, "СЮЖЕТ ПРОЙДЕН   (H - скрыть)")
                lines = ["Ты - хозяин Медвежьего Угла.", "Боссы возвращаются - охота продолжается."]
            for i, row in enumerate(self.task_rows):
                set_text(row, lines[i] if i < len(lines) else "")
                row.color = GOLD if i == 0 else CREAM
            return
        show = self.tasks_on and len(self.tut) < len(TASKS) and self.intro is None
        self.tasks.enabled = show
        if not show:
            return
        set_text(self.t_tasks_title, f"ПЕРВЫЕ ШАГИ  {len(self.tut)}/{len(TASKS)}   (H - скрыть)")
        cur = next((k for k, _ in TASKS if k not in self.tut), None)
        for (k, txt), row in zip(TASKS, self.task_rows):
            ok = k in self.tut
            set_text(row, ("[x] " if ok else "[ ] ") + txt)
            row.color = DIM if ok else (GOLD if k == cur else CREAM)

    def done(self, key):
        if key in self.tut or len(self.tut) >= len(TASKS):
            return
        self.tut.add(key)
        self.S["tut_done"] = sorted(self.tut)
        save_settings(self.S)
        self.feed.append((self.t, "Задание выполнено: " + dict(TASKS)[key]))
        self.feed_dirty = True
        self.sfx.play("skill", .5)

    def update_npcs(self, dt):
        me = self.me
        self.near_n, best = None, TALK_R
        for i, (nid, n) in enumerate(NPCS.items()):
            d = math.hypot(n["x"] - self.px, n["y"] - self.pz)
            e = self.npc_ents.get(nid)
            if e is not None:                                  # NPC поворачивается к игроку и «дышит»
                target = math.degrees(math.atan2(self.px - n["x"], self.pz - n["y"])) if d < 9 else n["yaw"]
                tags_on = 3.0 < d < 28
                for tg in getattr(e, "hth_tags", ()):
                    if tg.enabled != tags_on:
                        tg.enabled = tags_on
                e.rotation_y = e.rotation_y + ((target - e.rotation_y + 180) % 360 - 180) * min(1, dt * 5)
                e.y = .018 * math.sin(self.t * 2 + i)
                if nid == "radio":                             # «!» - радар ещё не куплен
                    e.hth_mark.enabled = not me.get("radar") and d < 40
                if nid == "master":                            # «!» - есть заказ, «?» - можно сдать
                    q = me["quest"]
                    sign = "!" if q is None else ("?" if q["have"] >= q["need"] else "")
                    e.hth_mark.enabled = bool(sign) and d < 40
                    if sign:
                        set_text(e.hth_mark, sign)
                        e.hth_mark.y = 2.75 + .1 * math.sin(self.t * 4)
            if d < best:
                best, self.near_n = d, nid

    # ---------------------------------------------------------------- взлом замка сундука (мини-игра)
    LOCK_SPEED = (.75, .95, 1.15, 1.4)

    def build_lock(self):
        b = self.lock_ui = Entity(parent=self.ui)
        frame(b, 0, -.2, 1.2, .52, PANEL2, z=.1)
        label(b, "ВЗЛОМ ЗАМКА", 0, .01, 1.7, GOLD)
        self.l_info = label(b, "", 0, -.04, 1.0, CREAM)
        xs = [(i - 1.5) * .23 for i in range(4)]
        for x in xs:
            panel(b, x, -.2, .14, .25, C(20, 16, 14, 240), r=.01, z=.05)
        self.l_band = panel(b, 0, -.2, .86, .03, C(70, 160, 80, 150), r=0, z=.045)
        panel(b, 0, -.2, .86, .004, GOLD, r=0, z=.044)
        self.l_marks = [panel(b, x, -.2, .11, .02, WHITE, r=0, z=.03) for x in xs]
        self.l_res = label(b, "", 0, -.36, 1.2, CREAM)
        label(b, "ПРОБЕЛ или ЛКМ - зафиксировать штифт, когда он на золотой линии   ·   ESC - отмена", 0, -.42, .8, DIM)
        b.enabled = False

    def start_lock(self, cid):
        if self.me.get("dead"):
            return
        left = self.jam.get(cid, 0) - self.t
        if left > 0:
            return self.on_message(f"Замок заклинило. Подождите {int(left) + 1} с")
        c = self.chests.get(cid)
        if c is None or not c["avail"]:
            return
        tier = {"forest": 1, "thicket": 2, "tundra": 3}.get(self.cur_loc, 1)
        self.lock = dict(cid=cid, pin=0, picks=3, broke=0, qs=[], q=1.0, tol=max(.07, .15 * (1 - .14 * (tier - 1))), sp=1 + .16 * (tier - 1),
                         done=0.0, yn=0.0, ph=[random.uniform(0, 2) for _ in range(4)], st=[0, 0, 0, 0])
        set_text(self.l_res, "")
        self.set_overlay("lock")
        self.sfx.play("pin", .5, .8)
        self.refresh_lock()

    def refresh_lock(self):
        lk = self.lock
        set_text(self.l_info, f"Отмычек: {lk['picks']}   ·   Штифт {min(lk['pin'] + 1, 4)} из 4")
        self.l_band.scale_y = 2 * lk["tol"] * .105

    def update_lock(self, dt):
        lk = self.lock
        if lk is None:
            return
        c = self.chests.get(lk["cid"])
        if c is None:
            self.lock = None
            return self.set_overlay(None)
        want_yaw = math.degrees(math.atan2(c["x"] - self.px, c["z"] - self.pz))      # камера плавно смотрит на сундук
        want_pitch = math.degrees(math.atan2(EYE - .3, max(.5, math.hypot(c["x"] - self.px, c["z"] - self.pz))))
        self.yaw += ((want_yaw - self.yaw + 180) % 360 - 180) * min(1, dt * 4)
        self.pitch += (want_pitch - self.pitch) * min(1, dt * 4)
        self.rig.rotation_y = self.yaw
        self.pit_node.rotation_x = self.pitch
        if lk["done"]:
            lk["done"] -= dt
            if lk["done"] <= 0:
                self.net.send(t="loot", id=lk["cid"], q=round(lk["q"], 3))
                self.lock = None
                self.set_overlay(None)
            return
        i = lk["pin"]
        lk["ph"][i] += dt * self.LOCK_SPEED[i] * lk["sp"] * 2
        t = lk["ph"][i] % 2
        lk["yn"] = -1 + 2 * t if t < 1 else 1 - 2 * (t - 1)
        for j, m in enumerate(self.l_marks):
            if lk["st"][j]:
                m.y, m.color = -.2, C(110, 230, 120)
            elif j == i:
                m.y, m.color = -.2 + lk["yn"] * .105, WHITE
            else:
                m.y, m.color = -.2 - .105, C(110, 110, 110)

    def lock_press(self):
        lk = self.lock
        if lk is None or lk["done"]:
            return
        i, off = lk["pin"], abs(lk["yn"])
        if off <= lk["tol"]:
            acc = 1 - off / lk["tol"]
            lk["qs"].append(.85 + .4 * acc)
            lk["st"][i] = 1
            lk["pin"] += 1
            self.sfx.play("pin", .8, 1 + .08 * i)
            set_text(self.l_res, "Штифт встал точно!" if acc > .7 else "Штифт встал")
            self.l_res.color = GOLD if acc > .7 else C(140, 220, 140)
            if lk["pin"] >= 4:
                lk["q"] = max(.6, min(1.3, sum(lk["qs"]) / 4 - .06 * lk["broke"]))
                lk["done"] = 1.0
                set_text(self.l_res, f"Замок открыт! Качество взлома: {int(lk['q'] * 100)}%")
                self.l_res.color = GOLD
                self.sfx.play("unlock", .9)
        else:
            lk["picks"] -= 1
            lk["broke"] += 1
            self.sfx.play("snap", .8)
            self.shake = max(self.shake, .4)
            set_text(self.l_res, "Отмычка сломалась!")
            self.l_res.color = RED
            if lk["picks"] <= 0:
                self.jam[lk["cid"]] = self.t + 45
                self.lock = None
                self.set_overlay(None)
                return self.on_message("Все отмычки сломаны, замок заклинило. Попробуйте через 45 секунд")
        self.refresh_lock()

    # ---------------------------------------------------------------- туман, привязанный к месту
    def update_mist(self, dt, eye):
        """Полосы тумана стоят на карте. Клочья рядом с камерой плавно тают (перед тобой туман расступается), а видимость
        вокруг падает, пока ты внутри полосы; выйдешь - позади остаётся плотная стена."""
        self.mist_acc += dt
        self.mist_t -= dt
        if self.mist_t > 0:
            return
        dt, self.mist_acc, self.mist_t = self.mist_acc, 0.0, 1 / 15          # клочья тумана меняются плавно - 15 раз в секунду хватает
        at = self.atmo
        tint = getattr(at, "fog_tint", (170, 185, 175))
        key = (int(tint[0]) // 4, int(tint[1]) // 4, int(tint[2]) // 4)
        force, self.mist_key = key != self.mist_key, key
        fr, fg, fb = tint[0] / 255, tint[1] / 255, tint[2] / 255
        mist = getattr(at, "mist", 1.0) if self.S["fog"] else 0.0
        if self.mist_off:
            mist = 0.0
        ex, ey, ez = eye[0], eye[1], eye[2]
        target = 0.0
        for bk in self.banks:
            d = math.hypot(bk["x"] - self.px, bk["z"] - self.pz)
            show = mist > 0 and not self.mist_off and d < bk["R"] + 120                 # дальние полосы тумана сливаются с общим туманом - не рисуем
            if show != bk["vis"]:
                bk["vis"] = show
                if not show:
                    for s_ in bk["sprites"]:
                        if s_.hth_on:
                            s_.hth_on, s_.enabled = False, False
            if not show:
                continue
            ins = max(0.0, min(1.0, (bk["R"] - d) / (bk["R"] * .5)))
            ins = ins * ins * (3 - 2 * ins)
            target = max(target, ins)
            for s_ in bk["sprites"]:
                sx, sy, sz = s_.hth_pos
                dd = math.sqrt((sx - ex) ** 2 + (sy - ey) ** 2 + (sz - ez) ** 2)
                f = 0.0 if dd > 190 else max(0.0, min(1.0, (dd - 12) / 40))    # ближе 12 м клочья пропадают, полная плотность только к 52 м
                a = min(.3, s_.hth_a * mist * f * f * (3 - 2 * f) * (1 - .45 * ins))
                on = a > .004
                if on != s_.hth_on:
                    s_.hth_on, s_.enabled = on, on
                if on and (force or abs(a - s_.hth_last) > .004):
                    s_.color, s_.hth_last = Color(fr, fg, fb, a), a
        ar = self.arena
        if ar is not None and math.hypot(ar["x"] - self.px, ar["z"] - self.pz) < ARENA_R + 20:
            target = 0.0                                          # на арене босса туман не сгущается - бой должен быть виден
        lf = getattr(at, "local_fog", 0.0)
        at.local_fog = lf + (target - lf) * min(1.0, dt * 1.6)

    # ---------------------------------------------------------------- разделка туши (мини-игра)
    BUTCH_STAGES = (("Снять шкуру", .24, .75), ("Разделать мясо", .18, 1.0), ("Отделить трофей", .13, 1.3))

    def build_butcher(self):
        b = self.butcher_ui = Entity(parent=self.ui)
        frame(b, 0, -.27, 1.2, .36, PANEL2, z=.1)
        self.b_title = label(b, "", 0, -.13, 1.7, GOLD)
        self.b_stage = label(b, "", 0, -.18, 1.1, CREAM)
        panel(b, 0, -.255, 1.0, .06, C(20, 16, 14, 240), r=.01, z=.05)
        self.b_zone = panel(b, 0, -.255, .2, .06, C(70, 160, 80, 230), r=.008, z=.04)
        self.b_sweet = panel(b, 0, -.255, .012, .06, GOLD, r=0, z=.035)
        self.b_mark = panel(b, 0, -.255, .012, .09, WHITE, r=0, z=.03)
        self.b_res = label(b, "", 0, -.33, 1.2, CREAM)
        self.b_cuts = label(b, "", 0, -.375, 1.0, DIM)
        label(b, "ПРОБЕЛ или ЛКМ - резать, когда нож в зелёной зоне   ·   ESC - отмена", 0, -.42, .8, DIM)
        b.enabled = False

    def start_butcher(self):
        nc = self.near_c
        if nc is None:
            return self.net.send(t="pickup")                     # сервер ответит «Рядом нет добычи»
        if nc["lock"]:
            return self.on_message("Эта добыча чужая - подождите, пока хозяин её разделает")
        if len(self.me["bag"]) >= self.me["cap"]:
            return self.on_message("Сумка полна! Продайте добычу в лагере")
        self.butch = dict(rec=nc, stage=0, pos=0.0, dirn=1, res=[], done=0.0, flash=0.0,
                          zone=random.uniform(.2, .8), size=ANIMALS[nc["k"]]["hp"])
        self.set_overlay("butcher")
        self.sfx.play("cut", .5, .8)
        self.refresh_butcher()

    def refresh_butcher(self):
        bt = self.butch
        name, width, speed = self.BUTCH_STAGES[min(bt["stage"], 2)]
        set_text(self.b_title, "РАЗДЕЛКА: " + ANIMALS[bt["rec"]["k"]]["name"])
        set_text(self.b_stage, f"Этап {min(bt['stage'] + 1, 3)} из 3: {name}")
        self.b_zone.scale_x = width
        self.b_zone.x = (bt["zone"] - .5) * 1.0
        self.b_sweet.x = self.b_zone.x
        set_text(self.b_cuts, "   ".join(("ИДЕАЛЬНО" if q >= 1.18 else "ХОРОШО" if q >= .95 else "НЕРОВНО") for q in bt["res"]))

    def update_butcher(self, dt):
        bt = self.butch
        if bt is None:
            return
        rec = bt["rec"]
        if not any(r is rec for r in self.carc.values()):      # тушу успели забрать или она пропала
            self.butch = None
            self.set_overlay(None)
            return self.on_message("Туша пропала")
        tx, tz = rec["x"], rec["z"]                              # камера плавно смотрит на тушу
        want_yaw = math.degrees(math.atan2(tx - self.px, tz - self.pz))
        want_pitch = math.degrees(math.atan2(EYE - .4, max(.5, math.hypot(tx - self.px, tz - self.pz))))
        self.yaw += ((want_yaw - self.yaw + 180) % 360 - 180) * min(1, dt * 4)
        self.pitch += (want_pitch - self.pitch) * min(1, dt * 4)
        self.rig.rotation_y = self.yaw
        self.pit_node.rotation_x = self.pitch
        if bt["done"]:
            bt["done"] -= dt
            if bt["done"] <= 0:
                q = sum(bt["res"]) / len(bt["res"])
                self.net.send(t="pickup", q=round(q, 3))
                self.butch = None
                self.set_overlay(None)
            return
        _, width, speed = self.BUTCH_STAGES[bt["stage"]]
        speed *= 1 + min(.4, bt["size"] / 60)                    # крупного зверя разделывать сложнее
        bt["pos"] += bt["dirn"] * speed * dt
        if bt["pos"] > 1 or bt["pos"] < 0:
            bt["dirn"] *= -1
            bt["pos"] = min(1.0, max(0.0, bt["pos"]))
        self.b_mark.x = (bt["pos"] - .5) * 1.0
        bt["flash"] = max(0.0, bt["flash"] - dt)
        self.b_mark.color = GOLD if bt["flash"] > 0 else WHITE

    def butcher_cut(self):
        bt = self.butch
        if bt is None or bt["done"]:
            return
        _, width, _ = self.BUTCH_STAGES[bt["stage"]]
        off = abs(bt["pos"] - bt["zone"]) / (width / 2)
        rec = bt["rec"]
        if off <= 1:
            q = .95 + .3 * (1 - off)                            # в зоне: 95-125% (в центре - лучше всего)
            set_text(self.b_res, "ИДЕАЛЬНЫЙ РАЗРЕЗ!" if q >= 1.18 else "Хороший разрез")
            self.b_res.color = GOLD if q >= 1.18 else C(140, 220, 140)
            self.sfx.play("cut", .8, random.uniform(.95, 1.1))
            self.particles.burst((rec["x"], .45, rec["z"]), 10, C(160, 30, 28), speed=1.2, life=.6, size=.08, up=1.8)
        else:
            q = .55
            set_text(self.b_res, "Неровный разрез - шкура испорчена")
            self.b_res.color = RED
            self.sfx.play("error", .5)
            self.shake = .35
        bt["res"].append(q)
        bt["flash"] = .15
        bt["stage"] += 1
        if bt["stage"] >= 3:
            total = sum(bt["res"]) / 3
            set_text(self.b_res, f"Готово! Качество разделки: {int(total * 100)}%")
            self.b_res.color = GOLD if total >= 1.0 else CREAM
            bt["done"] = 1.1
            bt["stage"] = 2
            self.sfx.play("pickup", .8)
        else:
            bt["zone"] = random.uniform(.15, .85)
            bt["pos"] = 0.0 if bt["zone"] > .5 else 1.0
        self.refresh_butcher()

    # ---------------------------------------------------------------- сюжет: вступительный ролик и главы
    INTRO_LINES = {
        "forest": ["Тайга. Старый кордон «Медвежий Угол».",
                   "Три года назад здешний егерь Степан ушёл на север - и не вернулся."],
        "arena": ["С тех пор в тайге объявились хозяева - звери, каких не помнят и старики.",
                  "Их держат за стенами старых арен. Но надолго ли?"],
        "camp": ["Лесничество прислало нового егеря. Тебя.",
                 "На кордоне ждут: торговец Макар, Тамара, следопыт Игнат и радист Фёдор."],
    }
    STORY_OUTRO = [
        "Игнат одобрительно кивает: «Рука у тебя твёрдая. Степан бы оценил».\nФёдор машет из палатки: в эфире странный сигнал.",
        "Радар ожил. На экране три метки - три арены.\nФёдор шепчет: «Это маяки Степана. Он их и строил...»",
        "Секач повержен. В логове - клок куртки егеря и записка:\n«Дальше - чаща. Один не ходи».",
        "Шатун больше не бродит. На камне берлоги вырезано:\n«С. - на север, к белому».",
        "Белый вожак пал. Среди костей - дневник Степана: «Я запер хозяев за стенами,\nчтобы тайга жила. Читаешь это - значит, кордон теперь твой».",
    ]

    def build_cine(self):
        c = self.cine_ui = Entity(parent=self.ui)
        self.cine_fade = panel(c, 0, 0, 2.4, 1.4, C(0, 0, 0, 0), r=0, z=.05)
        self.cine_top = panel(c, 0, .62, 2.4, .2, C(0, 0, 0, 255), r=0, z=.04)
        self.cine_bot = panel(c, 0, -.62, 2.4, .2, C(0, 0, 0, 255), r=0, z=.04)
        self.cine_title = label(c, "", 0, .06, 6.0, GOLD, z=.02)
        self.cine_sub = label(c, "", 0, -.04, 1.9, CREAM, z=.02)
        self.cine_text = label(c, "", 0, -.405, 1.25, CREAM, z=.02)
        self.cine_skip = label(c, "ПРОБЕЛ или ESC - пропустить", .7, -.47, .75, DIM, z=.02)
        c.enabled = False
        self.intro, self.card, self.intro_pending = None, None, False

    @staticmethod
    def look(frm, to):
        dx, dy, dz = to[0] - frm[0], to[1] - frm[1], to[2] - frm[2]
        return math.degrees(math.atan2(dx, dz)), math.degrees(math.atan2(-dy, max(.1, math.hypot(dx, dz))))

    def start_intro(self):
        """Вступительный ролик новой игры: облёт тайги, арена босса, спуск к костру лагеря - с субтитрами."""
        cx, cz = CAMP
        fire = (cx, 1.0, cz)
        cl = lambda x, lo, hi: max(lo, min(hi, x))
        p1a = (cl(cx - 175, 20, W - 20), 58, cl(cz - 135, 20, H - 20))
        p1b = (cl(cx - 85, 20, W - 20), 34, cl(cz - 60, 20, H - 20))
        shots = [dict(kind="title", dur=4.2, a=p1a, b=p1a, target=fire)]
        shots.append(dict(kind="forest", dur=9.5, a=p1a, b=p1b, target=fire))
        ar = self.arena
        if ar is not None:
            ux, uz = ar["gx"] - ar["x"], ar["gz"] - ar["z"]
            n = math.hypot(ux, uz) or 1
            ux, uz = ux / n, uz / n
            shots.append(dict(kind="arena", dur=8.5, a=(ar["gx"] + ux * 34 - uz * 18, 19, ar["gz"] + uz * 34 + ux * 18),
                              b=(ar["gx"] + ux * 16 + uz * 6, 11, ar["gz"] + uz * 16 - ux * 6), target=(ar["x"], 1.5, ar["z"])))
        shots.append(dict(kind="camp", dur=9.5, a=(cx + 36, 19, cz - 30), b=(cx + 8.5, 3.0, cz - 6.5), target=fire))
        shots.append(dict(kind="end", dur=3.2, a=(cx + 8.5, 3.0, cz - 6.5), b=(cx + 8.5, 3.0, cz - 6.5), target=fire))
        self.intro = dict(shots=shots, i=0, t=0.0, roared=False, px=self.px, pz=self.pz)
        self.intro_pending = False
        self.cine_ui.enabled = True
        self.set_overlay("intro")
        if self.vm is not None:
            self.vm.enabled = False

    def end_intro(self):
        self.intro = None
        self.cine_ui.enabled = False
        self.set_overlay(None)
        if self.vm is not None:
            self.vm.enabled = True
        self.first_pos = True                                  # камера возвращается к охотнику у костра
        self.yaw, self.pitch = self.look((self.px, EYE, self.pz), (CAMP[0], 1.0, CAMP[1]))[0], 8.0
        self.show_card(-1)

    def update_intro(self, dt):
        it = self.intro
        it["t"] += dt
        sh = it["shots"][it["i"]]
        if it["t"] >= sh["dur"]:
            it["i"] += 1
            it["t"] = 0.0
            if it["i"] >= len(it["shots"]):
                return self.end_intro()
            sh = it["shots"][it["i"]]
        f = it["t"] / sh["dur"]
        e = f * f * (3 - 2 * f)                                 # плавный разгон и торможение камеры
        a, b = sh["a"], sh["b"]
        pos = (a[0] + (b[0] - a[0]) * e, a[1] + (b[1] - a[1]) * e, a[2] + (b[2] - a[2]) * e)
        yaw, pitch = self.look(pos, sh["target"])
        self.rig.position = pos
        self.rig.rotation_y = yaw
        self.pit_node.rotation_x = pitch
        self.pit_node.rotation_z = math.sin(self.t * .4) * .6     # лёгкое «дыхание» операторской камеры
        self.px, self.pz = pos[0], pos[2]                       # дальность прорисовки считаем от камеры
        bars = min(1.0, (it["t"] + (it["i"] > 0) * 9) / 1.0)   # чёрные полосы кино-кадра выезжают в начале
        self.cine_top.y, self.cine_bot.y = .62 - .17 * bars, -.62 + .17 * bars
        # затемнение: чёрный экран с названием, плавные переходы между планами
        if sh["kind"] == "title":
            fade = 1.0
            ta = min(1.0, it["t"] / .9) * min(1.0, (sh["dur"] - it["t"]) / .9)
            set_text(self.cine_title, "HOW TO HUNT")
            set_text(self.cine_sub, "Хроники Медвежьего Угла")
            self.cine_title.color = Color(1, .82, .29, ta)
            self.cine_sub.color = Color(.95, .92, .82, ta)
        else:
            set_text(self.cine_title, "")
            set_text(self.cine_sub, "")
            fade = max(0.0, 1 - it["t"] / .8) if it["i"] > 0 else 0.0
            if sh["kind"] == "end":
                fade = min(1.0, it["t"] / 1.4) if it["t"] < 1.6 else max(0.0, 1 - (it["t"] - 1.6) / 1.2)
            elif sh["dur"] - it["t"] < .6:
                fade = max(fade, 1 - (sh["dur"] - it["t"]) / .6)
        self.cine_fade.color = Color(0, 0, 0, fade)
        lines = self.INTRO_LINES.get(sh["kind"])
        if lines:                                               # субтитры печатаются по буквам
            half = sh["dur"] / len(lines)
            k = min(len(lines) - 1, int(it["t"] / half))
            n = int((it["t"] - k * half) * 38)
            set_text(self.cine_text, lines[k][:n])
        else:
            set_text(self.cine_text, "")
        if sh["kind"] == "arena" and not it["roared"] and it["t"] > 2.0:
            it["roared"] = True
            self.sfx.play("roar", .8, .9)

    def show_card(self, ch):
        """Карточка главы: -1 - начало игры (глава 1), иначе ch - номер пройденной главы."""
        if self.card is not None and ch >= 0:                  # несколько глав сразу - карточки по очереди
            self.card_q = getattr(self, "card_q", []) + [ch]
            return
        story = STORY
        if ch < 0:
            title, body = f"Глава 1. {story[0]['title']}", story[0]["goal"]
        elif ch + 1 < len(story):
            title = f"Глава {ch + 1} пройдена!"
            body = self.STORY_OUTRO[ch] + f"\n\nДальше - глава {ch + 2}. {story[ch + 1]['title']}: {story[ch + 1]['goal']}"
        else:
            title, body = "Сюжет пройден!", self.STORY_OUTRO[ch] + "\n\nТы - хозяин Медвежьего Угла. Охота продолжается."
        self.card = dict(t=0.0, dur=9.0 if ch >= 0 else 5.5, title=title, body=body)
        self.cine_ui.enabled = True
        self.cine_skip.enabled = False
        self.sfx.play("levelup", .6)

    def update_card(self, dt):
        cd = self.card
        if cd is None or self.intro is not None:
            return
        cd["t"] += dt
        t, dur = cd["t"], cd["dur"]
        a = min(1.0, t / .6) * min(1.0, max(0.0, (dur - t) / .8))
        self.cine_top.y, self.cine_bot.y = .62 - .1 * a, -.62 + .1 * a
        self.cine_fade.color = Color(0, 0, 0, .35 * a)
        set_text(self.cine_title, cd["title"])
        set_text(self.cine_sub, "")
        set_text(self.cine_text, cd["body"][:int(t * 60)])
        self.cine_title.y = .2
        self.cine_title.color = Color(1, .82, .29, a)
        self.cine_text.y = .02
        self.cine_text.color = Color(.95, .92, .82, a)
        if t >= dur:
            self.card = None
            self.cine_ui.enabled = False
            q = getattr(self, "card_q", [])
            if q:
                self.card_q = q[1:]
                self.show_card(q[0])
                return
            self.cine_skip.enabled = True
            self.cine_title.y, self.cine_text.y = .06, -.405

    # ---------------------------------------------------------------- сумка с добычей: клетки, добыча в руках
    INV_COLS = 5

    def build_inv(self):
        v = self.inv_ui = Entity(parent=self.ui)
        frame(v, 0, 0, 1.4, .98, PANEL2, z=.1)
        label(v, "СУМКА С ДОБЫЧЕЙ", 0, .445, 2.0, GOLD)
        self.i_info = label(v, "", 0, .385, 1.0, CREAM)
        self.inv_cells = []
        cols, w, h, gx, gy = self.INV_COLS, .23, .14, .016, .012
        x0 = -(cols * w + (cols - 1) * gx) / 2 + w / 2
        for i in range(25):                                        # до 25 клеток (на случай навыков, увеличивающих сумку)
            r, c = divmod(i, cols)
            x, y = x0 + c * (w + gx), .295 - r * (h + gy)
            btn = UIButton(v, "", x, y, w, h, lambda i=i: self.inv_click(i), C(26, 42, 34), 1.0)
            box = Entity(parent=btn.root, position=(0, 0, -.02))
            nm = label(btn.root, "", x * 0 + .018, .033, .78, CREAM, left=True, z=-.03)
            q = label(btn.root, "", .018, .0, .62, DIM, left=True, z=-.03)
            vl = label(btn.root, "", .018, -.033, .62, C(120, 220, 130), left=True, z=-.03)
            hd = label(btn.root, "", 0, h / 2 - .014, .55, GOLD, z=-.03)
            self.inv_cells.append(dict(btn=btn, box=box, nm=nm, q=q, vl=vl, hd=hd, key=None, x=x, y=y))
        self.i_stow = UIButton(v, "ПОЛОЖИТЬ В СУМКУ", -.3, -.435, .5, .06, lambda: self.carry_set(-1), C(90, 70, 40), 1.0)
        UIButton(v, "ЗАКРЫТЬ  (I / ESC)", .3, -.435, .5, .06, lambda: self.set_overlay(None), C(70, 70, 82), 1.0)
        v.enabled = False
        self.carry_ov, self.cvm, self.cvm_key = (-1, 0.0), None, "none"

    def carry_idx(self):
        """Что несём в руках: клиент сразу показывает выбор, не дожидаясь ответа сервера."""
        ov, until = self.carry_ov
        return ov if self.t < until else self.me.get("carry", -1)

    def carry_item(self):
        i, bag = self.carry_idx(), self.me.get("bag", [])
        if 0 <= i < len(bag) and item_parts(bag[i])[0] in ANIMALS:
            return bag[i]
        return None

    def carry_set(self, i):
        bag = self.me.get("bag", [])
        if i >= 0 and (i >= len(bag) or item_parts(bag[i])[0] not in ANIMALS):
            return
        if i >= 0 and self.overlay in (None, "inv") and not self.me.get("dead"):
            self.net.send(t="carry", i=i)
            self.carry_ov = (i, self.t + .6)
            self.sfx.play("pickup", .6, 1.1)
        elif i < 0:
            self.net.send(t="carry", i=-1)
            self.carry_ov = (-1, self.t + .6)
            self.sfx.play("step", .4, .7)
        if self.overlay == "inv":
            self.refresh_inv()

    def inv_click(self, i):
        bag = self.me.get("bag", [])
        if i >= len(bag):
            return
        kind = item_parts(bag[i])[0]
        if kind not in ANIMALS:
            return self.on_message("Сокровище в руках не носят: продайте его в лагере (E)")
        if self.carry_idx() == i:
            self.carry_set(-1)                                     # клик по несомой добыче - убрать в сумку
        else:
            self.carry_set(i)
            self.set_overlay(None)                                 # взяли в руки - сумка закрывается

    def toggle_carry(self):
        if self.me.get("dead") or self.overlay is not None:
            return
        if self.carry_idx() >= 0:
            return self.carry_set(-1)
        bag = self.me.get("bag", [])
        for i in range(len(bag) - 1, -1, -1):                      # G: взять последнюю добычу
            if item_parts(bag[i])[0] in ANIMALS:
                return self.carry_set(i)
        self.on_message("В сумке нет добычи. Добудьте зверя и разделайте тушу (F)")

    def open_inv(self):
        if self.me.get("dead"):
            return
        self.set_overlay("inv")
        self.refresh_inv(force=True)

    def refresh_inv(self, force=False):
        me = self.me
        bag, cap, ci = me.get("bag", []), me.get("cap", 9), self.carry_idx()
        total_est = 0
        cit = self.carry_item()
        cm = CARRY_SLOW.get(item_parts(cit)[0], .85) if cit else 1.0
        set_text(self.i_info, f"Добыча: {len(bag)}/{cap}     ${me.get('bagval', 0)}" +
                 (f"     В руках: {ANIMALS[item_parts(cit)[0]]['name']}  ·  скорость {int(cm * 100)}%" if cit else "     руки свободны"))
        self.i_stow.set(off=cit is None)
        for i, cell in enumerate(self.inv_cells):
            on = i < cap
            cell["btn"].root.enabled = on
            if not on:
                continue
            item = bag[i] if i < len(bag) else None
            key = (item, i == ci)
            if key == cell["key"] and not force:
                continue
            cell["key"] = key
            for ch in list(cell["box"].children):
                destroy(ch)
            if item is None:
                cell["btn"].set(col=C(18, 28, 24))
                for k in ("nm", "q", "vl", "hd"):
                    set_text(cell[k], "")
                set_text(cell["nm"], "пусто")
                cell["nm"].color = C(70, 86, 78)
                continue
            kind, q = item_parts(item)
            gold = item_gold(item)
            if kind in ANIMALS:
                nm = ANIMALS[kind]["name"]
                animal_icon(cell["box"], kind, -.076, -.03, .085, gold)
                est = int(ANIMALS[kind]["value"] * q / 100)
            else:
                nm = LOOT.get(kind[5:], (kind, 0))[0]
                animal_icon(cell["box"], None, -.076, -.01, .085, False)
                est = int(LOOT.get(kind[5:], ("", 0))[1] * q / 100)
            set_text(cell["nm"], nm if len(nm) < 15 else nm[:14] + ".")
            cell["nm"].color = GOLD if gold else CREAM
            set_text(cell["q"], f"качество {q}%")
            set_text(cell["vl"], f"≈ ${est * (1 if not gold else 1)}")
            set_text(cell["hd"], "В РУКАХ" if i == ci else ("ЗОЛОТОЙ" if gold else ""))
            cell["btn"].set(col=C(96, 76, 28) if i == ci else (C(60, 52, 24) if gold else C(32, 56, 42)))

    # ---- добыча в руках от первого лица
    def update_carry_vm(self, dt):
        item = self.carry_item() if self.mode == "play" and self.overlay in (None, "pause") and not self.me.get("dead") else None
        key = (item_parts(item)[0], item_gold(item)) if item else None
        if key != self.cvm_key:
            if self.cvm is not None:
                destroy(self.cvm)
                self.cvm = None
            self.cvm_key = key
            if key:
                self.cvm = self.make_carry_vm(*key)
        if self.cvm is not None:
            walking = math.sin(self.bob) * .012 if getattr(self, "moving_now", False) else 0.0
            self.cvm.position = (0, -.36 + walking + math.sin(self.t * 1.6) * .003, .92)
            self.cvm.rotation_z = math.sin(self.bob * .5) * 1.2
        if self.vm is not None and self.cvm is not None:
            self.vm.enabled = False

    @staticmethod
    def make_carry_vm(kind, gold):
        """Добыча на руках перед охотником: зверь лежит поперёк, голова вправо, снизу - два предплечья с ладонями."""
        ln, h = w3.carry_size(kind)
        sp = w3.SPECS[kind]
        sc = max(.3, min(1.1, 1.05 / max(ln, .3)))
        holder = Entity(parent=camera)
        m = w3.make_animal(kind, gold, unlit=True)
        m.parent = holder
        m.scale = sc
        m.rotation_y = 90
        m.y = -(sp['leg'][1] + sp['body'][1] / 2) * sc + .03
        coat, skin = C(70, 96, 66), C(226, 186, 150)
        for sx in (-1, 1):
            Entity(parent=holder, model="cube", color=coat, unlit=True, scale=(.11, .1, .75), position=(sx * .36, -.27 - sp['body'][1] * sc * .5, -.18),
                   rotation_y=-sx * 9)
            Entity(parent=holder, model="cube", color=skin, unlit=True, scale=(.1, .08, .13), position=(sx * .31, -.255 - sp['body'][1] * sc * .5, .2))
        return holder

    # ---------------------------------------------------------------- игровой автомат «Золотая тайга»: скины оружия
    REEL_SYMS = ("★", "◆", "♣", "♥", "✦", "●", "♠")
    RAR_SYM = {"common": "●", "rare": "◆", "epic": "✦", "legend": "★"}

    def build_casino(self):
        c = self.casino = Entity(parent=self.ui)
        frame(c, 0, 0, 1.5, .96, PANEL2, z=.1)
        label(c, "ИГРОВОЙ АВТОМАТ «ЗОЛОТАЯ ТАЙГА»", 0, .43, 1.8, GOLD)
        self.c_tok = label(c, "", 0, .375, 1.05, CREAM)
        self.c_reels = []
        for i in range(3):
            x = -.42 + i * .2
            frame(c, x, .2, .17, .22, C(240, 234, 220), r=.015, z=.05)
            self.c_reels.append(label(c, "★", x, .2, 4.2, GOLD, z=.02))
        self.c_res = label(c, "", -.22, .045, 1.2, CREAM)
        self.c_res2 = label(c, "", -.22, .0, .9, DIM)
        self.c_spin = UIButton(c, "", -.22, -.075, .56, .085, self.casino_spin, C(170, 40, 40), 1.25)
        label(c, "Шансы: обычный 58% · редкий 28% · эпический 11% · легендарный 3%. Повтор - 1 жетон назад.", 0, -.145, .72, DIM)
        frame(c, .43, .19, .42, .36, C(16, 24, 20, 240), r=.02, z=.05)
        label(c, "ПРЕДПРОСМОТР", .43, .34, .8, DIM)
        self.c_preview_root = Entity(parent=c, position=(.43, .17, -.1))
        self.c_preview = None
        label(c, "КОЛЛЕКЦИЯ  (◄ ► - выбрать скин для оружия)", -.68, -.21, .9, GOLD, left=True)
        self.c_rows = {}
        for i, wk in enumerate(WEAPONS):
            y = -.27 - i * .055
            label(c, WEAPONS[wk]["name"], -.68, y, .9, CREAM, left=True)
            UIButton(c, "◄", -.2, y, .05, .045, lambda w=wk: self.casino_cycle(w, -1), C(60, 70, 66), .85)
            nm = label(c, "", .08, y, .88, CREAM)
            UIButton(c, "►", .36, y, .05, .045, lambda w=wk: self.casino_cycle(w, 1), C(60, 70, 66), .85)
            cnt = label(c, "", .48, y, .8, DIM, left=True)
            self.c_rows[wk] = (nm, cnt)
        UIButton(c, "ЗАКРЫТЬ (ESC)", 0, -.45, .4, .06, lambda: self.set_overlay(None), C(70, 70, 82), 1.0)
        c.enabled = False
        self.spin = None
        self.near_slot = False

    def open_casino(self):
        self.set_overlay("casino")
        self.refresh_casino()

    def refresh_casino(self):
        me = self.me
        set_text(self.c_tok, f"Жетоны: {me.get('tok', 0)}   ·   золотые звери дают 1-3 жетона")
        self.c_spin.set(f"КРУТИТЬ  ({SPIN_COST} жетона)", off=me.get("tok", 0) < SPIN_COST or self.spin is not None)
        owned, eq = me.get("skins", []), me.get("equip", {})
        for wk, (nm, cnt) in self.c_rows.items():
            k = eq.get(wk)
            if k:
                set_text(nm, SKINS[k][1])
                nm.color = C(*RARITY[SKINS[k][2]][1])
            else:
                set_text(nm, "Стандарт")
                nm.color = CREAM
            total = sum(1 for v in SKINS.values() if v[0] == wk)
            set_text(cnt, f"{sum(1 for x in owned if SKINS[x][0] == wk)}/{total}")

    def casino_cycle(self, wk, d):
        opts = [None] + [k for k in SKINS if SKINS[k][0] == wk and k in self.me.get("skins", [])]
        cur = self.me.get("equip", {}).get(wk)
        k = opts[(opts.index(cur) + d) % len(opts)] if cur in opts else opts[0]
        self.net.send(t="equip", w=wk, skin=k)
        self.me.setdefault("equip", {})
        if k is None:
            self.me["equip"].pop(wk, None)
        else:
            self.me["equip"][wk] = k
        self.show_preview(wk, k)
        self.refresh_casino()
        self.sfx.play("click", .5)

    def show_preview(self, wk, skin):
        if self.c_preview is not None:
            destroy(self.c_preview)
        self.c_preview = w3.make_weapon(wk, self.c_preview_root, unlit=True, skin=skin)
        self.c_preview.scale = .32
        self.c_preview.rotation = (10, 90, 0)

    def casino_spin(self):
        if self.spin is not None or self.me.get("tok", 0) < SPIN_COST:
            return
        self.net.send(t="spin")
        self.spin = dict(t=0.0, result=None, dup=0, stop=[1.4, 1.9, 2.4], done=False, tick=0.0)
        set_text(self.c_res, "Барабаны крутятся...")
        self.c_res.color = CREAM
        set_text(self.c_res2, "")
        self.refresh_casino()

    def update_casino(self, dt):
        sp = self.spin
        if self.c_preview is not None:
            self.c_preview.rotation_y += dt * 40
        if sp is None:
            return
        sp["t"] += dt
        if sp["result"] is None and sp["t"] > 4.0:            # сервер не ответил (например, мало жетонов)
            self.spin = None
            set_text(self.c_res, "")
            return self.refresh_casino()
        rar = SKINS[sp["result"]][2] if sp["result"] else None
        sp["tick"] -= dt
        for i, r in enumerate(self.c_reels):
            stop_t = sp["stop"][i] if sp["result"] else 99
            if sp["t"] < stop_t:
                if sp["tick"] <= 0:
                    set_text(r, random.choice(self.REEL_SYMS))
                    r.color = C(*random.choice([v[1] for v in RARITY.values()]))
            else:
                set_text(r, self.RAR_SYM[rar])
                r.color = C(*RARITY[rar][1])
        if sp["tick"] <= 0:
            sp["tick"] = .05 + .1 * min(1.0, sp["t"] / 2.4)        # барабаны замедляются
            self.sfx.play("pin", .25, 1.6)
        if sp["result"] and sp["t"] >= sp["stop"][-1] and not sp["done"]:
            sp["done"] = True
            k = sp["result"]
            wk, name, rar = SKINS[k][0], SKINS[k][1], SKINS[k][2]
            set_text(self.c_res, f"{RARITY[rar][0].upper()}: {WEAPONS[wk]['name']} «{name}»")
            self.c_res.color = C(*RARITY[rar][1])
            set_text(self.c_res2, "Уже есть - вернули 1 жетон" if sp["dup"] else "Новый скин в коллекции!")
            self.show_preview(wk, k)
            self.sfx.play("levelup" if rar in ("epic", "legend") else "chest", .9)
            if rar == "legend":
                self.shake = max(self.shake, .5)
                self.particles.burst((self.px, 1.6, self.pz), 30, GOLD, speed=2.5, life=1.2, size=.08, up=3.5)
        if sp["done"] and sp["t"] > sp["stop"][-1] + .6:
            self.spin = None
            self.refresh_casino()

    # ---------------------------------------------------------------- пауза
    def build_pause(self):

        p = self.pause = Entity(parent=self.ui)
        frame(p, 0, 0, .66, .86, PANEL2, z=.1)
        label(p, "ПАУЗА", 0, .33, 2.8, GOLD)
        UIButton(p, "ПРОДОЛЖИТЬ", 0, .16, .5, .085, lambda: self.set_overlay(None), size=1.4)
        UIButton(p, "ДЕРЕВО НАВЫКОВ", 0, .055, .5, .085, lambda: self.set_overlay("tree"), C(110, 80, 40), 1.3)
        UIButton(p, "НАСТРОЙКИ", 0, -.05, .5, .085, lambda: self.set_overlay("settings"), C(40, 84, 120), 1.3)
        UIButton(p, "В ГЛАВНОЕ МЕНЮ", 0, -.155, .5, .085, lambda: self.leave(""), C(70, 70, 82), 1.3)
        UIButton(p, "СЮЖЕТНЫЙ РОЛИК", 0, -.26, .5, .085, self.replay_intro, C(90, 70, 110), 1.3)
        UIButton(p, "ВЫЙТИ ИЗ ИГРЫ", 0, -.365, .5, .085, application.quit, C(120, 50, 46), 1.3)
        p.enabled = False

    def set_overlay(self, name):
        if self.mode != "play":
            return
        self.overlay = name
        self.camp.enabled = name == "camp"
        self.tree.enabled = name == "tree"
        self.pause.enabled = name == "pause"
        self.settings_ui.enabled = name == "settings"
        self.help_ui.enabled = name == "help"
        self.dialog.enabled = name == "npc"
        self.butcher_ui.enabled = name == "butcher"
        self.lock_ui.enabled = name == "lock"
        self.casino.enabled = name == "casino"
        self.inv_ui.enabled = name == "inv"
        self.dim.enabled = name not in (None, "butcher", "lock", "intro")
        self.hud.enabled = name is None
        if name is not None:
            self.scope.enabled = False
        mouse.locked = name is None
        mouse.visible = name is not None
        try:
            mouse.raycast = name is not None                   # в игре кнопки не нужны - не обходим сцену лучом на каждый кадр
        except Exception:
            pass
        if name is None:
            self.lock_t = .3                                   # игнорируем скачок мыши в момент захвата
        if name == "camp":
            self.refresh_camp()
        elif name == "tree":
            self.refresh_tree()
        elif name == "settings":
            self.refresh_settings()
        elif name == "npc":
            self.refresh_dialog()

    # ---------------------------------------------------------------- подключение / выход
    def go(self, host, slot=None, name=None):
        name = name or self.name_box.value.strip() or "Охотник"
        addr, port = "127.0.0.1", PORT
        if not host:
            raw = self.addr_box.value.strip() or "127.0.0.1"
            addr = raw
            if ":" in raw:
                addr, p = raw.rsplit(":", 1)
                try:
                    port = int(p)
                except ValueError:
                    self.menu_msg = "Неверный порт в адресе"
                    return self.show_menu("connect")
        else:
            slot = 0 if slot is None else slot
            info = srv.read_slot(slot)
            if info is None:
                srv.new_slot(slot, name)
            else:
                name = info["owner"]                   # играем за охотника из этого слота - прогресс сохраняется
            self.stop_server()                         # прежний мир (другой слот) закрываем, иначе порт занят и подключимся к старому миру
            if not (self.S.get("proc", 1) and USE_SERVER_PROCESS and self.start_server_process(slot, name)):
                try:
                    self.server = srv.run_server(PORT, srv.slot_path(slot), name)
                except OSError:
                    pass                               # порт занят чужим сервером - просто подключимся к нему
        self.S.update(name=name, addr=self.addr_box.value.strip() or "127.0.0.1")
        save_settings(self.S)
        self.shown_addr = f"{lan_ip()}:{PORT}" if host else f"{addr}:{port}"
        self.mode, self.net, self.conn_err, self.conn_t = "connecting", None, None, self.t
        for e in self.pages.values():
            e.enabled = False
        self.loading_txt.text = "Подключение к лагерю..."
        self.loading_txt.enabled = True
        threading.Thread(target=self.connect_worker, args=(addr, port, name), daemon=True).start()

    def connect_worker(self, addr, port, name):
        try:
            self.net = Net(addr, port, name)
        except OSError as e:
            self.conn_err = f"Не удалось подключиться: {e}"

    def start_play(self):
        self.mode = "play"
        self.play_t0 = self.t
        if MT_STATE["note"]:
            self.on_message(MT_STATE["note"])
            MT_STATE["note"] = ""
        self.loading_txt.enabled = False
        for d in self.menu_deer:
            d.enabled = False
        self.hud.enabled = True
        self.snap = self.me = None
        self.cur_loc = None
        self.feed, self.feed_dirty = [], True
        camera.position, camera.rotation = (0, 0, 0), (0, 0, 0)
        camera.fov = self.S["fov"]
        self.rig.rotation = (0, 0, 0)
        self.pit_node.rotation = (0, 0, 0)
        self.first_pos, self.icon_key, self.ads_t = True, None, 0.0
        if self.net.seed != w3.SEED:                          # у сервера своя случайная карта - перестраиваем мир
            w3.SEED = self.net.seed
            srv.set_world_seed(self.net.seed)
            for r in self.worlds.values():
                destroy(r)
            self.worlds = {}
        self.pitch, self.play_t0 = 0.0, self.t
        self.set_overlay(None)
        self.apply_live()
        if not self.S.get("tut"):                              # первый запуск - показываем обучение
            self.S["tut"] = 1
            save_settings(self.S)
            self.open_help()

    def clear_entities(self):
        for rec in list(self.animals.values()) + list(self.players.values()):
            destroy(rec["e"])
        for rec in self.carc.values():
            destroy(rec["e"])
            destroy(rec["m"])
        self.animals, self.players, self.carc = {}, {}, {}
        for q in self.dying:
            if not q["adopted"]:
                destroy(q["e"])
        self.dying = []
        for e in self.floats:
            destroy(e[0])
        self.floats = []

    def start_server_process(self, slot, name):
        """Сервер мира запускается отдельной программой (процессом): звери, погода, сохранения и сеть считаются на
        другом ядре процессора и не отнимают время у отрисовки. Если не получилось - вернём False (сервер будет внутри игры)."""
        import secrets
        token = secrets.token_hex(8)
        args = [sys.executable, os.path.join(HERE, "server.py"), "--port", str(PORT), "--save", srv.slot_path(slot),
                "--owner", name, "--token", token, "--idle-exit", "20", "--slots", srv.SLOTS_DIR]
        try:
            log = open(os.path.join(HOME, "server.log"), "w", encoding="utf-8")
            flags = 0x08000000 if os.name == "nt" else 0          # CREATE_NO_WINDOW: без чёрного окна консоли
            proc = subprocess.Popen(args, cwd=HERE, stdout=log, stderr=subprocess.STDOUT, creationflags=flags)
        except Exception as e:
            print("Не удалось запустить сервер отдельным процессом:", e)
            return False
        t0 = pytime.time()
        while pytime.time() - t0 < 12:                              # ждём, пока сервер начнёт принимать подключения
            if proc.poll() is not None:
                print("Сервер-процесс завершился сразу (см. server.log)")
                return False
            try:
                socket.create_connection(("127.0.0.1", PORT), timeout=.3).close()
                self.server_proc, self.server_token = proc, token
                print("Сервер запущен отдельным процессом, pid", proc.pid)
                return True
            except OSError:
                pytime.sleep(.1)
        try:
            proc.kill()
        except Exception:
            pass
        return False

    def stop_server(self):
        sv = getattr(self, "server", None)
        self.server = None
        if sv is not None:
            try:
                sv.stop()
                pytime.sleep(.15)                      # даём сокету закрыться
            except Exception:
                pass
        proc = getattr(self, "server_proc", None)
        self.server_proc = None
        if proc is not None:
            try:
                proc.wait(timeout=3)                   # сервер сам сохранится и закроется по команде quit
            except Exception:
                try:
                    proc.terminate()
                    proc.wait(timeout=2)
                except Exception:
                    pass

    def replay_intro(self):
        if self.mode == "play" and self.overlay in (None, "pause") and self.cur_loc:
            self.set_overlay(None)
            self.start_intro()

    def leave(self, msg):
        if getattr(self, "intro", None) is not None or getattr(self, "card", None) is not None:
            self.intro = self.card = None
            self.cine_ui.enabled = False
        if self.net and getattr(self, "server_proc", None) is not None:
            try:
                self.net.send(t="quit", token=self.server_token)     # своему серверу-процессу: сохранись и закройся
                pytime.sleep(.1)
            except Exception:
                pass
        if self.net:
            self.net.close()
        self.net = None
        self.stop_server()
        self.clear_entities()
        if self.vm is not None:
            destroy(self.vm)
            self.vm = self.flash = self.vm_kind = None
        self.mode, self.overlay = "menu", None
        for e in (self.camp, self.tree, self.pause, self.hud, self.scope, self.settings_ui, self.help_ui, self.dialog, self.butcher_ui, self.lock_ui, self.casino, self.inv_ui):
            e.enabled = False
        mouse.locked, mouse.visible = False, True
        for d in self.menu_deer:
            d.enabled = True
        if "forest" not in self.worlds:
            self.build_world("forest")
        self.enter_location("forest")
        camera.fov = 70
        self.menu_msg = msg
        self.show_menu("main")
        self.apply_live()

    # ---------------------------------------------------------------- ввод
    def input(self, key):
        if key == "f3" and self.mode == "play":
            return self.toggle_prof()
        if self.rebind:                                        # ждём новую клавишу для действия
            if key.endswith(" up") or "mouse" in key or key.startswith("scroll"):
                return
            return self.finish_rebind(key)
        if key == "left mouse down" and ACTIVE[0] is not None and mouse.hovered_entity is None:
            ACTIVE[0].blur()
        if self.mode == "menu":
            box = ACTIVE[0]
            if box is not None:
                if key == "backspace":
                    box.backspace()
                elif key in ("enter", "escape"):
                    box.blur()
                elif not self.keystroke_ok and len(key) == 1:
                    box.type(key.upper() if held_keys["shift"] else key)
            elif key == self.S["keys"]["help"]:
                self.open_help()
            elif key in ("left arrow", "right arrow") and self.help_ui.enabled:
                self.help_go(-1 if key == "left arrow" else 1)
            elif key == "escape":
                if self.help_ui.enabled:
                    self.close_help()
                elif self.settings_ui.enabled:
                    self.close_settings()
                elif not self.pages["main"].enabled:
                    self.show_menu("main")
            return
        if self.mode != "play" or self.me is None:
            return
        K = self.S["keys"]
        if self.overlay == "butcher":
            if key in ("space", "left mouse down"):
                self.butcher_cut()
            elif key == "escape":
                self.butch = None
                self.set_overlay(None)
            return
        if self.overlay == "intro":
            if key in ("space", "escape", "enter"):
                self.end_intro()
            return
        if self.overlay == "lock":
            if key in ("space", "left mouse down"):
                self.lock_press()
            elif key == "escape":
                self.lock = None
                self.set_overlay(None)
            return
        if key == "escape":
            if self.overlay == "settings":
                self.close_settings()
            else:
                self.set_overlay(None if self.overlay else "pause")
        elif key == K["shop"]:
            if self.overlay == "camp":
                self.set_overlay(None)
            elif self.overlay is None and self.me["camp"]:
                self.set_overlay("camp")
        elif key == K["skills"]:
            self.set_overlay(None if self.overlay == "tree" else ("tree" if self.overlay in (None, "camp") else self.overlay))
        elif key == K["inv"]:
            if self.overlay == "inv":
                self.set_overlay(None)
            elif self.overlay is None:
                self.open_inv()
        elif key == K["carry"] and self.overlay is None:
            self.toggle_carry()
        elif key == K["interact"] and self.overlay is None and self.near_n is None and self.near_slot:
            self.open_casino()
        elif key == K["interact"] and self.overlay is None and self.near_n is None and self.near_ch is not None:
            self.start_lock(self.near_ch)
        elif key == K["interact"] and self.overlay is None and self.near_n is not None:
            self.open_dialog(self.near_n)
        elif key == K["interact"] and self.overlay in (None, "camp") and self.me["camp"]:
            self.net.send(t="sell")
        elif key == K["help"]:
            if self.overlay == "help":
                self.close_help()
            elif self.overlay in (None, "pause"):
                self.open_help()
        elif key == "f3":
            self.dbg_on = not getattr(self, "dbg_on", False)
            self.dbg.enabled = self.dbg_on
        elif key == K["tasks"] and self.overlay is None:
            self.tasks_on = not self.tasks_on
        elif key in ("left arrow", "right arrow") and self.overlay == "help":
            self.help_go(-1 if key == "left arrow" else 1)
        elif key == K["pickup"] and self.overlay is None:
            self.start_butcher()
        elif key == K["jump"] and self.overlay is None and not self.me.get("dead") and self.jump_y <= 0 and self.vy == 0:
            self.vy = 5.4                                          # прыжок: ~1 м вверх
            self.sfx.play("step", .5, .7)
        elif key == "right mouse down" and self.overlay is None and self.S["aim_mode"]:
            self.aim_toggle = 0.0 if self.aim_toggle else 1.0
        elif key in ("1", "2", "3", "4") and self.overlay is None:
            self.net.send(t="buy", w=list(WEAPONS)[int(key) - 1])
            if self.carry_item() is not None:                      # оружие берём в руки - добыча убирается в сумку
                self.carry_ov = (-1, self.t + .6)

    # ---------------------------------------------------------------- авто-качество
    # ступени: что отключается (поверх выбранных игроком настроек) по мере падения FPS. Ступени 1-3 меняются на лету,
    # ступень 4 пересобирает мир без теней (1-2 секунды), ступень 5 - минимум.
    LADDER = (
        {},
        dict(sway=0, lightning=0, particles=1),
        dict(sway=0, lightning=0, particles=1, clouds=0, precip=1, mist=0),
        dict(sway=0, lightning=0, particles=1, clouds=0, precip=1, mist=0, view=0, grass=1),
        dict(sway=0, lightning=0, particles=1, clouds=0, precip=1, mist=0, view=0, grass=1, shadows=0, density=0),
        dict(sway=0, lightning=0, particles=0, clouds=0, precip=0, mist=0, view=0, grass=0, shadows=0, density=0, fog=1),
    )
    TARGET_FPS = 60.0

    def perf_govern(self, raw):
        """Каждые 2 секунды смотрим средний FPS. Если он ниже ~50, снижаем качество на ступень (см. LADDER), если с большим
        запасом выше 60 - возвращаем. Выбранные игроком настройки не трогаются и после перезапуска действуют снова."""
        self.pf_t = getattr(self, "pf_t", 0.0) + raw
        self.pf_n = getattr(self, "pf_n", 0) + 1
        if self.pf_t < 2.0:
            return
        fps = self.pf_n / self.pf_t
        self.pf_t, self.pf_n = 0.0, 0
        self.fps_now = fps
        d = getattr(self, "detail", 1.0)
        calm = self.mode == "play" and self.overlay in (None, "pause") and self.intro is None and self.t - getattr(self, "play_t0", 0) > 8
        if not self.S.get("auto_q") or not calm:
            self.low_t = self.high_t = 0.0
            self.detail = self.atmo.detail = 1.0 if not self.S.get("auto_q") else d
            if not self.S.get("auto_q") and self.q_level:
                self.set_quality(0)
            return
        # дальность травы - плавно, остальное - ступенями
        d = max(.2, d - .15) if fps < 35 else (max(.2, d - .06) if fps < 50 else (min(1.0, d + .06) if fps > 62 else d))
        self.detail = self.atmo.detail = d
        if fps < self.TARGET_FPS * .83:
            self.low_t = getattr(self, "low_t", 0.0) + 2.0
            self.high_t = 0.0
            if self.low_t >= 4.0 and self.q_level < len(self.LADDER) - 1:         # 4 секунды подряд ниже ~50 FPS
                self.low_t = 0.0
                self.set_quality(self.q_level + 1)
        elif fps > self.TARGET_FPS * 1.3 and 0 < self.q_level < 4:                 # устойчиво 78+ FPS: пробуем вернуть ступень
            self.high_t = getattr(self, "high_t", 0.0) + 2.0
            self.low_t = 0.0
            if self.high_t >= 24.0:
                self.high_t = 0.0
                self.set_quality(self.q_level - 1)
        else:
            self.low_t = max(0.0, getattr(self, "low_t", 0.0) - 1.0)
            self.high_t = 0.0

    def set_quality(self, lv, quiet=False):
        old = self.q_level
        self.q_level = lv
        ov = dict(self.LADDER[lv])
        self.mist_off = ov.pop("mist", 1) == 0
        user = self.S                                       # потолок: не выше выбранного игроком (ничего не повышаем)
        self.S.ov = {k: v for k, v in ov.items() if k not in user or v < dict.__getitem__(user, k) or k in ("fog",)}
        if "fog" in ov:
            self.S.ov["fog"] = 1
        self.atmo.detail = getattr(self, "detail", 1.0)
        if hasattr(self.particles, "level"):
            self.particles.level = self.S["particles"]
            self.smoke.level = self.S["particles"]
        need_rebuild = ov.get("shadows", None) == 0 and w3.SHADER is not None
        if need_rebuild:
            self.go_light_mode(rebuild_only=True)
        if not quiet and lv != old:
            names = ("максимальное", "ступень 1: без колыхания травы и молний", "ступень 2: без облаков, лёгкий дождь, без полос тумана",
                     "ступень 3: ближе дальность прорисовки, меньше травы", "ступень 4: без теней и с редкой растительностью", "ступень 5: минимум")
            self.on_message(f"Качество снижено ({names[lv]}), чтобы держать 60 FPS. Отключить: Настройки - Графика - Авто-качество"
                            if lv > old else f"Качество возвращено ({names[lv]})")

    def go_light_mode(self, rebuild_only=False):
        """Слабый компьютер: выключаем тени и попиксельное освещение и один раз перестраиваем мир с запечённым светом.
        Выбранные игроком настройки не меняются: после перезапуска тени вернутся."""
        self.low_hits = 0
        w3.SHADER, w3.BAKE = None, True
        w3.DENSITY = DENSITY[self.S["density"]]
        w3.GRASS_LEVEL = self.S["grass"]
        try:
            if self.sun is not None:
                self.sun.shadows = False
        except Exception:
            pass
        self.sun = None
        loc = self.cur_loc
        for r in self.worlds.values():
            destroy(r)
        self.worlds = {}
        self.cur_loc = None
        self.fire = self.grass = None
        self.build_world("forest" if loc is None else loc)
        self.enter_location("forest" if loc is None else loc)
        self.freeze_heap()

    # ---------------------------------------------------------------- игровой цикл
    # ---------------------------------------------------------------- профилировщик (F3) и сведения о видеокарте
    PROF_TARGETS = (("handle_events", "события"), ("sync_entities", "звери и игроки"), ("control", "управление"),
                    ("update_viewmodel", "оружие в руках"), ("update_npcs", "NPC"), ("update_world_objects", "сундуки, ворота"),
                    ("update_hud", "интерфейс"), ("update_audio", "звук"), ("update_shadows", "тени"),
                    ("update_projectiles", "пули и гильзы"), ("update_mist", "туман"), ("update_card", "ролик"), ("update_radar", "радар"))

    def toggle_prof(self):
        self.prof_on = not self.prof_on
        self.pacc = {}
        self.pn = 0
        if self.prof_on:
            for name, label_ in self.PROF_TARGETS:
                self._wrap(self, name, label_)
            for obj, name, label_ in ((self.atmo, "update", "небо и погода"), (self.precip, "update", "дождь и снег"),
                                      (self.smoke, "update", "дым"), (self.particles, "update", "частицы"), (self.critters, "update", "живность")):
                self._wrap(obj, name, label_)
            import grass as _g
            self._wrap_cls(_g.GrassField, "update", "трава")
        else:
            for obj in (self, self.atmo, self.precip, self.smoke, self.particles, self.critters):
                for name in list(vars(obj)):
                    f = getattr(obj, name, None)
                    if getattr(f, "hth_orig", None) is not None:
                        setattr(obj, name, f.hth_orig)
            import grass as _g
            if getattr(_g.GrassField.update, "hth_orig", None) is not None:
                _g.GrassField.update = _g.GrassField.update.hth_orig
        self.on_message("Профилировщик " + ("включён (F3 - выключить): время на кадр по частям игры" if self.prof_on else "выключен"))

    def _wrap(self, obj, name, label_):
        f = getattr(obj, name, None)
        if f is None or getattr(f, "hth_orig", None) is not None:
            return

        def w(*a, **k):
            t0 = pytime.perf_counter()
            try:
                return f(*a, **k)
            finally:
                self.pacc[label_] = self.pacc.get(label_, 0.0) + pytime.perf_counter() - t0
        w.hth_orig = f
        setattr(obj, name, w)

    def _wrap_cls(self, cls, name, label_):
        f = cls.__dict__.get(name)
        if f is None or getattr(f, "hth_orig", None) is not None:
            return

        def w(*a, **k):
            t0 = pytime.perf_counter()
            try:
                return f(*a, **k)
            finally:
                self.pacc[label_] = self.pacc.get(label_, 0.0) + pytime.perf_counter() - t0
        w.hth_orig = f
        setattr(cls, name, w)

    def detect_gpu(self):
        """Название видеокарты, на которой реально работает игра (на ноутбуках с двумя видеокартами это часто встроенная)."""
        try:
            from ursina import application
            gsg = application.base.win.getGsg()
            name = str(gsg.getDriverRenderer()).split("/")[0].strip()
            return name if name and "Any" not in name else ""
        except Exception:
            return ""

    def update(self):
        t_enter = pytime.perf_counter()
        now = t_enter
        raw = now - self.last
        dt = min(.1, raw)
        self.last = now
        self.t += dt
        self.frame_i = getattr(self, "frame_i", 0) + 1
        self.perf_govern(raw)
        self.fps_n += 1
        self.fps_t += raw
        if self.fps_t >= .5 and hasattr(self, "t_fps"):            # свой счётчик FPS (встроенный в Ursina прячется за панелью)
            fps = self.fps_n / self.fps_t
            self.fps_n, self.fps_t = 0, 0.0
            on = bool(self.S["fps"])
            self.t_fps.enabled = on
            if on:
                eng = max(0.0, self.frame_ms - self.py_ms)
                set_text(self.t_fps, f"FPS {fps:.0f}   {1000 / max(fps, .1):.0f} мс  (игра {self.py_ms:.0f} + движок/GPU {eng:.0f})"
                         + (f"   ступень {self.q_level}" if self.q_level else "") + ("   VSync" if self.S["vsync"] else ""))
                self.t_fps.color = C(120, 230, 120) if fps >= 50 else (C(240, 210, 90) if fps >= 30 else C(240, 90, 80))
                set_text(self.t_gpu, ("GPU: " + self.gpu) if self.gpu else "")
                if self.prof_on and self.pn:
                    rows = sorted(self.pacc.items(), key=lambda kv: -kv[1])[:9]
                    set_text(self.t_prof, "\n".join(f"{k}: {v / self.pn * 1000:.1f} мс" for k, v in rows))
                    self.pacc, self.pn = {}, 0
                else:
                    set_text(self.t_prof, "")
        self.quiet_t -= raw
        if getattr(self, "_qs", None) is not None:                # идёт проверка объектов: по 250 за кадр
            self.quiet_static(250)
        elif self.quiet_t <= 0:                                   # новые объекты (звери, следы, туши) - раз в 3 секунды
            self.quiet_t = 3.0
            self.quiet_static(250)
        if self.gpu and not getattr(self, "gpu_hint", False) and self.mode == "play" and self.t - getattr(self, "play_t0", 0) > 12 \
                and getattr(self, "fps_now", 99) < 40 and any(w_ in self.gpu.lower() for w_ in ("intel", "uhd", "iris", "basic render", "llvmpipe")):
            self.gpu_hint = True                                  # работаем на встроенной видеокарте и тормозит
            self.on_message("Игра идёт на встроенной видеокарте. Если есть мощная: Параметры Windows - Система - Дисплей - Графика - "
                            "pythonw.exe - «Высокая производительность»")
        if self.mode == "menu":
            self.update_menu(dt)
        elif self.mode == "connecting":
            self.update_connecting()
            if self.mode == "connecting":
                self.update_menu(dt)
        else:
            self.update_play(dt)
        self.particles.update(dt)
        py = (pytime.perf_counter() - t_enter) * 1000
        self.py_ms += (py - self.py_ms) * .08
        self.frame_ms += (raw * 1000 - self.frame_ms) * .08
        if self.prof_on:
            self.pn = getattr(self, "pn", 0) + 1

    def update_menu(self, dt, keep_ui=False):
        self.rig.position = (CAMP[0], 7, CAMP[1])
        self.rig.rotation_y = self.t * 5
        self.pit_node.rotation_x = 11
        camera.position = (0, 0, -32)
        camera.rotation = (0, 0, 0)
        camera.fov = 70
        if self.fire:
            self.fire.update(self.t, dt, True)
        if ACTIVE[0] is not None:
            ACTIVE[0].tick(int(self.t * 2) % 2 == 0)
        self.atmo.update(dt, (CAMP[0], 7, CAMP[1]), "forest", self.S, "clear")
        self.precip.update(dt, (CAMP[0], 7, CAMP[1]), self.t, 0, 0, 0, 0)
        if self.grass:
            self.grass.update(self.t, (CAMP[0], 7, CAMP[1]), self.atmo.cur["wind"], bool(self.S["sway"]), self.S["view"])
        self.update_shadows(CAMP[0], CAMP[1], dt)
        self.sfx.level("music", 1.0)
        self.sfx.level("wind", .12)
        self.sfx.level("fire", .35)
        self.sfx.level("rain", 0)

    def update_connecting(self):
        if self.conn_err:
            err = self.conn_err
            self.mode = "menu"
            self.menu_msg = err
            return self.show_menu("connect")
        net = self.net
        if net and net.id is not None and net.state is not None:
            return self.start_play()
        if self.t - self.conn_t > 12:
            self.mode = "menu"
            self.menu_msg = "Сервер не отвечает"
            if net:
                net.close()
            self.show_menu("connect")

    def update_shadows(self, x, z, dt):
        if self.sun is None:
            return
        buf = getattr(self, "shadow_buf", None)                   # карта теней перерисовывается через кадр - вдвое дешевле, на глаз не видно
        if buf is None:
            try:
                buf = self.sun._light.getShadowBuffer(self.base.win.getGsg()) or False
            except Exception:
                buf = False
            self.shadow_buf = buf
        if buf:
            try:
                buf.setActive(self.frame_i % 2 == 0)
            except Exception:
                self.shadow_buf = False
        self.shadow_t = getattr(self, "shadow_t", 0.0) - dt
        if self.shadow_t <= 0:
            self.shadow_t = .5
            try:
                self.shadow_box.position = (x, 0, z)
                self.sun.update_bounds(self.shadow_box)
            except Exception:
                self.sun = None

    def update_play(self, dt):
        net = self.net
        if not net.alive:
            return self.leave("Соединение с сервером потеряно")
        with net.lock:
            snap, evs, msgs = net.state, net.events, net.msgs
            net.events, net.msgs = [], []
        if snap is None:
            return
        self.snap, self.me = snap, snap["you"]
        me = self.me
        if snap["loc"] != self.cur_loc:
            if snap["loc"] not in self.worlds:
                if not self.loading:                         # даём кадр показать «Загрузка...»
                    self.loading = True
                    self.loading_txt.text = f"Загрузка: {LOCS[snap['loc']]['name']}..."
                    self.loading_txt.enabled = True
                    return
                self.build_world(snap["loc"])
                self.loading = False
                self.loading_txt.enabled = False
            self.clear_entities()
            self.enter_location(snap["loc"])
            self.first_pos = True
        for m in msgs:
            self.on_message(m)
        mine = next((p for p in snap["pl"] if p[0] == net.id), None)
        if mine is not None and self.first_pos:
            self.px, self.pz, self.first_pos = mine[2], mine[3], False
        self.handle_events(evs)
        if self.intro_pending and self.cur_loc and self.intro is None:
            self.start_intro()
        self.sync_entities(snap, dt)
        if self.intro is not None:
            self.update_intro(dt)                              # вступительный ролик: камерой управляет режиссёр
        else:
            self.control(dt, mine)
            self.update_viewmodel(dt)
        self.update_card(dt)
        self.animate(dt)
        self.update_npcs(dt)
        self.update_world_objects(snap, dt)
        self.hud_acc += dt
        if self.hud_acc >= 1 / 24:                              # панель интерфейса обновляем 24 раза в секунду - глазу хватает
            self.update_hud(self.hud_acc)
            self.hud_acc = 0.0
        self.update_tasks()
        self.update_audio(dt)
        eye = tuple(self.rig.position)                         # точная позиция камеры (с покачиванием)
        wx = snap.get("wx", "clear")
        self.wx_name = wx
        if wx != self.wx:
            self.wx = wx
            self.feed.append((self.t, "Погода: " + fx.WX_RU.get(wx, wx)))
            self.feed_dirty = True
        self.atmo.update(dt, eye, self.cur_loc, self.S, wx)
        cw = self.atmo.cur
        if self.grass:
            self.grass.update(self.t, eye, cw["wind"], bool(self.S["sway"]), self.S["view"], detail=getattr(self, "detail", 1.0))
        self.precip.update(dt, eye, self.t, cw["rain"], cw["snow"], cw["wind"], self.S["precip"])
        for ev in self.atmo.events:                           # молния: вспышка, зигзаг и гром с задержкой
            _, ang, dist = ev
            self.bolt.strike(eye, ang, dist)
            self.thunder_q.append((self.t + dist / 340 * 3, max(.25, 1 - dist / 220)))
        self.atmo.events = []
        self.bolt.update(dt)
        for item in self.thunder_q[:]:
            if self.t >= item[0]:
                self.sfx.play("thunder", item[1])
                self.thunder_q.remove(item)
        self.update_shadows(self.px, self.pz, dt)
        self.update_projectiles(dt)
        self.smoke.update(dt)
        if getattr(self, "dbg_on", False):
            self.update_debug(dt)
        self.critters.update(dt, self.t, eye, self.cur_loc, fx.phase_of(self.S["tod"]), self.atmo.cur["rain"], self.S["particles"])
        if self.overlay == "butcher":
            self.update_butcher(dt)
        elif self.overlay == "lock":
            self.update_lock(dt)
        if self.overlay == "casino":
            self.update_casino(dt)
        elif self.overlay == "inv":
            self.refresh_inv()
        self.update_mist(dt, eye)
        self.cull_t -= dt
        if self.cull_t <= 0:                                     # уровни детализации мира, раз в полсекунды
            self.cull_t = .4
            lim = getattr(self.atmo, "far", 1e9) + 46            # дальше тумана ничего не рисуем
            near_r = 100.0                                       # деревья ближе 100 м от игрока всегда подробные (считаем по ближнему краю участка)
            px, pz = self.px, self.pz
            for e, cx, cz, inside, layer, hs in getattr(self.worlds[self.cur_loc], "hth_chunks", []):
                d = math.hypot(max(abs(cx - px) - hs, 0.0), max(abs(cz - pz) - hs, 0.0))
                if layer == "base" or layer[0] == "g":
                    vis = d < (lim if inside else lim + 70)             # далёкие горы за туманом не рисуем
                elif layer == "near":
                    vis = d < near_r
                else:
                    vis = near_r <= d < lim
                if e.enabled != vis:
                    e.enabled = vis
        if self.overlay == "camp" and not me["camp"]:
            self.set_overlay(None)
        if self.overlay == "npc":
            self.refresh_dialog()
        if self.overlay == "camp":
            self.refresh_camp()
        elif self.overlay == "tree":
            self.refresh_tree()
            self.refresh_info()
            for k, n in self.nodes.items():
                if n["state"] == "avail":
                    n["ring"].scale = .098 * (1 + .07 * math.sin(self.t * 5))
                else:
                    n["ring"].scale = .098 * (1.12 if self.tree_hover == k else 1)

    def on_message(self, m):
        self.feed.append((self.t, m))
        self.feed_dirty = True
        for pre, snd in MSG_SOUND:
            if m.startswith(pre):
                self.sfx.play(snd, .8)
                break
        if m.startswith("Новый уровень"):
            self.banner_t = 2.6
            set_text(self.banner, f"УРОВЕНЬ {self.me['lv']}!")
        if m.startswith("Продано"):
            self.done("sell")
        elif m.startswith("Навык «"):
            self.done("skill")

    # ---------------------------------------------------------------- управление и камера
    def control(self, dt, mine):
        me, S = self.me, self.S
        free = self.overlay is None and not me.get("dead")
        wk = me["w"]
        K = S["keys"]
        rmb = (held_keys["right mouse"] or getattr(mouse, "right", False)) if not S["aim_mode"] else self.aim_toggle
        carrying = self.carry_item() is not None
        self.ads = bool(free and mouse.locked and rmb and not me["camp"] and not carrying)
        if me["camp"]:
            self.aim_toggle = 0.0
        self.ads_t += ((1.0 if self.ads else 0.0) - self.ads_t) * min(1, dt * 9)
        base_fov = S["fov"]
        camera.fov = base_fov * (1 - (1 - ZOOM[wk]) * self.ads_t)
        sens = S["sens"] * (camera.fov / base_fov) * (1 + (S["ads_sens"] / 100 - 1) * self.ads_t)
        self.lock_t = max(0.0, getattr(self, "lock_t", 0.0) - dt)
        if free and mouse.locked and self.lock_t <= 0:
            dyaw = max(-30, min(30, mouse.velocity[0] * sens))
            self.yaw += dyaw
            dy_ = max(-30, min(30, mouse.velocity[1] * sens)) * (-1 if S["inv_y"] else 1)
            self.pitch = max(-85, min(85, self.pitch - dy_))
            self.look_acc += abs(dyaw)
            if self.look_acc > 90:
                self.done("look")
        f = (held_keys[K["forward"]] - held_keys[K["back"]]) if free else 0
        r = (held_keys[K["right"]] - held_keys[K["left"]]) if free else 0
        yr = math.radians(self.yaw)
        wx, wz = f * math.sin(yr) + r * math.cos(yr), f * math.cos(yr) - r * math.sin(yr)
        n = math.hypot(wx, wz)
        if n > 1:
            wx, wz = wx / n, wz / n
        sprint = bool(held_keys[K["sprint"]]) and f > 0 and not self.ads
        cm = CARRY_SLOW.get(item_parts(self.carry_item())[0], .85) if carrying else 1.0
        speed = me["spd"] * (ADS_SPEED if self.ads else (me["spr"] if sprint else 1)) * cm
        self.px, self.pz = srv.move(self.px, self.pz, wx * speed * dt, wz * speed * dt, self.cur_loc, bool(me.get("radar")))   # те же коллизии, что на сервере
        self.px, self.pz = max(3, min(W - 3, self.px)), max(3, min(H - 3, self.pz))
        if free and n > .01:
            self.walked += speed * dt
            if self.walked > 6:
                self.done("move")
        if sprint:
            self.sprint_t += dt
            if self.sprint_t > 1.2:
                self.done("sprint")
        if self.ads_t > .85:
            self.done("aim")
        if not me["camp"]:
            self.done("leave")
        if mine is not None:                                  # сверка с сервером
            ex, ez = mine[2] - self.px, mine[3] - self.pz
            if math.hypot(ex, ez) > 4:
                self.px, self.pz = mine[2], mine[3]
            elif n <= .01:
                k = min(1, dt * 8)
                self.px, self.pz = self.px + ex * k, self.pz + ez * k
        ang, pit = math.radians(90 - self.yaw), math.radians(-self.pitch)
        if self.t - self.last_in > .05:
            self.last_in = self.t
            self.net.send(t="in", dx=round(wx, 3), dy=round(wz, 3), ang=round(ang, 3), pit=round(pit, 3),
                          sp=sprint, ads=self.ads, jy=round(self.jump_y, 2))
        self.local_cd = max(0, self.local_cd - dt)
        if free and mouse.locked and held_keys["left mouse"] and self.local_cd <= 0 and not me["camp"] and carrying:
            if self.t > self.hostile_t:                           # руки заняты добычей - стрелять нельзя
                self.hostile_t = self.t + 3
                self.on_message("Руки заняты добычей: положите её (G) или возьмите оружие (1-4)")
        elif free and mouse.locked and held_keys["left mouse"] and self.local_cd <= 0 and not me["camp"]:
            self.net.send(t="shoot", ang=round(ang, 3), pit=round(pit, 3), ads=self.ads)
            self.done("shoot")
            self.local_cd = WEAPONS[wk]["cd"] * me["cdm"]
            self.recoil, self.flash_t = 1.0, .06
            self.pitch -= .5 if self.ads else 1.1
            self.sfx.play(SHOT[wk], 1.0, random.uniform(.96, 1.04))
            self.shot_effects(wk)
        moving = n > .01
        self.moving_now = moving
        if moving and free:                                   # шаги и покачивание камеры
            self.step_t -= dt
            if self.step_t <= 0:
                self.step_t = .3 if sprint else .46
                self.sfx.play("step", .35, random.uniform(.85, 1.15))
            self.bob += dt * (9 if sprint else 6)
        bob = math.sin(self.bob) * .035 if (moving and S["bob"] and self.jump_y <= 0) else 0
        if self.vy or self.jump_y > 0:                        # прыжок: подъём и падение с ускорением свободного падения
            self.vy -= 15.5 * dt
            self.jump_y += self.vy * dt
            if self.jump_y <= 0:
                if self.vy < -3:
                    self.land = .14                            # приземление: камера немного проседает
                    self.sfx.play("step", .7, .6)
                self.jump_y, self.vy = 0.0, 0.0
        self.land = max(0.0, self.land - dt)
        dip = math.sin(self.land / .14 * math.pi) * .09 if self.land > 0 else 0.0
        self.shake = max(0.0, self.shake - dt * 5)
        sh = self.shake * self.shake
        self.rig.position = (self.px, EYE + bob + self.jump_y - dip, self.pz)
        self.rig.rotation_y = self.yaw + random.uniform(-1, 1) * sh * .6
        self.pit_node.rotation_x = self.pitch + random.uniform(-1, 1) * sh * .8
        self.pit_node.rotation_z = random.uniform(-1, 1) * sh * 1.2
        camera.position, camera.rotation = (0, 0, 0), (0, 0, 0)       # только вид от первого лица
        self.near_slot = self.cur_loc is not None and math.hypot(SLOT_POS[0] - self.px, SLOT_POS[1] - self.pz) < 2.6
        self.near_ch = None                                   # ближайший полный сундук для подсказки «E»
        for cid, c in self.chests.items():
            if c["avail"] and math.hypot(c["x"] - self.px, c["z"] - self.pz) < 2.8:
                self.near_ch = cid
        # ближайшая туша для подсказки «F»
        self.near_c = None
        best = PICKUP_R
        for rec in self.carc.values():
            d = math.hypot(rec["x"] - self.px, rec["z"] - self.pz)
            if d < best:
                best, self.near_c = d, rec

    def update_viewmodel(self, dt):
        kind = self.me["w"]
        skin = self.me.get("equip", {}).get(kind)
        if (kind, skin) != self.vm_kind:
            if self.vm is not None:
                destroy(self.vm)
            self.vm = w3.make_weapon(kind, camera, unlit=True, dyn=True, skin=skin)
            self.vm.scale = .6
            self.bow_s1 = None
            if kind == "bow":                                  # тетива (две нити) и стрела
                cream = C(235, 230, 205)
                self.bow_s1 = Entity(parent=self.vm, model="cube", color=cream, unlit=True)
                self.bow_s2 = Entity(parent=self.vm, model="cube", color=cream, unlit=True)
                self.bow_arrow = Entity(parent=self.vm, model="cube", color=C(214, 192, 140), unlit=True, scale=(.014, .014, .75))
                self.bow_tip = Entity(parent=self.vm, model="cube", color=C(70, 70, 78), unlit=True, scale=(.035, .035, .06))
            self.flash = Entity(parent=self.vm.hth_muzzle, model="sphere", scale=.2, color=C(255, 220, 120), unlit=True)
            self.flash.enabled = False
            self.vm_kind = (kind, skin)
        self.recoil = max(0, self.recoil - dt * 7)
        self.flash_t = max(0, self.flash_t - dt)
        self.flash.enabled = self.flash_t > 0
        a = self.ads_t
        hx, hy, hz = .24, -.22, .55
        ax, ay, az = ADS_POS[kind]
        sway = math.sin(self.t * 1.7) * .004 * (1 - a)
        self.vm.position = (hx + (ax - hx) * a + sway, hy + (ay - hy) * a - .02 * self.recoil,
                            hz + (az - hz) * a - .12 * self.recoil)
        self.vm.rotation_x = -8 * self.recoil
        self.vm.rotation_y = 10 * a if kind == "bow" else 0
        if self.bow_s1 is not None:
            nz = -.15 - .3 * a                                 # чем дольше целишься, тем сильнее оттянута тетива
            for st, y0 in ((self.bow_s1, .5), (self.bow_s2, -.5)):
                dy, dz = -y0, nz + .13
                st.position = (0, y0 / 2, (nz - .13) / 2)
                st.rotation_x = -math.degrees(math.atan2(dy, dz))
                st.scale = (.012, .012, math.hypot(dy, dz))
            self.bow_arrow.position = (0, 0, nz + .375 - .02 * self.recoil)
            self.bow_tip.position = (0, 0, nz + .75 - .02 * self.recoil)
        self.vm.enabled = (self.overlay is None or self.overlay == "pause") and not (kind == "sniper" and a > .6)
        self.update_carry_vm(dt)

    def update_audio(self, dt):
        cw = self.atmo.cur
        self.sfx.level("music", .22)
        self.sfx.level("wind", (.5 if self.cur_loc == "tundra" else .2) + .45 * cw["wind"])
        self.sfx.level("rain", min(1.0, cw["rain"] / 2 * .9) if self.S["precip"] else 0)
        dc = math.hypot(CAMP[0] - self.px, CAMP[1] - self.pz)
        self.sfx.level("fire", max(0.0, 1 - dc / 35) * .6)
        if self.cur_loc in ("forest", "thicket") and self.atmo.cur["rain"] < .5:
            self.bird_t -= dt
            ph = fx.phase_of(self.S["tod"])
            if self.cur_loc == "thicket" and self.bird_t <= 0:  # в чаще вместо щебета - кукушка днём и сова ночью
                self.bird_t = random.uniform(9, 20)
                self.sfx.play("cuckoo" if .08 < ph < .66 else "owl", random.uniform(.25, .45), random.uniform(.95, 1.05))
                return
            if self.bird_t <= 0:
                self.bird_t = random.uniform(6, 14)
                self.sfx.play(random.choice(("bird1", "bird2")), random.uniform(.25, .5), random.uniform(.9, 1.15))

    # ---------------------------------------------------------------- события выстрелов
    def handle_events(self, evs):
        for ev in evs:
            mine = ev.get("p") == self.net.id
            dist = math.hypot(ev["x"] - self.px, ev["y"] - self.pz)
            far = max(0.0, 1 - dist / 120)
            if ev["k"] == "shot":
                a = Vec3(ev["x"], ev["z"], ev["y"])
                b = Vec3(ev["x2"], ev["z2"], ev["y2"])
                if mine and self.vm is not None:
                    a = self.vm.hth_muzzle.world_position
                elif not mine:
                    self.sfx.play(SHOT.get(ev.get("w"), "rifle"), far * .9, random.uniform(.96, 1.04))
                    self.smoke.burst(a, 3, C(200, 200, 204, 140), speed=.3, life=1.2, size=.12, up=.6, grav=-.5, grow=3.0)
                ground = ev["z2"] < .08
                if ev.get("w") == "bow":
                    self.spawn_arrow(a, b, ground)
                else:
                    self.spawn_tracer(a, b, .25 if ev.get("w") == "sniper" else .09)
                if ground:                                          # попадание в землю: пыль, комья, след
                    self.particles.burst((ev["x2"], .1, ev["y2"]), 8, C(150, 120, 80), speed=1.4, life=.6, size=.1, up=2.4)
                    self.smoke.burst((ev["x2"], .15, ev["y2"]), 3, C(170, 150, 120, 120), speed=.4, life=1.0, size=.15, up=.4, grav=-.2, grow=2.5)
                    if ev.get("w") != "bow":
                        self.spawn_decal(ev["x2"], ev["y2"])
            elif ev["k"] == "hit":
                if mine:
                    self.hit_t = .18
                    self.hitmark.color = RED if ev["dead"] else WHITE
                    if ev["dead"]:
                        self.done("kill")
                self.sfx.play("kill" if ev["dead"] else ("crit" if ev["c"] else "hit"), (1.0 if mine else far) * .9)
                if not ev["dead"]:                                  # зверь вздрагивает от попадания
                    hurt = min(self.animals.values(), key=lambda r: math.hypot(r["x"] - ev["x"], r["z"] - ev["y"]), default=None)
                    if hurt is not None and math.hypot(hurt["x"] - ev["x"], hurt["z"] - ev["y"]) < 3:
                        hurt["flinch"] = .35
                self.particles.burst((ev["x"], ev["z"] + .2, ev["y"]), 18 if ev["dead"] else 9, C(170, 40, 30),
                                     speed=2.4, life=.7, size=.13, up=3.2)
                self.smoke.burst((ev["x"], ev["z"] + .2, ev["y"]), 3, C(150, 30, 30, 110), speed=.5, life=.6, size=.15, up=.5, grav=0, grow=2.0)
                if ev["c"]:                                         # крит: золотые искры
                    self.particles.burst((ev["x"], ev["z"] + .3, ev["y"]), 10, GOLD, speed=2.0, life=.4, size=.06, up=2.5)
                txt = Text(text=f"{ev['d']:g}" + ("!" if ev["c"] else ""), parent=scene, position=(ev["x"], ev["z"] + 1.0, ev["y"]),
                           origin=(0, 0), scale=22 if ev["c"] else 16, billboard=True,
                           color=C(255, 140, 40) if ev["c"] else C(255, 245, 220))
                self.floats.append([txt, .9, ev["z"] + 1.0])
            elif ev["k"] == "hurt":
                if mine and self.t > self.hostile_t and (self.boss_rec is None or math.hypot(self.boss_rec["x"] - ev["x"], self.boss_rec["z"] - ev["y"]) > 6):
                    self.hostile_t = self.t + 25
                    self.on_message("На вас напали! Отстреливайтесь или бегите в лагерь - туда звери не заходят")
                if mine:                                         # по нам попали: вспышка, тряска, звук
                    self.flash_red, self.shake = 1.0, 1.2
                    self.sfx.play("hurt", .9)
                else:
                    self.sfx.play("hurt", far * .5)
                self.particles.burst((ev["x"], 1.0, ev["y"]), 8, C(170, 40, 30), speed=1.5, life=.5, size=.1, up=2.0)
            elif ev["k"] == "spin":
                if mine and self.spin is not None:
                    self.spin["result"], self.spin["dup"] = ev["skin"], ev["dup"]
            elif ev["k"] == "golden":
                self.particles.burst((ev["x"], .8, ev["y"]), 26, GOLD, speed=2.2, life=1.0, size=.08, up=3.0)
                if mine:
                    self.sfx.play("levelup", .7, 1.2)
            elif ev["k"] == "story":
                if mine:
                    self.show_card(ev["ch"])
            elif ev["k"] == "shield":
                self.particles.burst((ev["x"], ev["z"] + .5, ev["y"]), 14, C(110, 220, 255), speed=2.0, life=.45, size=.08, up=1.8)
                self.sfx.play("pin", .7, 1.7)
            elif ev["k"] == "chest":
                self.sfx.play("chest", (1.0 if mine else far) * .9)
                self.particles.burst((ev["x"], .9, ev["y"]), 22, GOLD, speed=1.8, life=1.0, size=.09, up=3.5)
            elif ev["k"] == "pick":
                if mine:
                    self.done("pick")
                self.sfx.play("pickup", (1.0 if mine else far) * .8)
                self.particles.burst((ev["x"], .6, ev["y"]), 12, GOLD, speed=1.6, life=.8, size=.1, up=3.0)

    def update_debug(self, dt):
        """F3: данные для диагностики (их удобно прислать скриншотом, если что-то выглядит не так)."""
        self.dbg_t = getattr(self, "dbg_t", 0.0) - dt
        if self.dbg_t > 0:
            return
        self.dbg_t = .5
        ch = getattr(self.worlds.get(self.cur_loc), "hth_chunks", [])
        cnt = {}
        for e, cx, cz, inside, layer, hs in ch:
            if e.enabled:
                cnt[layer] = cnt.get(layer, 0) + 1
        vis = sum(1 for r in self.animals.values() if r["e"].enabled)
        g = self.grass
        gv = sum(1 for st in g.state.values() if st) if g is not None and getattr(g, "state", None) else 0
        set_text(self.dbg, "\n".join((
            f"FPS {getattr(self, 'fps_now', 0):.0f} | {self.cur_loc} | погода {getattr(self, 'wx_name', '?')}",
            f"туман {scene.fog_density[0]:.0f}-{scene.fog_density[1]:.0f} м | тени {'вкл' if self.sun is not None else 'выкл'}",
            f"участки мира: основа {cnt.get('base', 0)}, подробные {cnt.get('near', 0)}, дальние {cnt.get('far', 0)}",
            f"трава: ячеек {gv} | звери: {len(self.animals)} (рисуются {vis})",
            f"позиция {self.px:.0f}, {self.pz:.0f}")))

    def update_world_objects(self, snap, dt):
        """Сундуки (крышка открывается, полные искрятся), подписи построек, босс и его рёв."""
        state = {cid: avail for cid, avail in snap.get("ch", [])}
        self.spark_t -= dt
        spark = self.spark_t <= 0
        if spark:
            self.spark_t = .6
        for cid, c in self.chests.items():
            c["avail"] = bool(state.get(cid, 1))
            target = 0.0 if c["avail"] else 1.0
            c["open"] += (target - c["open"]) * min(1, dt * 4)
            c["e"].hth_lid.rotation_x = -105 * c["open"]
            if spark and c["avail"] and math.hypot(c["x"] - self.px, c["z"] - self.pz) < 25:
                self.particles.burst((c["x"], .8, c["z"]), 2, GOLD, speed=.3, life=.9, size=.05, up=1.2)
        for t, x, z, r in self.labels:
            vis = math.hypot(x - self.px, z - self.pz) < r
            if t.enabled != vis:
                t.enabled = vis
        self.gold_t = getattr(self, "gold_t", 0.0) - dt
        if self.gold_t <= 0:                                      # золотые звери поблёскивают
            self.gold_t = .3
            for r in self.animals.values():
                if getattr(r["e"], "hth_gold", False) and r.get("vis", True) and (r["x"] - self.px) ** 2 + (r["z"] - self.pz) ** 2 < 70 ** 2:
                    self.particles.burst((r["x"], .9, r["z"]), 2, GOLD, speed=.4, life=.8, size=.05, up=1.4, grav=-.4)
        sl = getattr(self.worlds.get(self.cur_loc), "hth_slot", None)
        if sl is not None:                                        # лампочки автомата мигают, вывеска видна вблизи
            sl["glow"].color = Color(1, .85, .35, .25 + .5 * (int(self.t * 3) % 2))
            on = math.hypot(sl["x"] - self.px, sl["z"] - self.pz) < 30
            if sl["label"].enabled != on:
                sl["label"].enabled = on
        has_radar = bool(self.me.get("radar"))
        pulse = .5 + .5 * math.sin(self.t * 3)
        for gt in self.gates:                                     # силовой барьер ворот: красный пульсирует, с радаром - зелёный и почти прозрачный
            gt["e"].color = Color(.3, 1, .55, .06 + .04 * pulse) if has_radar else Color(.95, .25, .22, .26 + .14 * pulse)
        ar = self.arena
        if ar is not None:
            nm = ANIMALS[ar["boss"]]["name"]
            set_text(ar["label"], f"АРЕНА: {nm}" if has_radar else "АРЕНА БОССА - нужен радар")
            if not has_radar and math.hypot(ar["gx"] - self.px, ar["gz"] - self.pz) < 7 and self.t > self.gate_hint_t:
                self.gate_hint_t = self.t + 8
                self.on_message("Ворота закрыты силовым барьером. Нужен боевой радар - его продаёт Радист Фёдор в лагере")
        self.boss_rec = None
        for rec in self.animals.values():
            if rec["k"].startswith("boss_"):
                self.boss_rec = rec
                st = rec.get("st", 0)
                if st == 4 and rec.get("prev_st") != 4 and math.hypot(rec["x"] - self.px, rec["z"] - self.pz) < 70:
                    self.sfx.play("roar", 1.0, random.uniform(.9, 1.05))       # босс бросается в атаку
                    self.shake = max(self.shake, .6)
                rec["prev_st"] = st
        if self.me.get("dead") and self.overlay in ("butcher", "lock"):
            self.butch = self.lock = None
            self.set_overlay(None)

    def shot_effects(self, wk):
        """Свой выстрел: тряска камеры, вспышка, дым из ствола, гильза (у ружей)."""
        self.shake = {"bow": .35, "rifle": .7, "shotgun": 1.0, "sniper": 1.25}[wk]
        if self.vm is None or not self.S["particles"]:
            return
        mz = self.vm.hth_muzzle.world_position
        if wk != "bow":
            self.smoke.burst(mz, 5, C(200, 200, 204, 150), speed=.35, life=1.3, size=.12, up=.7, grav=-.5, grow=3.0)
            self.particles.burst(mz, 6, C(255, 200, 90), speed=1.5, life=.18, size=.05, up=1.0)       # искры
            yr = math.radians(self.yaw)
            right = (math.cos(yr), -math.sin(yr))
            e = Entity(model="cube", color=C(214, 170, 70), unlit=True, scale=(.025, .025, .06) if wk != "shotgun" else (.04, .04, .09),
                       position=(mz.x - right[0] * .25, mz.y - .05, mz.z - right[1] * .25))
            self.shells.append(dict(e=e, v=[right[0] * random.uniform(1.6, 2.4), random.uniform(1.8, 2.6), right[1] * random.uniform(1.6, 2.4)],
                                    spin=random.uniform(400, 900), life=6.0, landed=False))
        else:
            self.smoke.burst(mz, 2, C(220, 220, 220, 90), speed=.2, life=.6, size=.06, up=.3, grav=-.3, grow=2.0)

    def spawn_arrow(self, a, b, stick):
        """Стрела летит к цели (видна в полёте) и втыкается в землю, если промах."""
        d = b - a
        length = d.length()
        if length < .3:
            return
        e = Entity(model="cube", color=C(214, 192, 140), unlit=True, scale=(.03, .03, .8), position=a)
        e.look_at(b)
        Entity(parent=e, model="cube", color=C(60, 60, 66), unlit=True, scale=(1.6, 1.6, .08), position=(0, 0, .5))
        self.arrows.append(dict(e=e, a=a, b=b, t=0.0, dur=length / 70.0, stick=stick, life=8.0))

    def spawn_decal(self, x, z):
        e = Entity(model="cube", color=C(40, 32, 24, 200), unlit=True, scale=(.22, .01, .22), position=(x, .02, z),
                   rotation_y=random.uniform(0, 90))
        self.decals.append([e, 10.0])
        if len(self.decals) > 30:
            destroy(self.decals.pop(0)[0])

    def update_projectiles(self, dt):
        for ar in self.arrows[:]:
            e = ar["e"]
            if ar["t"] < ar["dur"]:
                ar["t"] += dt
                f = min(1.0, ar["t"] / ar["dur"])
                e.position = ar["a"] + (ar["b"] - ar["a"]) * f
                if f >= 1 and not ar["stick"]:
                    destroy(e)
                    self.arrows.remove(ar)
            else:
                ar["life"] -= dt
                if ar["life"] <= 0:
                    destroy(e)
                    self.arrows.remove(ar)
        for sh in self.shells[:]:                              # гильзы: летят, крутятся, звенят о землю
            e, v = sh["e"], sh["v"]
            sh["life"] -= dt
            if not sh["landed"]:
                v[1] -= 9.8 * dt
                e.position = (e.x + v[0] * dt, e.y + v[1] * dt, e.z + v[2] * dt)
                e.rotation_x += sh["spin"] * dt
                if e.y <= .02:
                    e.y = .02
                    sh["landed"] = True
                    self.sfx.play("shell", .45, random.uniform(.9, 1.2))
            if sh["life"] <= 0:
                destroy(e)
                self.shells.remove(sh)
        for dc in self.decals[:]:
            dc[1] -= dt
            if dc[1] <= 0:
                destroy(dc[0])
                self.decals.remove(dc)

    def spawn_tracer(self, a, b, life=.09):
        d = b - a
        length = d.length()
        if length < .2:
            return
        e = Entity(model="cube", color=C(255, 232, 150), unlit=True, position=a + d / 2, scale=(.05, .05, length))
        e.look_at(b)
        self.tracers.append([e, life])

    # ---------------------------------------------------------------- модели зверей, туш и игроков
    def sync_entities(self, snap, dt):
        k = min(1, dt * 12)
        seen = set()
        for a in snap["an"]:
            rec = self.animals.get(a[0])
            if rec is None:
                e = w3.make_animal(a[1], gold=bool(a[7]) if len(a) > 7 else False)
                e.position = (a[2], 0, a[3])
                rec = self.animals[a[0]] = dict(e=e, x=a[2], z=a[3], yaw=90 - math.degrees(a[4]), ph=0.0)
            seen.add(a[0])
            rec["st"] = a[6] if len(a) > 6 else 0
            rec["k"], rec["hp"] = a[1], a[5]
            d2 = (rec["x"] - self.px) ** 2 + (rec["z"] - self.pz) ** 2
            n_ = 1 if d2 < 3600 else (2 if d2 < 19600 else 4)       # ближе 60 м - каждый кадр, до 140 м - через кадр, дальше - каждый 4-й
            if n_ > 1 and (self.frame_i + a[0]) % n_:
                continue
            self.ease(rec, a[2], a[3], 90 - math.degrees(a[4]), min(1.0, k * n_), dt * n_)
        for aid in [i for i in self.animals if i not in seen]:       # убитый зверь падает; его туша придёт позже в cs
            rec = self.animals.pop(aid)
            dx, dz = rec["x"] - self.px, rec["z"] - self.pz
            d = math.hypot(dx, dz) or 1.0
            if d > 245:                                            # просто ушёл далеко (сервер не шлёт далёких) - убираем тихо
                destroy(rec["e"])
                continue
            self.dying.append(dict(e=rec["e"], kind=rec["e"].hth_kind, x=rec["x"], z=rec["z"], yaw=rec["yaw"], t=0.0,
                                   side=random.choice((-1, 1)), kx=dx / d, kz=dz / d, adopted=False, landed=False, grace=0.0))
        seen = set()
        for c in snap["cs"]:
            rec = self.carc.get(c[0])
            if rec is None:
                dyn = next((q for q in self.dying if not q["adopted"] and q["kind"] == c[1]
                            and math.hypot(q["x"] - c[2], q["z"] - c[3]) < 3.5), None)
                if dyn is not None:                                 # тушей становится тот же падающий зверь
                    dyn["adopted"] = True
                    e = dyn["e"]
                else:
                    e = w3.make_animal(c[1], gold=bool(c[6]) if len(c) > 6 else False)
                    e.position = (c[2], w3.SPECS[c[1]]["body"][0] / 2 + .05, c[3])
                    e.rotation_y = 90 - math.degrees(c[4])
                    e.rotation_z = 90 if c[0] % 2 else -90
                m = Text(text="[F]", parent=scene, position=(c[2], 1.7, c[3]), origin=(0, 0), scale=20, billboard=True, color=GOLD)
                rec = self.carc[c[0]] = dict(e=e, m=m, x=c[2], z=c[3], k=c[1], lock=0)
            rec["lock"] = c[5]
            seen.add(c[0])
        for cid in [i for i in self.carc if i not in seen]:
            rec = self.carc.pop(cid)
            destroy(rec["e"])
            destroy(rec["m"])
        seen = set()
        for p in snap["pl"]:
            if p[0] == self.net.id:
                continue
            rec = self.players.get(p[0])
            if rec is None:
                e = w3.make_hunter(p[1])
                e.position = (p[2], 0, p[3])
                rec = self.players[p[0]] = dict(e=e, x=p[2], z=p[3], yaw=90 - math.degrees(p[4]), ph=0.0)
            seen.add(p[0])
            w3.set_hunter_weapon(rec["e"], p[5], p[7] if len(p) > 7 else None)
            w3.set_hunter_carry(rec["e"], p[8] if len(p) > 8 else None, bool(p[9]) if len(p) > 9 else False)
            rec["jy"] = p[6] if len(p) > 6 else 0.0
            self.ease(rec, p[2], p[3], 90 - math.degrees(p[4]), k, dt)
        for pid in [i for i in self.players if i not in seen]:
            destroy(self.players.pop(pid)["e"])

    def ease(self, rec, tx, tz, tyaw, k, dt):
        ox, oz = rec["x"], rec["z"]
        rec["x"] += (tx - ox) * k
        rec["z"] += (tz - oz) * k
        rec["yaw"] += ((tyaw - rec["yaw"] + 180) % 360 - 180) * min(1, k * 1.5)
        rec["v"] = math.hypot(rec["x"] - ox, rec["z"] - oz) / max(dt, 1e-3)
        e = rec["e"]
        e.position = (rec["x"], 0, rec["z"])
        e.rotation_y = rec["yaw"]

    def animate(self, dt):
        far2 = min(getattr(self.atmo, "far", 400) + 15, 130.0) ** 2         # дальше 130 м зверь - пара пикселей, а отрисовка на каждого
        for rec in list(self.animals.values()) + list(self.players.values()):
            e = rec["e"]
            d2 = (rec["x"] - self.px) ** 2 + (rec["z"] - self.pz) ** 2
            vis = d2 < far2                                                          # в тумане зверя не видно - не рисуем
            if vis != rec.get("vis", True):
                rec["vis"] = vis
                e.enabled = vis
            if not vis:
                continue
            ds = dt
            if d2 > 19600:                                       # дальше 140 м анимация раз в 4 кадра (дрожь шага не видна)
                if (self.frame_i + (id(rec) >> 5)) % 4:
                    continue
                ds = dt * 4
            rec["ph"] += ds * 9
            amp = min(1, rec.get("v", 0) / 3)                     # покачивание при движении
            e.y = abs(math.sin(rec["ph"])) * .12 * amp + rec.get("jy", 0.0)
            fl = rec.get("flinch", 0)
            st_ = rec.get("st")
            tilt = 14 if st_ == 2 else (-6 if st_ == 3 else (7 if st_ == 5 else 0))   # пасётся / насторожился / нападает
            if st_ == 5 and rec.get("pst") != 5 and not rec["k"].startswith("boss_"):
                dd = math.hypot(rec["x"] - self.px, rec["z"] - self.pz)
                if dd < 45:                                       # зверь бросился на охотника - рык
                    self.sfx.play("roar", max(.15, .55 - dd / 100), {"wolf": 1.7, "boar": 1.35, "bear": .95, "moose": 1.1}.get(rec["k"], 1.3))
            rec["pst"] = st_
            rec["tilt"] = rec.get("tilt", 0) + (tilt - rec.get("tilt", 0)) * min(1, ds * 3)
            if fl > 0:                                            # вздрагивание от попадания
                rec["flinch"] = fl - ds
                e.rotation_x = rec["tilt"] + math.sin(self.t * 45) * 10 * max(0.0, fl / .35)
            else:
                e.rotation_x = rec["tilt"]
        for q in self.dying[:]:                                   # смерть: отброс, падение на бок, пыль при ударе о землю
            q["t"] += dt
            p = min(1.0, q["t"] / .8)
            ease = 1 - (1 - p) ** 3
            e = q["e"]
            e.rotation_y = q["yaw"]
            e.rotation_z = q["side"] * 90 * ease
            lie = w3.SPECS[q["kind"]]["body"][0] / 2 + .05
            e.position = (q["x"] + q["kx"] * .4 * ease, lie * ease + .5 * math.sin(min(1.0, p * 1.6) * math.pi) * (1 - p),
                          q["z"] + q["kz"] * .4 * ease)
            if p >= 1.0 and not q["landed"]:
                q["landed"] = True
                self.particles.burst((e.x, .15, e.z), 8, C(150, 120, 80), speed=1.4, life=.6, size=.12, up=1.6)
                self.sfx.play("step", .5, .6)
            if q["landed"]:
                if q["adopted"]:
                    self.dying.remove(q)
                else:
                    q["grace"] += dt
                    if q["grace"] > 3:                            # туша так и не пришла (например, сменилась локация)
                        destroy(e)
                        self.dying.remove(q)
        for rec in self.carc.values():                            # маркер над добычей
            d = math.hypot(rec["x"] - self.px, rec["z"] - self.pz)
            rec["m"].enabled = d < 35
            rec["m"].y = 1.7 + .18 * math.sin(self.t * 4)
            rec["m"].color = DIM if rec["lock"] else GOLD
        for tr in self.tracers[:]:
            tr[1] -= dt
            if tr[1] <= 0:
                destroy(tr[0])
                self.tracers.remove(tr)
        for fl in self.floats[:]:
            fl[1] -= dt
            fl[2] += 1.6 * dt
            fl[0].y = fl[2]
            if fl[1] <= 0:
                destroy(fl[0])
                self.floats.remove(fl)
        dcamp = math.hypot(CAMP[0] - self.px, CAMP[1] - self.pz)
        if self.fire and dcamp < 110:                             # дальше огонь не разглядеть - не тратим время
            self.fire.update(self.t, dt, dcamp < 70)


def setup_runtime():
    """Запуск без консоли (pythonw): пишем вывод в файл; в панели задач показываем иконку игры, а не Python."""
    if sys.stdout is None or sys.stderr is None:
        try:
            os.makedirs(HOME, exist_ok=True)
            log = open(os.path.join(HOME, "game.log"), "w", encoding="utf-8", buffering=1)
            sys.stdout = sys.stdout or log
            sys.stderr = sys.stderr or log
        except OSError:
            pass
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("HowToHunt.Game.1")
        except Exception:
            pass


def set_window_icon(app):
    """Иконка окна и панели задач (копия в ~/.how_to_hunt - путь без русских букв)."""
    try:
        src = os.path.join(HERE, "assets", "icon.ico")
        if not os.path.exists(src):
            return
        os.makedirs(HOME, exist_ok=True)
        dst = os.path.join(HOME, "icon.ico")
        if not os.path.exists(dst) or os.path.getsize(dst) != os.path.getsize(src):
            shutil.copyfile(src, dst)
        from panda3d.core import Filename, WindowProperties
        props = WindowProperties()
        props.setIconFilename(Filename.from_os_specific(dst))
        app.win.requestProperties(props)
    except Exception as e:
        print("Иконка окна недоступна:", e)


GPU_KEY = r"Software\Microsoft\DirectX\UserGpuPreferences"


def ensure_gpu_preference():
    """Windows 10/11: просим систему запускать python и pythonw игры на видеокарте «Высокая производительность»
    (в настройках графики Windows). Возвращает True, если настройка только что изменена - тогда игру нужно запустить заново,
    потому что видеокарту Windows выбирает при старте программы."""
    if os.name != "nt":
        return False
    try:
        import winreg
        exes = {sys.executable}
        d, n = os.path.split(sys.executable)
        for alt in ("python.exe", "pythonw.exe"):
            if os.path.exists(os.path.join(d, alt)):
                exes.add(os.path.join(d, alt))
        changed = False
        with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, GPU_KEY, 0, winreg.KEY_READ | winreg.KEY_WRITE) as key:
            for exe in exes:
                try:
                    cur = winreg.QueryValueEx(key, exe)[0]
                except OSError:
                    cur = None
                if cur != "GpuPreference=2;":
                    winreg.SetValueEx(key, exe, 0, winreg.REG_SZ, "GpuPreference=2;")
                    changed = True
        return changed
    except Exception as e:
        print("Выбор видеокарты не удался:", e)
        return False


def relaunch_once():
    """Перезапуск игры (один раз) после смены настройки видеокарты."""
    if os.environ.get("HTH_RELAUNCHED"):
        return False
    try:
        env = dict(os.environ, HTH_RELAUNCHED="1")
        subprocess.Popen([sys.executable] + sys.argv, env=env, cwd=HERE)
        return True
    except Exception:
        return False


MT_STATE = {"crashed": False, "note": ""}


def mt_guard(S):
    """Многопоточная отрисовка включена по умолчанию. Если прошлый запуск с ней не завершился нормально (вылет),
    в этот раз она выключается сама - игра всё равно запустится."""
    flag = os.path.join(HOME, "mt_running.flag")
    if not S.get("mt"):
        return
    if os.path.exists(flag):
        S["mt"] = 0
        save_settings(S)
        MT_STATE["note"] = "Прошлый запуск завершился с ошибкой - многопоточная отрисовка выключена (Настройки - Графика)"
        try:
            os.remove(flag)
        except OSError:
            pass
        return
    try:
        os.makedirs(HOME, exist_ok=True)
        open(flag, "w").close()
    except OSError:
        return

    def _clear():
        if not MT_STATE["crashed"]:
            try:
                os.remove(flag)
            except OSError:
                pass
    import atexit
    atexit.register(_clear)


def main():
    setup_runtime()
    if ensure_gpu_preference() and relaunch_once():          # первый запуск: «Высокая производительность» применится после перезапуска
        return
    S = load_settings()
    mt_guard(S)
    try:
        from panda3d.core import loadPrcFileData
        loadPrcFileData("", f"sync-video {1 if S['vsync'] else 0}")
        loadPrcFileData("", "gl-check-errors false\ngl-force-no-error true\nnotify-level-glgsg error\nnotify-level-display error")
        if S.get("mt"):
            loadPrcFileData("", "threading-model Cull/Draw")
        if S["aa"]:
            loadPrcFileData("", "framebuffer-multisample 1\nmultisamples 4")
    except Exception:
        pass
    kw = dict(title="HOW TO HUNT", borderless=False)
    try:
        app = Ursina(development_mode=False, vsync=bool(S["vsync"]), **kw)
    except TypeError:
        try:
            app = Ursina(development_mode=False, **kw)
        except TypeError:
            app = Ursina(**kw)
    try:
        window.exit_button.visible = False
        window.fps_counter.enabled = False
        window.forced_aspect_ratio = 16 / 9            # интерфейс рассчитан на 16:9
    except Exception:
        pass
    if S["aa"]:
        try:
            from panda3d.core import AntiAliasAttrib
            app.render.setAntialias(AntiAliasAttrib.MAuto)
        except Exception:
            pass
    set_window_icon(app)
    setup_font()
    w3.DENSITY = DENSITY[S["density"]]
    w3.GRASS_LEVEL = S["grass"]
    if S["shadows"] > 0:
        try:
            from ursina.shaders import lit_with_shadows_shader
            w3.SHADER = lit_with_shadows_shader
        except Exception as e:
            print("Шейдер освещения недоступен, режим без теней:", e)
    w3.BAKE = w3.SHADER is None
    try:
        gc.set_threshold(50000, 50, 100)          # мелкие сборки мусора реже: меньше микро-рывков
    except Exception:
        pass
    a = App(app, S)
    a.freeze_heap()
    a.quiet_static()
    app.run()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        MT_STATE["crashed"] = True
        import traceback
        tb = traceback.format_exc()
        os.makedirs(HOME, exist_ok=True)
        crash = os.path.join(HOME, "crash.log")
        with open(crash, "w", encoding="utf-8") as f:
            f.write(tb)
        if os.name == "nt":                          # без консоли ошибку иначе не увидеть - показываем окно с текстом
            try:
                import ctypes
                text = ("Игра завершилась с ошибкой.\n\n" + tb[-1100:] + "\n\nПолный текст сохранён в файле:\n" + crash +
                        "\n\nОткрыть папку с этим файлом?")
                if ctypes.windll.user32.MessageBoxW(0, text, "HOW TO HUNT", 0x14) == 6:      # Да
                    os.startfile(HOME)
            except Exception:
                pass
        raise
