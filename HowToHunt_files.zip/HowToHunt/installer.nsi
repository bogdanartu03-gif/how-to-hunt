﻿; HOW TO HUNT - установщик (NSIS, как Catgame-Setup). Собирается скриптом build_setup.ps1:



;   HowToHunt-Setup-<версия>.exe  - внутри встроенный Python, движок Ursina и игра: на чужом компьютере ничего не нужно



Unicode true



!ifndef VERSION



  !define VERSION "1.0.0"



!endif



!ifndef VERSION_US



  !define VERSION_US "1_0_0"



!endif



!define APPNAME "HOW TO HUNT"



!define UNINSTKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\HowToHunt"







!include "MUI2.nsh"



!include "FileFunc.nsh"



!include "LogicLib.nsh"



!insertmacro GetFileName



!insertmacro GetSize







Name "${APPNAME}"



OutFile "HowToHunt-Setup-${VERSION_US}.exe"



InstallDir "$LOCALAPPDATA\Programs\HowToHunt"



InstallDirRegKey HKCU "Software\HowToHunt" "InstallDir"



RequestExecutionLevel user



SetCompressor /SOLID lzma



SetCompressorDictSize 32



ShowInstDetails show



ShowUninstDetails show



BrandingText "${APPNAME} ${VERSION}"







!define MUI_ICON "assets\icon.ico"



!define MUI_UNICON "assets\icon.ico"



!define MUI_ABORTWARNING



!define MUI_FINISHPAGE_RUN



!define MUI_FINISHPAGE_RUN_FUNCTION LaunchGame



!define MUI_FINISHPAGE_RUN_TEXT "Запустить ${APPNAME}"







!insertmacro MUI_PAGE_WELCOME



!insertmacro MUI_PAGE_COMPONENTS



!insertmacro MUI_PAGE_DIRECTORY



!insertmacro MUI_PAGE_INSTFILES



!insertmacro MUI_PAGE_FINISH



!insertmacro MUI_UNPAGE_CONFIRM



!insertmacro MUI_UNPAGE_INSTFILES







!insertmacro MUI_LANGUAGE "Russian"



!insertmacro MUI_LANGUAGE "English"







VIProductVersion "${VERSION}.0"



VIAddVersionKey /LANG=${LANG_RUSSIAN} "ProductName" "${APPNAME}"



VIAddVersionKey /LANG=${LANG_RUSSIAN} "FileVersion" "${VERSION}"



VIAddVersionKey /LANG=${LANG_RUSSIAN} "FileDescription" "Установщик ${APPNAME}"



VIAddVersionKey /LANG=${LANG_ENGLISH} "ProductName" "${APPNAME}"



VIAddVersionKey /LANG=${LANG_ENGLISH} "FileVersion" "${VERSION}"



VIAddVersionKey /LANG=${LANG_ENGLISH} "FileDescription" "${APPNAME} setup"







; запуск игры по кнопке «Готово» (pythonw - без окна консоли)



Function LaunchGame



  SetOutPath "$INSTDIR\game"



  Exec '"$INSTDIR\python\pythonw.exe" "$INSTDIR\game\how_to_hunt.py"'



FunctionEnd







Section "!${APPNAME}" SecMain



  SectionIn RO



  ; ставим только в свою папку HowToHunt - так удаление никогда не заденет чужие файлы



  ${GetFileName} "$INSTDIR" $0



  ${If} $0 != "HowToHunt"



    StrCpy $INSTDIR "$INSTDIR\HowToHunt"



  ${EndIf}



  SetOutPath "$INSTDIR"



  File /r "build\app\*.*"







  WriteUninstaller "$INSTDIR\Uninstall.exe"



  WriteRegStr HKCU "Software\HowToHunt" "InstallDir" "$INSTDIR"



  WriteRegStr HKCU "${UNINSTKEY}" "DisplayName" "${APPNAME}"



  WriteRegStr HKCU "${UNINSTKEY}" "DisplayVersion" "${VERSION}"



  WriteRegStr HKCU "${UNINSTKEY}" "Publisher" "${APPNAME}"



  WriteRegStr HKCU "${UNINSTKEY}" "DisplayIcon" "$INSTDIR\game\assets\icon.ico"



  WriteRegStr HKCU "${UNINSTKEY}" "InstallLocation" "$INSTDIR"



  WriteRegStr HKCU "${UNINSTKEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'



  WriteRegDWORD HKCU "${UNINSTKEY}" "NoModify" 1



  WriteRegDWORD HKCU "${UNINSTKEY}" "NoRepair" 1



  ${GetSize} "$INSTDIR" "/S=0K" $0 $1 $2



  IntFmt $0 "0x%08X" $0



  WriteRegDWORD HKCU "${UNINSTKEY}" "EstimatedSize" "$0"







  SetOutPath "$INSTDIR\game"



  CreateDirectory "$SMPROGRAMS\${APPNAME}"



  ; на ноутбуках с двумя видеокартами Windows даёт python встроенную - просим мощную (график Windows: «Высокая производительность»)
  WriteRegStr HKCU "Software\Microsoft\DirectX\UserGpuPreferences" "$INSTDIR\python\pythonw.exe" "GpuPreference=2;"
  WriteRegStr HKCU "Software\Microsoft\DirectX\UserGpuPreferences" "$INSTDIR\python\python.exe" "GpuPreference=2;"
  CreateShortcut "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk" "$INSTDIR\python\pythonw.exe" '"$INSTDIR\game\how_to_hunt.py"' "$INSTDIR\game\assets\icon.ico" 0



  CreateShortcut "$SMPROGRAMS\${APPNAME}\Удалить ${APPNAME}.lnk" "$INSTDIR\Uninstall.exe"

  ; запуск с окном консоли: если игра не стартует, здесь видно текст ошибки

  CreateShortcut "$SMPROGRAMS\${APPNAME}\${APPNAME} (с консолью).lnk" "$SYSDIR\cmd.exe" '/k ""$INSTDIR\python\python.exe" "$INSTDIR\game\how_to_hunt.py""' "$INSTDIR\game\assets\icon.ico" 0



SectionEnd







Section "Ярлык на рабочем столе" SecDesktop



  SetOutPath "$INSTDIR\game"



  CreateShortcut "$DESKTOP\${APPNAME}.lnk" "$INSTDIR\python\pythonw.exe" '"$INSTDIR\game\how_to_hunt.py"' "$INSTDIR\game\assets\icon.ico" 0



SectionEnd







Section "Uninstall"



  Delete "$DESKTOP\${APPNAME}.lnk"



  Delete "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk"



  Delete "$SMPROGRAMS\${APPNAME}\Удалить ${APPNAME}.lnk"
  DeleteRegValue HKCU "Software\Microsoft\DirectX\UserGpuPreferences" "$INSTDIR\python\pythonw.exe"
  DeleteRegValue HKCU "Software\Microsoft\DirectX\UserGpuPreferences" "$INSTDIR\python\python.exe"

  Delete "$SMPROGRAMS\${APPNAME}\${APPNAME} (с консолью).lnk"



  RMDir "$SMPROGRAMS\${APPNAME}"



  RMDir /r "$INSTDIR"



  DeleteRegKey HKCU "${UNINSTKEY}"



  DeleteRegKey HKCU "Software\HowToHunt"



  MessageBox MB_YESNO|MB_ICONQUESTION "Удалить также ваши сохранения и настройки игры?" IDNO keep



    RMDir /r "$PROFILE\.how_to_hunt"



  keep:



SectionEnd



