#!/usr/bin/env bash
# HOW TO HUNT - установка и запуск для Linux и macOS
cd "$(dirname "$0")" || exit 1

find_py() {
    for c in python3.13 python3.12 python3.11 python3.10 python3 python; do
        if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null; then
            echo "$c"; return
        fi
    done
}

PY=$(find_py)
if [ -z "$PY" ]; then
    echo "[!] Python не найден. Пробую установить (может спросить пароль)..."
    if   command -v brew    >/dev/null 2>&1; then brew install python@3.12
    elif command -v apt-get >/dev/null 2>&1; then sudo apt-get update && sudo apt-get install -y python3 python3-venv python3-pip
    elif command -v dnf     >/dev/null 2>&1; then sudo dnf install -y python3 python3-pip
    elif command -v pacman  >/dev/null 2>&1; then sudo pacman -S --noconfirm python python-pip
    fi
    PY=$(find_py)
fi
if [ -z "$PY" ]; then
    echo "Не удалось установить Python автоматически. Скачайте его: https://www.python.org/downloads/"
    exit 1
fi

# на Debian/Ubuntu модуль venv ставится отдельным пакетом
if ! "$PY" -c 'import ensurepip, venv' >/dev/null 2>&1 && command -v apt-get >/dev/null 2>&1; then
    sudo apt-get install -y python3-venv python3-pip
fi

exec "$PY" launcher.py "$@"
