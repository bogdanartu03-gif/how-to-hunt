﻿# Сборка установщика HowToHunt-Setup-<версия>.exe (NSIS - тот же формат, что у Catgame-Setup).
# Запускать двойным кликом по Build_Setup_Exe.bat. Нужен интернет (Python, движок и NSIS скачиваются один раз).
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ProgressPreference = 'SilentlyContinue'
$ver = '1.0.0'
$verUs = $ver.Replace('.', '_')
$root = $PSScriptRoot
$b = Join-Path $root 'build'
$app = Join-Path $b 'app'
New-Item -ItemType Directory -Force -Path $b, $app | Out-Null

function Step($n, $t) { Write-Host ''; Write-Host "[$n/6] $t" -ForegroundColor Yellow }
function Fetch($url, $dest, $agent = 'Mozilla/5.0') {
    Write-Host "  Скачиваю: $url"
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $dest -UserAgent $agent
}

Step 1 'Проверяю файлы игры'
Write-Host "  папка со скриптом: $root"
$installed = Join-Path $env:USERPROFILE '.how_to_hunt\game'          # игра, установленная HowToHunt_Setup.bat
$files = 'how_to_hunt.py', 'world3d.py', 'server.py', 'ui.py', 'fx.py', 'sfx.py', 'grass.py'
$assetFiles = 'assets\icon.ico', 'assets\icon.png', 'assets\DejaVuSans.ttf'

function Find-Source($rel) {
    $p = Join-Path $root $rel
    if (Test-Path -LiteralPath $p) { return $p }
    $dir = Split-Path $p -Parent
    $name = [IO.Path]::GetFileNameWithoutExtension($p)
    $ext = [IO.Path]::GetExtension($p)
    if (Test-Path -LiteralPath $dir) {                                    # браузер мог назвать файл "server (1).py"
        $alt = Get-ChildItem -LiteralPath $dir -Filter "$name (*)$ext" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($alt) { Write-Host "  $rel не найден, беру $($alt.Name)" -ForegroundColor Yellow; return $alt.FullName }
    }
    $q = Join-Path $installed $rel
    if (Test-Path -LiteralPath $q) {
        Write-Host "  $rel нет рядом со скриптом - беру из установленной игры ($installed). Лучше скачайте свежий." -ForegroundColor Yellow
        return $q
    }
    return $null
}

$src = @{}
$missing = @()
foreach ($rel in ($files + $assetFiles)) {
    $found = Find-Source $rel
    if ($found) { $src[$rel] = $found } else { $missing += $rel }
}
if (-not (Test-Path -LiteralPath (Join-Path $root 'installer.nsi'))) { $missing += 'installer.nsi' }
if ($missing.Count -gt 0) {
    Write-Host ''
    Write-Host 'Не хватает файлов:' -ForegroundColor Red
    foreach ($m in $missing) { Write-Host "   - $m" -ForegroundColor Red }
    Write-Host ''
    Write-Host "Скачайте их и положите в папку: $root" -ForegroundColor Red
    Write-Host '(файлы шрифта и иконок - в подпапку assets). Полный список - в README.md.' -ForegroundColor Red
    throw 'Не все файлы на месте'
}
New-Item -ItemType Directory -Force -Path (Join-Path $root 'assets') | Out-Null
foreach ($rel in $assetFiles) {                                          # installer.nsi ищет иконку в папке assets рядом со скриптом
    $dst = Join-Path $root $rel
    if (-not (Test-Path -LiteralPath $dst)) { Copy-Item -LiteralPath $src[$rel] -Destination $dst }
}
Write-Host '  всё на месте'

Step 2 'Встроенный Python 3.12 (чтобы у игроков не нужно было ничего ставить)'
$py = Join-Path $app 'python'
$pyexe = Join-Path $py 'python.exe'
if (-not (Test-Path -LiteralPath (Join-Path $py 'pythonw.exe'))) {
    $zip = Join-Path $b 'python-embed.zip'
    Fetch 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip' $zip
    if (Test-Path -LiteralPath $py) { Remove-Item -Recurse -Force -LiteralPath $py }
    Expand-Archive -LiteralPath $zip -DestinationPath $py -Force
    $pth = Get-ChildItem -LiteralPath $py -Filter 'python*._pth' | Select-Object -First 1
    Set-Content -LiteralPath $pth.FullName -Value @(($pth.BaseName + '.zip'), '.', 'Lib\site-packages', '..\game', 'import site') -Encoding ASCII
} else { Write-Host '  уже есть' }

Step 3 'Движок Ursina и numpy (самый долгий шаг, около 150 МБ)'
$stamp = Join-Path $py '.packages-ok'
if (-not (Test-Path -LiteralPath $stamp)) {
    $gp = Join-Path $b 'get-pip.py'
    Fetch 'https://bootstrap.pypa.io/get-pip.py' $gp
    & $pyexe $gp --no-warn-script-location --disable-pip-version-check
    if ($LASTEXITCODE -ne 0) { throw 'get-pip завершился с ошибкой' }
    & $pyexe -m pip install --no-warn-script-location --disable-pip-version-check ursina numpy
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось установить ursina' }
    & $pyexe -c "import ursina, numpy; print('ursina и numpy импортируются')"
    if ($LASTEXITCODE -ne 0) { throw 'ursina не запускается во встроенном Python' }
    New-Item -ItemType File -Path $stamp | Out-Null
} else { Write-Host '  уже установлено' }

Step 4 'Копирую файлы игры'
$game = Join-Path $app 'game'
if (Test-Path -LiteralPath $game) { Remove-Item -Recurse -Force -LiteralPath $game }
New-Item -ItemType Directory -Path $game | Out-Null
foreach ($f in $files) { Copy-Item -LiteralPath $src[$f] -Destination (Join-Path $game $f) }
New-Item -ItemType Directory -Path (Join-Path $game 'assets') | Out-Null
foreach ($rel in $assetFiles) { Copy-Item -LiteralPath $src[$rel] -Destination (Join-Path $game $rel) }
$lic = Join-Path $root 'assets\DejaVu-LICENSE.txt'
if (Test-Path -LiteralPath $lic) { Copy-Item -LiteralPath $lic -Destination (Join-Path $game 'assets') }
Write-Host '  готово'

Step 5 'Компилятор установщиков NSIS'
$nsisDir = Join-Path $b 'nsis'
$mk = Get-ChildItem -LiteralPath $b -Filter makensis.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $mk) {
    foreach ($c in 'C:\Program Files (x86)\NSIS\makensis.exe', 'C:\Program Files\NSIS\makensis.exe') { if (Test-Path -LiteralPath $c) { $mk = Get-Item -LiteralPath $c; break } }
}
if (-not $mk) {
    foreach ($v in '3.11', '3.10', '3.09', '3.08') {
        try {
            $z = Join-Path $b "nsis-$v.zip"
            Fetch "https://sourceforge.net/projects/nsis/files/NSIS%203/$v/nsis-$v.zip/download" $z 'Wget/1.21'
            $head = [IO.File]::ReadAllBytes($z)[0..1]
            if ((Get-Item -LiteralPath $z).Length -lt 1MB -or $head[0] -ne 0x50 -or $head[1] -ne 0x4B) { throw 'получен не архив' }
            if (Test-Path -LiteralPath $nsisDir) { Remove-Item -Recurse -Force -LiteralPath $nsisDir }
            Expand-Archive -LiteralPath $z -DestinationPath $nsisDir -Force
            $mk = Get-ChildItem -LiteralPath $nsisDir -Filter makensis.exe -Recurse | Select-Object -First 1
            if ($mk) { break }
        } catch { Write-Host "  версия $v не скачалась: $($_.Exception.Message)" }
    }
}
if (-not $mk -and (Get-Command winget -ErrorAction SilentlyContinue)) {
    Write-Host '  пробую поставить NSIS через winget'
    winget install -e --id NSIS.NSIS --silent --accept-package-agreements --accept-source-agreements
    foreach ($c in 'C:\Program Files (x86)\NSIS\makensis.exe', 'C:\Program Files\NSIS\makensis.exe') { if (Test-Path -LiteralPath $c) { $mk = Get-Item -LiteralPath $c; break } }
}
if (-not $mk) { throw 'Не удалось получить NSIS. Установите его вручную (https://nsis.sourceforge.io/Download) и запустите сборку ещё раз.' }
Write-Host "  makensis: $($mk.FullName)"

Step 6 'Собираю установщик (сжатие занимает несколько минут)'
Push-Location -LiteralPath $root
try {
    & $mk.FullName /V2 "/DVERSION=$ver" "/DVERSION_US=$verUs" 'installer.nsi'
    $code = $LASTEXITCODE
} finally { Pop-Location }
if ($code -ne 0) { throw "makensis вернул ошибку $code (текст выше)" }
$exe = Join-Path $root "HowToHunt-Setup-$verUs.exe"
if (-not (Test-Path -LiteralPath $exe)) { throw 'Файл установщика не появился' }
Write-Host ''
Write-Host ("ГОТОВО: {0}  ({1:N0} МБ)" -f $exe, ((Get-Item -LiteralPath $exe).Length / 1MB)) -ForegroundColor Green
Write-Host 'Этот файл можно отправлять друзьям: Python и интернет им не нужны.'
Start-Process explorer.exe -ArgumentList "/select,`"$exe`""
