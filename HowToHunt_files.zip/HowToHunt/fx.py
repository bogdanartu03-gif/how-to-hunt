"""HOW TO HUNT - эффекты: время суток, солнце и облака, частицы."""
import math
import random
import time

from ursina import Entity, Mesh, Vec3, scene, window
from ursina.color import Color

# ключевые кадры суток: цвета неба/тумана/солнца/ambient и высота солнца над горизонтом (градусы)
KEYS = [
    (0.00, dict(top=(96, 118, 190), sky=(255, 190, 150), fog=(238, 186, 160), sun=(255, 190, 140), amb=(112, 110, 130), el=9)),
    (0.20, dict(top=(64, 128, 214), sky=(255, 255, 255), fog=(172, 204, 216), sun=(255, 238, 205), amb=(125, 130, 140), el=45)),
    (0.50, dict(top=(70, 140, 225), sky=(255, 255, 255), fog=(172, 204, 216), sun=(255, 244, 220), amb=(130, 134, 144), el=62)),
    (0.68, dict(top=(72, 76, 142), sky=(255, 200, 160), fog=(232, 170, 130), sun=(255, 160, 100), amb=(112, 100, 118), el=14)),
    (0.80, dict(top=(12, 16, 38), sky=(70, 80, 140), fog=(40, 48, 86), sun=(110, 130, 190), amb=(64, 74, 112), el=28)),
    (0.92, dict(top=(10, 14, 32), sky=(60, 70, 125), fog=(34, 42, 76), sun=(100, 120, 180), amb=(58, 68, 104), el=26)),
    (1.00, dict(top=(96, 118, 190), sky=(255, 190, 150), fog=(238, 186, 160), sun=(255, 190, 140), amb=(112, 110, 130), el=9)),
]
PHASES = {"day": .35, "dusk": .66, "night": .86}
CYCLE = 1200.0                      # полный цикл суток, секунд
VIEW = {0: (90, 320), 1: (130, 460), 2: (180, 640)}            # туман лёгкий: начинается далеко и плавно


def col(t, a=255):
    return Color(t[0] / 255, t[1] / 255, t[2] / 255, a / 255)


def mix(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def sample(phase):
    for i in range(len(KEYS) - 1):
        p0, k0 = KEYS[i]
        p1, k1 = KEYS[i + 1]
        if phase <= p1:
            t = (phase - p0) / (p1 - p0)
            out = {k: mix(k0[k], k1[k], t) for k in ("top", "sky", "fog", "sun", "amb")}
            out["el"] = k0["el"] + (k1["el"] - k0["el"]) * t
            return out
    return dict(KEYS[-1][1])


def phase_of(mode):
    return (time.time() % CYCLE) / CYCLE if mode == "cycle" else PHASES.get(mode, .35)


# погода: dark - яркость, fogm - дальность тумана, cloud - облачность, gray - серость неба,
# rain / snow - сила осадков (0..2), wind - порывистость ветра
WX = {
    "clear":    dict(dark=1.0, fogm=1.0, cloud=.45, gray=0.0, rain=0, snow=0, wind=.2),
    "cloudy":   dict(dark=.82, fogm=.9, cloud=1.0, gray=.35, rain=0, snow=0, wind=.4),
    "fog":      dict(dark=.88, fogm=.42, cloud=.7, gray=.55, rain=0, snow=0, wind=.1),
    "rain":     dict(dark=.64, fogm=.68, cloud=1.0, gray=.7, rain=1, snow=0, wind=.6),
    "storm":    dict(dark=.42, fogm=.52, cloud=1.0, gray=.85, rain=2, snow=0, wind=1.0),
    "snow":     dict(dark=.9, fogm=.62, cloud=1.0, gray=.4, rain=0, snow=1, wind=.4),
    "blizzard": dict(dark=.8, fogm=.3, cloud=1.0, gray=.5, rain=0, snow=2, wind=1.0),
}
WX_RU = dict(clear="ясно", cloudy="облачно", fog="туман", rain="дождь", storm="гроза", snow="снег", blizzard="метель")


def scale3(c, k):
    return tuple(min(255, v * k) for v in c)


_UNIT = {}


def _unit(kind):
    """Вершины и треугольники единичной фигуры: шар 8x6 или куб (без нормалей - облака и капли не освещаются)."""
    if kind not in _UNIT:
        V, T = [], []
        if kind == "sphere":
            seg, rings = 8, 6
            for r in range(rings + 1):
                th = math.pi * r / rings
                for s_ in range(seg + 1):
                    ph = 2 * math.pi * s_ / seg
                    V.append((.5 * math.sin(th) * math.cos(ph), .5 * math.cos(th), .5 * math.sin(th) * math.sin(ph)))
            for r in range(rings):
                for s_ in range(seg):
                    i = r * (seg + 1) + s_
                    T += [(i, i + seg + 1, i + 1), (i + 1, i + seg + 1, i + seg + 2)]
        else:
            c = [(x, y, z) for x in (-.5, .5) for y in (-.5, .5) for z in (-.5, .5)]
            V = c
            for a, b, c_, d in ((0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)):
                T += [(a, b, c_), (a, c_, d)]
        _UNIT[kind] = (V, T)
    return _UNIT[kind]


def merged_mesh(items, kind):
    """items: [(центр (x,y,z), масштаб (sx,sy,sz))] -> один Mesh: одна отрисовка вместо сотни."""
    V0, T0 = _unit(kind)
    verts, tris = [], []
    for (px, py, pz), (sx, sy, sz) in items:
        base = len(verts)
        verts += [Vec3(px + x * sx, py + y * sy, pz + z * sz) for x, y, z in V0]
        tris += [(a + base, b + base, c + base) for a, b, c in T0]
    return Mesh(vertices=verts, triangles=tris, colors=[Color(1, 1, 1, 1)] * len(verts))


class GradientSky:
    """Купол неба из вершин с цветами: у горизонта ровно цвет тумана (нет полосы между небом и горами), вверху - цвет
    зенита, вокруг солнца - тёплое свечение. Стоит ровно в точке камеры и не вращается - небо не «плывёт»."""
    SEG, RING = 24, 12

    def __init__(self):
        self.dirs, verts, tris = [], [], []
        for r in range(self.RING + 1):
            th = math.pi * r / self.RING
            for s in range(self.SEG + 1):
                ph = 2 * math.pi * s / self.SEG
                d = (math.sin(th) * math.cos(ph), math.cos(th), math.sin(th) * math.sin(ph))
                self.dirs.append(d)
                verts.append(Vec3(*d))
        for r in range(self.RING):
            for s in range(self.SEG):
                i = r * (self.SEG + 1) + s
                tris += [(i, i + self.SEG + 1, i + 1), (i + 1, i + self.SEG + 1, i + self.SEG + 2)]
        self.mesh = Mesh(vertices=verts, triangles=tris, colors=[Color(.5, .6, .8, 1)] * len(verts))
        self.e = Entity(model=self.mesh, scale=700, unlit=True, double_sided=True)
        try:
            self.e.setFogOff()
            self.e.setBin("background", 0)
            self.e.setDepthWrite(False)
        except Exception:
            pass
        self.key, self.t = None, 0.0

    def update(self, dt, eye, top, horizon, sun_dir, sun_col, glow):
        self.e.position = (eye[0], eye[1], eye[2])
        self.t -= dt
        key = tuple(int(v) for v in top + horizon + sun_col) + (round(sun_dir[1], 2), round(glow, 2))
        if key == self.key or self.t > 0:
            return
        self.key, self.t = key, 1.0                       # цвета пересчитываем не чаще раза в секунду
        cols = []
        for x, y, z in self.dirs:
            if y < 0:
                c = scale3(horizon, 1 + y * .35)
            else:
                c = mix(horizon, top, y ** .55)
            g = max(0.0, x * sun_dir[0] + y * sun_dir[1] + z * sun_dir[2]) ** 6 * glow
            c = mix(c, sun_col, min(1.0, g))
            cols.append(Color(c[0] / 255, c[1] / 255, c[2] / 255, 1))
        self.mesh.colors = cols
        try:
            self.mesh.generate()
        except Exception:
            pass


class Aurora:
    """Северное сияние: несколько колышущихся полупрозрачных лент (зелёный низ, фиолетовый верх)."""

    def __init__(self):
        r = random.Random(4)
        self.ribbons, self.t = [], 0.0
        for i in range(5):
            verts, tris, cols = [], [], []
            n = 30
            for j in range(n + 1):
                f = j / n
                x = (f - .5) * 460
                z = math.sin(f * 6.283 * 1.3 + i) * 55
                for yy, c_ in ((0, (90, 255, 150, 230)), (1, (150, 90, 255, 0))):
                    verts.append(Vec3(x, yy, z))
                    cols.append(Color(c_[0] / 255, c_[1] / 255, c_[2] / 255, c_[3] / 255))
            for j in range(n):
                a = j * 2
                tris += [(a, a + 1, a + 3), (a, a + 3, a + 2)]
            e = Entity(model=Mesh(vertices=verts, triangles=tris, colors=cols), unlit=True, double_sided=True,
                       color=Color(1, 1, 1, .01), enabled=False)
            try:
                e.setFogOff()
                e.setBin("background", 10 + i)
                e.setDepthWrite(False)
            except Exception:
                pass
            ang = r.uniform(0, 6.283)
            dist = r.uniform(170, 260)
            e.hth_base = (math.cos(ang) * dist, r.uniform(105, 140), math.sin(ang) * dist, r.uniform(0, 6.283),
                          r.uniform(45, 80), -math.degrees(ang) + 90)
            self.ribbons.append(e)

    def update(self, dt, eye, strength):
        self.t += dt
        for e in self.ribbons:
            on = strength > .02
            if e.enabled != on:
                e.enabled = on
            if not on:
                continue
            bx, by, bz, ph, h, yaw = e.hth_base
            e.position = (eye[0] + bx, by, eye[2] + bz)
            e.rotation_y = yaw + math.sin(self.t * .05 + ph) * 12
            e.scale = (1, h * (.85 + .15 * math.sin(self.t * .4 + ph)), 1)
            e.color = Color(1, 1, 1, strength * (.5 + .3 * math.sin(self.t * .7 + ph)))


class Critters:
    """Живность вокруг игрока: бабочки (лес, день), светлячки (лес и чаща, вечер и ночь), споры в воздухе (чаща, день)."""
    PAL = ((250, 200, 60), (240, 120, 60), (120, 170, 255), (250, 250, 250), (210, 120, 230))

    def __init__(self, n=26):
        r = random.Random(9)
        self.items = [dict(e=Entity(model="quad", unlit=True, billboard=True, double_sided=True, scale=.1, enabled=False),
                           p=[0.0, 1.0, 0.0], v=[0.0, 0.0, 0.0], ph=r.uniform(0, 6.283)) for _ in range(n)]
        self.kind = None

    def update(self, dt, t, eye, loc, phase, rain, level):
        day = .08 < phase < .66
        kind = None
        if level and rain < .4:
            if loc == "forest":
                kind = "butterfly" if day else ("firefly" if phase > .74 or phase < .04 else None)
            elif loc == "thicket":
                kind = "spore" if day else "firefly"
        want = 0 if kind is None else {"butterfly": 12, "firefly": 22, "spore": 26}[kind]
        if level == 1:
            want //= 2
        if kind != self.kind:                                     # смена вида: раскрашиваем заново
            self.kind = kind
            for i, it in enumerate(self.items):
                e = it["e"]
                if kind == "butterfly":
                    c = self.PAL[i % len(self.PAL)]
                    e.color, e.scale = Color(c[0] / 255, c[1] / 255, c[2] / 255, 1), .13
                elif kind == "firefly":
                    e.scale = .07
                elif kind == "spore":
                    e.color, e.scale = Color(.95, .95, .8, .55), .035
                it["p"] = [eye[0] + random.uniform(-12, 12), random.uniform(.4, 2.2), eye[2] + random.uniform(-12, 12)]
        speed = {"butterfly": 1.4, "firefly": .5, "spore": .18}.get(kind, 1)
        for i, it in enumerate(self.items):
            e = it["e"]
            on = i < want
            if e.enabled != on:
                e.enabled = on
            if not on:
                continue
            p, v = it["p"], it["v"]
            for j in range(3):                                    # блуждание
                v[j] += random.uniform(-1, 1) * speed * 3 * dt
            v[1] -= (p[1] - 1.2) * .6 * dt
            sp = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2) or 1.0
            if sp > speed:
                v[0], v[1], v[2] = v[0] / sp * speed, v[1] / sp * speed, v[2] / sp * speed
            for j in range(3):
                p[j] += v[j] * dt
            p[1] = min(3.0, max(.25, p[1]))
            if (p[0] - eye[0]) ** 2 + (p[2] - eye[2]) ** 2 > 16 ** 2:      # улетели далеко - появляются рядом
                a = random.uniform(0, 6.283)
                p[0], p[2] = eye[0] + math.cos(a) * random.uniform(5, 14), eye[2] + math.sin(a) * random.uniform(5, 14)
            e.position = (p[0], p[1], p[2])
            if kind == "butterfly":                               # взмахи крыльев
                e.scale_x = .13 * (.25 + .75 * abs(math.sin(t * 16 + it["ph"])))
            elif kind == "firefly":                               # мерцание
                g = max(0.0, math.sin(t * 2.2 + it["ph"] * 3))
                e.color = Color(.8 + .2 * g, 1, .3 + .2 * g, .15 + .85 * g)


class Atmosphere:
    def __init__(self, sky, sun, amb):
        self.sky, self.sun, self.amb = sky, sun, amb
        self.disc = Entity(model="sphere", scale=26, unlit=True, color=Color(1, .95, .8, 1))
        self.glow = Entity(model="sphere", scale=70, unlit=True, color=Color(1, .9, .6, .22))
        rnd = random.Random(5)
        self.cloud_root = Entity()
        self.drift = 0.0
        groups = [[], [], []]
        for i in range(12):                                  # 12 облаков, каждое - кучка из 3-5 пухлых частей, в трёх группах
            cx, cy, cz = rnd.uniform(-450, 450), rnd.uniform(85, 130), rnd.uniform(-450, 450)
            for j in range(rnd.randint(3, 5)):
                groups[i % 3].append(((cx + rnd.uniform(-26, 26), cy + rnd.uniform(-3, 5), cz + rnd.uniform(-14, 14)),
                                      (rnd.uniform(28, 55), rnd.uniform(9, 17), rnd.uniform(22, 40))))
        self.clouds = []
        for field in (0.0, -900.0):                           # второе поле позади первого: перенос через 900 м незаметен
            for g in groups:
                self.clouds.append(Entity(parent=self.cloud_root, model=merged_mesh(g, "sphere"), unlit=True, double_sided=True,
                                          color=Color(1, 1, 1, .85), x=field))
        # облака привязаны к камере: сдвиг относительно неё (дрейф) хранится отдельно, поэтому при ходьбе и качании
        # камеры небо не «плывёт» и не дрожит - меняется только то, куда вы смотрите
        for i, e in enumerate([self.glow, self.disc] + self.clouds):
            try:
                e.setFogOff()
                e.setBin("background", 20 + i)           # фиксированный порядок прорисовки: прозрачные облака не мерцают
                e.setDepthWrite(False)                   # и не «пробивают» горы и деревья
            except Exception:
                pass
        self.t_light = 0.0
        self.aurora = Aurora()
        self.cur = dict(WX["clear"])                 # текущие параметры погоды плавно перетекают к целевым
        self.flash = self.pending = 0.0
        self.next_bolt = 8.0
        self.events = []                             # ("bolt", угол, дистанция) - для вспышек и грома

    def update(self, dt, eye, loc, S, wx="clear"):
        tgt = WX.get(wx, WX["clear"])
        kk = min(1.0, dt * .35)
        for key in self.cur:
            self.cur[key] += (tgt[key] - self.cur[key]) * kk
        c = self.cur
        phase = phase_of(S["tod"])
        k = sample(phase)
        tundra, thick = loc == "tundra", loc == "thicket"
        fog = mix(k["fog"], (214, 224, 238), .45) if tundra else k["fog"]
        if phase > .72:                                            # ночью тундра тоже тёмная
            fog = mix(fog, k["fog"], .8)
        grey = (205, 212, 224) if tundra else (150, 156, 166)
        fog = scale3(mix(fog, grey, c["gray"] * .75), c["dark"] ** .5)
        sky = scale3(mix(k["sky"], (176, 182, 194), c["gray"]), c["dark"])
        if thick:                                                  # в чаще под кронами темно, зелёный сумрак
            fog = mix(scale3(fog, .7), (52, 82, 60), .38)
        elif loc == "forest":                                      # лес светлый, тёплый и прозрачный
            fog = mix(fog, (214, 226, 196), .18)
        near, far = VIEW[S["view"]]
        near, far = near * c["fogm"], far * c["fogm"]
        lf = getattr(self, "local_fog", 0.0)                         # внутри полосы тумана видимость заметно падает
        if lf > .001:
            near, far = max(15.0, near * (1 - .5 * lf)), max(90.0, far * (1 - .4 * lf))
        # сила дымки: туманная погода и рассвет/закат сгущают полосы тумана, полдень - разрежает
        dawn = max(0.0, 1 - abs(phase - .04) / .1) + max(0.0, 1 - abs(phase - .72) / .1)
        self.mist = max(.3, min(1.8, (1 + (1 - c["fogm"]) * 1.6) * (.75 + .5 * dawn)))
        if tundra:
            near, far = near * .5, far * .7
        if thick:
            near, far = near * .8, far * .85
        elif loc == "forest":
            near, far = near * 1.2, far * 1.15
        fl = self.flash if S.get("lightning", 1) else 0.0
        self.flash = max(0.0, self.flash - dt * 4)
        if self.pending > 0:
            self.pending -= dt
            if self.pending <= 0:
                self.flash = .8
        if fl > 0:
            fog, sky = mix(fog, (255, 255, 255), fl * .75), mix(sky, (255, 255, 255), fl * .8)
        night = phase > .76
        top = scale3(mix(k["top"], (150, 156, 168), c["gray"] * .85), c["dark"])
        if fl > 0:
            top = mix(top, (255, 255, 255), fl * .8)
        el_ = math.radians(k["el"])
        az_ = math.radians(40 + phase * 60)
        sdir = (-math.cos(el_) * math.cos(az_), math.sin(el_), -math.cos(el_) * math.sin(az_))      # направление НА солнце
        glow = (.15 if night else (.75 if k["el"] < 22 else .3)) * max(0.0, 1 - c["gray"] * 1.1)
        self.sky.update(dt, eye, top, fog, sdir, (205, 215, 255) if night else k["sun"], glow)
        self.far = far if S["fog"] else 1e9
        self.fog_tint = fog
        try:
            scene.fog_color = col(fog)
            window.color = col(fog)
            scene.fog_density = (near, far) if S["fog"] else (5000, 6000)
        except Exception:
            pass
        el = math.radians(k["el"])
        az = math.radians(40 + phase * 60)
        d = (math.cos(el) * math.cos(az), -math.sin(el), math.cos(el) * math.sin(az))
        night = phase > .76
        sun_vis = max(0.0, 1.0 - c["gray"] * 1.25)                 # в пасмурную погоду солнца не видно
        self.disc.position = (eye[0] - d[0] * 280, eye[1] - d[1] * 280, eye[2] - d[2] * 280)
        self.glow.position = self.disc.position
        self.disc.scale = (15 if night else 26) * (1 if sun_vis > .05 else .001)
        self.glow.scale = 70 * (1 if sun_vis > .05 else .001)
        self.disc.color = col((225, 232, 255) if night else k["sun"], 255 * sun_vis)
        self.glow.color = col((150, 170, 230) if night else k["sun"], 55 * sun_vis)
        self.t_light -= dt
        if self.t_light <= 0 or fl > 0:
            self.t_light = .5
            try:
                lsun = .62 if thick else (1.08 if loc == "forest" else 1.0)          # кроны чащи гасят солнце
                amb = mix(k["amb"], (78, 104, 84), .45) if thick else (mix(k["amb"], (150, 170, 196), .3) if tundra else k["amb"])
                if self.sun is not None:
                    self.sun.look_at(Vec3(*d))
                    self.sun.color = col(scale3(k["sun"], c["dark"] * lsun * (1 + fl * 1.2)))
                if self.amb is not None:
                    self.amb.color = col(scale3(amb, (.55 + .45 * c["dark"]) * (1 + fl * 1.5)))
            except Exception:
                pass
        if c["rain"] > 1.5 and S.get("lightning", 1):               # гроза: молния раз в 6-16 секунд
            self.next_bolt -= dt
            if self.next_bolt <= 0:
                self.next_bolt = random.uniform(6, 16)
                self.flash, self.pending = 1.0, .14
                self.events.append(("bolt", random.uniform(0, 6.283), random.uniform(70, 170)))
        nk = max(0.0, min(1.0, (phase - .74) / .06)) if phase > .5 else max(0.0, 1 - phase / .03)
        self.aurora.update(dt, eye, nk * max(0.0, 1 - c["gray"] * 1.4) if tundra else 0.0)
        tint = col(mix((255, 255, 255), scale3(k["sky"], c["dark"] * 1.1), .85), 235)
        shown = 0
        self.drift = (self.drift + (2.5 + 5 * c["wind"]) * dt) % 900.0
        self.cloud_root.position = (eye[0] + self.drift, 0, eye[2])
        self.cloud_t = getattr(self, "cloud_t", 0.0) - dt
        if self.cloud_t <= 0:                                      # цвет и количество облаков - 2 раза в секунду
            self.cloud_t = .5
            groups_on = 0 if not S["clouds"] else max(1, min(3, int(math.ceil(3 * min(1.0, c["cloud"])))))
            for i, e in enumerate(self.clouds):
                on = (i % 3) < groups_on
                if e.enabled != on:
                    e.enabled = on
                if on:
                    e.color = tint


class Precip:
    """Дождь и снег: капли/снежинки собраны в меши (3 группы, у каждой 2 копии одна над другой). Весь «столб» осадков
    сдвигается вниз и по кругу возвращается наверх - выглядит как отдельные капли, а рисуется 2-6 раз вместо 170."""
    H = 12.0

    def __init__(self, n=170):
        self.root = Entity()
        r = random.Random(1)
        self.groups = {}
        for kind, col, size in (("rain", Color(.75, .82, .95, .55), (.012, .55, .012)), ("snow", Color(1, 1, 1, .95), (.07, .07, .07))):
            gl = []
            for g in range(3):
                items = [((r.uniform(-14, 14), r.uniform(0, self.H), r.uniform(-14, 14)), size) for _ in range(n // 3)]
                mesh = merged_mesh(items, "cube")
                pair = []
                for k in range(2):
                    e = Entity(parent=self.root, model=mesh, unlit=True, color=col, enabled=False)
                    try:
                        e.setFogOff()
                    except Exception:
                        pass
                    pair.append(e)
                gl.append(pair)
            self.groups[kind] = gl
        self.on = {"rain": 0, "snow": 0}
        self.off = {"rain": 0.0, "snow": 0.0}
        self.rain, self.snow = [], []                        # совместимость со старым кодом (лёгких узлов больше нет)
        self.per = n // 3

    @property
    def nr(self):
        """Сколько капель сейчас идёт (для отладки и счётчиков)."""
        return self.on["rain"] * self.per

    @property
    def ns(self):
        return self.on["snow"] * self.per

    def update(self, dt, eye, t, rain, snow, wind, level):
        self.root.position = eye
        for kind, amount, speed in (("rain", rain, 24.0), ("snow", snow, 1.6 + wind * 1.5)):
            want = 0 if not (level and amount > .05) else max(1, min(3, int(math.ceil(3 * min(1.0, amount / 2 + .15) * (.5 if level == 1 else 1.0)))))
            if want != self.on[kind]:
                self.on[kind] = want
                for i, pair in enumerate(self.groups[kind]):
                    for e in pair:
                        e.enabled = i < want
            if not want:
                continue
            self.off[kind] = (self.off[kind] + speed * dt) % self.H
            y0 = -self.off[kind] - 1.8
            sway = (math.sin(t * 1.3) * .6 if kind == "snow" else 0.0) + wind * (1.5 if kind == "rain" else 2.5)
            for i in range(want):
                lo, hi = self.groups[kind][i]
                lo.position = (sway * .3 * (i - 1), y0, 0)
                hi.position = (sway * .3 * (i - 1), y0 + self.H, 0)
                if kind == "rain":
                    lo.rotation_z = hi.rotation_z = -wind * 8                     # косой дождь при ветре


class Lightning:
    """Зигзаг молнии из кубиков-звеньев, держится доли секунды."""

    def __init__(self):
        self.segs = [Entity(model="cube", unlit=True, color=Color(.9, .94, 1, 1), enabled=False) for _ in range(14)]
        for e in self.segs:
            try:
                e.setFogOff()
            except Exception:
                pass
        self.life = 0.0

    def strike(self, eye, ang, dist):
        x0, z0 = eye[0] + math.cos(ang) * dist, eye[2] + math.sin(ang) * dist
        pts = [(x0, 150.0, z0)]
        for i in range(1, 15):
            pts.append((x0 + random.uniform(-7, 7) * (i < 14), 150.0 * (1 - i / 14), z0 + random.uniform(-7, 7) * (i < 14)))
        for i, seg in enumerate(self.segs):
            a, b = Vec3(*pts[i]), Vec3(*pts[i + 1])
            seg.position = (a + b) / 2
            seg.scale = (1.3, 1.3, (b - a).length())
            seg.look_at(b)
            seg.enabled = True
        self.life = .22

    def update(self, dt):
        if self.life > 0:
            self.life -= dt
            if self.life <= 0:
                for e in self.segs:
                    e.enabled = False


class Particles:
    """Пул частиц: пыль, брызги, искры (кубики с гравитацией) и дым (шары, которые растут и поднимаются)."""

    def __init__(self, level, model="cube", n=80):
        self.level, self.live = level, []
        self.pool = [Entity(model=model, unlit=True, enabled=False) for _ in range(n if level else 0)]

    def burst(self, pos, n, color, speed=3.0, life=.7, size=.12, up=2.5, grav=9.0, grow=0.0):
        if not self.level:
            return
        n = int(n * (.5 if self.level == 1 else 1))
        for _ in range(n):
            if not self.pool:
                return
            e = self.pool.pop()
            e.enabled = True
            e.position = pos
            e.color = color
            sz = size * random.uniform(.6, 1.4)
            e.scale = sz
            lf = life * random.uniform(.7, 1.2)
            self.live.append([e, random.uniform(-speed, speed), random.uniform(.2, 1) * up, random.uniform(-speed, speed),
                              lf, sz, lf, grav, grow, color])

    def update(self, dt):
        for p in self.live[:]:
            e = p[0]
            p[2] -= p[7] * dt
            e.x += p[1] * dt
            e.z += p[3] * dt
            e.y = max(.03, e.y + p[2] * dt)
            p[4] -= dt
            k = max(0.0, p[4] / p[6])
            if p[4] <= 0:
                e.enabled = False
                self.pool.append(e)
                self.live.remove(p)
            elif p[8]:                                    # дым: растёт и тает
                e.scale = p[5] * (1 + p[8] * (1 - k))
                c = p[9]
                e.color = Color(c.r, c.g, c.b, c.a * k)
            elif p[4] < .25:
                e.scale = p[5] * (p[4] / .25)
