"""HOW TO HUNT - 3D-модели и окружение. Всё собирается из примитивов (кубы, сферы, конусы),
внешних моделей не нужно. Геометрия склеивается в несколько мешей с цветами вершин -
так в сцене сотни деревьев и десятки зверей не убивают FPS.

Координаты: сервер (x, y) -> движок (x, 0, z=y). Модели «смотрят» вдоль оси +Z.
"""
import math
import random

from ursina import Entity, Mesh, Text, Vec3, destroy
from ursina.color import Color

from grass import GrassField
from server import (ANIMALS, BLUEPRINTS, CAMP, CAMP_R, SKINS, SLOT_POS, H, LAYOUTS, NPCS, TENT_D, TENT_H, TENT_W, TENTS, W, struct_world,
                    tent_world)

SHADER = None            # приложение ставит сюда lit_with_shadows_shader, если включены тени
BAKE = False             # без шейдера «запекаем» простое освещение прямо в цвета вершин
DENSITY = 1.0            # плотность растительности (настройка графики)
GRASS_LEVEL = 3          # густота травы 0..4 (настройка графики)
SEED = 0                 # общий seed карты (приходит от сервера): у всех игроков одинаковый случайный мир
AREA = W * H / (320 * 220)   # во сколько раз карта больше прежней
_AVOID = []              # (x, z, r) - места построек и логова: туда не ставим деревья
_L = (.35, .8, .45)
_Ll = math.sqrt(sum(c * c for c in _L))
CX, CZ = CAMP


def rgb(r, g, b, a=255):
    return Color(r / 255, g / 255, b / 255, a / 255)


def ent(**kw):
    """Entity, которому автоматически дают шейдер освещения (если включён)."""
    if SHADER is not None and 'shader' not in kw and not kw.get('unlit'):
        kw['shader'] = SHADER
    return Entity(**kw)


# ------------------------------------------------------------------ склейка геометрии
def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _unit_cube():
    verts, norms, tris = [], [], []
    for n, w in (((0, 0, 1), (0, 1, 0)), ((0, 0, -1), (0, 1, 0)), ((1, 0, 0), (0, 1, 0)),
                 ((-1, 0, 0), (0, 1, 0)), ((0, 1, 0), (0, 0, 1)), ((0, -1, 0), (0, 0, 1))):
        r = _cross(w, (-n[0], -n[1], -n[2]))                 # вид снаружи: r x w = -n (левая система Ursina)
        base = len(verts)
        for sr, sw in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            verts.append(tuple(n[i] * .5 + r[i] * .5 * sr + w[i] * .5 * sw for i in range(3)))
            norms.append(n)
        tris += [(base, base + 1, base + 2), (base, base + 2, base + 3)]
    return verts, norms, tris


def _unit_sphere(seg, ring):
    verts, norms, tris = [], [], []
    for r in range(ring + 1):
        th = math.pi * r / ring
        for s in range(seg + 1):
            ph = 2 * math.pi * s / seg
            n = (math.sin(th) * math.cos(ph), math.cos(th), math.sin(th) * math.sin(ph))
            verts.append((n[0] * .5, n[1] * .5, n[2] * .5))
            norms.append(n)
    for r in range(ring):
        for s in range(seg):
            i = r * (seg + 1) + s
            tris += [(i, i + seg + 1, i + 1), (i + 1, i + seg + 1, i + seg + 2)]
    return verts, norms, tris


def _unit_cone(seg):
    verts, norms, tris = [], [], []
    for s in range(seg + 1):
        a = 2 * math.pi * s / seg
        am = 2 * math.pi * (s + .5) / seg
        l = math.hypot(1, .5)
        verts.append((.5 * math.cos(a), 0, .5 * math.sin(a)))
        norms.append((math.cos(a) / l, .5 / l, math.sin(a) / l))
        verts.append((0, 1, 0))
        norms.append((math.cos(am) / l, .5 / l, math.sin(am) / l))
    for s in range(seg):
        i = s * 2
        tris.append((i, i + 1, i + 2))
    return verts, norms, tris


def _unit_rock(seed):
    """Неровный граненый камень: сфера со случайными радиусами и плоским основанием, грани с плоскими нормалями."""
    r = random.Random(seed)
    seg, ring = 7, 5
    grid = [[(0, .5 * r.uniform(.9, 1.0), 0)] * seg]
    for i in range(1, ring):
        th = math.pi * i / ring
        row = []
        for j in range(seg):
            ph = 2 * math.pi * j / seg
            rad = .5 * r.uniform(.8, 1.12)
            y = math.cos(th) * rad
            row.append((math.sin(th) * math.cos(ph) * rad, y * (.55 if y < 0 else 1.0), math.sin(th) * math.sin(ph) * rad))
        grid.append(row)
    grid.append([(0, -.5 * .55 * r.uniform(.9, 1.0), 0)] * seg)
    verts, norms, tris = [], [], []

    def tri(a, b, c):
        n = _cross((b[0] - a[0], b[1] - a[1], b[2] - a[2]), (c[0] - a[0], c[1] - a[1], c[2] - a[2]))
        ln = math.sqrt(n[0] ** 2 + n[1] ** 2 + n[2] ** 2)
        if ln < 1e-9:
            return
        n = (n[0] / ln, n[1] / ln, n[2] / ln)
        cen = ((a[0] + b[0] + c[0]) / 3, (a[1] + b[1] + c[1]) / 3, (a[2] + b[2] + c[2]) / 3)
        if n[0] * cen[0] + n[1] * cen[1] + n[2] * cen[2] < 0:
            n, b, c = (-n[0], -n[1], -n[2]), c, b
        i0 = len(verts)
        verts.extend([a, b, c])
        norms.extend([n, n, n])
        tris.append((i0, i0 + 1, i0 + 2))

    for i in range(ring):
        for j in range(seg):
            j2 = (j + 1) % seg
            a, b, c, d = grid[i][j], grid[i][j2], grid[i + 1][j2], grid[i + 1][j]
            tri(a, b, c)
            tri(a, c, d)
    return verts, norms, tris


_SHAPES = {'cube': _unit_cube(), 'sphere': _unit_sphere(8, 6), 'sphere_hi': _unit_sphere(12, 8), 'cone': _unit_cone(8),
           'blade': _unit_cone(4), 'sphere_lo': _unit_sphere(6, 4),
           'rock0': _unit_rock(1), 'rock1': _unit_rock(2), 'rock2': _unit_rock(3)}


def _rot(v, rx, ry, rz):
    x, y, z = v
    if rz:
        c, s = math.cos(rz), math.sin(rz)
        x, y = x * c - y * s, x * s + y * c
    if rx:
        c, s = math.cos(rx), math.sin(rx)
        y, z = y * c - z * s, y * s + z * c
    if ry:
        c, s = math.cos(ry), math.sin(ry)
        x, z = x * c + z * s, -x * s + z * c
    return x, y, z


class Batch:
    """Копит примитивы с цветами и превращает их в меши. С chunk=N мир режется на квадраты N x N метров:
    движок не рисует участки вне поля зрения, а игра выключает далёкие участки (оптимизация)."""

    def __init__(self, chunk=None):
        self.chunk = chunk
        self.parts = {}                                       # участок -> [готовые куски, v, n, c, t]

    def _part(self, pos):
        key = (int(pos[0] // self.chunk), int(pos[2] // self.chunk)) if self.chunk else 0
        st = self.parts.get(key)
        if st is None:
            st = self.parts[key] = [[], [], [], [], []]
        return st

    def add(self, shape, col, scale, pos, rot=(0, 0, 0)):
        st = self._part(pos)
        if len(st[1]) > 52000:
            st[0].append((st[1], st[2], st[3], st[4]))
            st[1], st[2], st[3], st[4] = [], [], [], []
        if shape == 'sphere' and (scale[0] if isinstance(scale, tuple) else scale) > 30:
            shape = 'sphere_hi'
        V, N, T = _SHAPES[shape]
        sx, sy, sz = scale if isinstance(scale, tuple) else (scale, scale, scale)
        rx, ry, rz = (math.radians(a) for a in rot)
        px, py, pz = pos
        vv, nn, cc = st[1], st[2], st[3]
        base = len(vv)
        for (x, y, z), (nx, ny, nz) in zip(V, N):
            vx, vy, vz = _rot((x * sx, y * sy, z * sz), rx, ry, rz)
            ax, ay, az = _rot((nx / sx, ny / sy, nz / sz), rx, ry, rz)
            ln = math.sqrt(ax * ax + ay * ay + az * az) or 1.0
            vv.append(Vec3(vx + px, vy + py, vz + pz))
            nn.append(Vec3(ax / ln, ay / ln, az / ln))
            if BAKE:
                k = .5 + .5 * max(0.0, (ax * _L[0] + ay * _L[1] + az * _L[2]) / (ln * _Ll))
                cc.append(Color(col.r * k, col.g * k, col.b * k, col.a))
            else:
                cc.append(col)
        st[4] += [(a + base, b + base, c + base) for a, b, c in T]

    def build(self, parent=None, unlit=False, offset=0, **kw):
        """Возвращает контейнер-Entity с мешами внутри; root.hth_chunks - список (меш, центр x, центр z, внутри карты)."""
        root = ent(parent=parent, unlit=True) if parent is not None else ent(unlit=True)
        chunks = []
        for key, st in self.parts.items():
            if st[1]:
                st[0].append((st[1], st[2], st[3], st[4]))
            for v, n, c, t in st[0]:
                e = ent(parent=root, model=Mesh(vertices=v, triangles=t, colors=c, normals=n), double_sided=True, unlit=unlit, **kw)
                if offset:
                    try:
                        e.setDepthOffset(offset)              # слой «наклеек» на земле всегда чуть ближе к камере, чем земля под ним
                    except Exception:
                        pass
                if self.chunk:
                    cx, cz = (key[0] + .5) * self.chunk, (key[1] + .5) * self.chunk
                    chunks.append((e, cx, cz, 0 <= cx <= W and 0 <= cz <= H, self.chunk / 2))
        self.parts = {}
        root.hth_chunks = chunks
        return root


# ------------------------------------------------------------------ животные
SPECS = {
    'rabbit': dict(body=(.26, .24, .48), head=(.2, .2, .22), leg=(.06, .16), col=(205, 195, 175), dark=(150, 140, 125), ears=(.05, .22), tail=.1),
    'deer':   dict(body=(.48, .5, 1.05), head=(.24, .26, .4), leg=(.09, .62), col=(165, 112, 62), dark=(95, 65, 40), antlers=True, neck=True, tail=.1),
    'boar':   dict(body=(.7, .62, 1.15), head=(.4, .4, .5), leg=(.12, .3), col=(96, 72, 62), dark=(60, 45, 40), tusks=True, tail=.08),
    'fox':    dict(body=(.28, .28, .65), head=(.2, .2, .3), leg=(.06, .28), col=(245, 245, 250), dark=(185, 190, 205), ears=(.06, .14), tail=.32),
    'wolf':   dict(body=(.4, .42, .95), head=(.26, .26, .42), leg=(.09, .5), col=(128, 130, 142), dark=(80, 82, 92), ears=(.07, .16), tail=.38),
    'bear':   dict(body=(1.0, .95, 1.65), head=(.55, .5, .6), leg=(.26, .5), col=(84, 52, 34), dark=(50, 30, 20), ears=(.14, .12), tail=.12, hump=True),
    'redfox': dict(body=(.28, .28, .68), head=(.2, .2, .3), leg=(.06, .28), col=(214, 104, 42), dark=(62, 42, 30), ears=(.06, .15), tail=.42),
    'grouse': dict(body=(.3, .26, .42), head=(.11, .12, .13), leg=(.03, .2), col=(76, 66, 70), dark=(40, 36, 40), tail=.22, beak=True, wings=True, comb=True),
    'moose':  dict(body=(.8, .95, 1.7), head=(.3, .4, .75), leg=(.14, 1.0), col=(88, 64, 46), dark=(50, 36, 28), neck=True, hump=True, palmate=True, tail=.12),
    'hare':   dict(body=(.25, .24, .5), head=(.18, .18, .22), leg=(.06, .18), col=(240, 242, 248), dark=(172, 178, 190), ears=(.05, .27), tail=.08),
    'reindeer': dict(body=(.52, .54, 1.1), head=(.24, .26, .42), leg=(.09, .7), col=(150, 128, 108), dark=(92, 76, 62), antlers=True, big=True, neck=True, tail=.1),
    'musk':   dict(body=(.95, .95, 1.5), head=(.5, .5, .6), leg=(.17, .45), col=(52, 40, 34), dark=(30, 24, 20), horns=True, hump=True, tail=.1),
}


def _boss_spec(base, k, col, dark, **extra):
    s = dict(SPECS[base])
    for key in ("body", "head", "leg", "ears"):
        if key in s:
            s[key] = tuple(v * k for v in s[key])
    s["tail"] = s["tail"] * k
    s.update(col=col, dark=dark, **extra)
    return s


SPECS["boss_boar"] = _boss_spec("boar", 2.2, (62, 46, 40), (34, 26, 22))
SPECS["boss_bear"] = _boss_spec("bear", 1.9, (34, 26, 22), (18, 14, 12))
SPECS["boss_wolf"] = _boss_spec("wolf", 2.2, (236, 240, 246), (170, 178, 196))


def make_animal(kind, gold=False, unlit=False):
    s = SPECS[kind]
    bw, bh, bl = s['body']
    lw, lh = s['leg']
    hw, hh, hl = s['head']
    col, dark = rgb(*s['col']), rgb(*s['dark'])
    if gold:                                                  # золотой зверь: шкура цвета золота
        col, dark = rgb(244, 196, 58), rgb(196, 140, 24)
    b = Batch()
    b.add('cube', col, (bw, bh, bl), (0, lh + bh / 2, 0))
    if s.get('hump'):
        b.add('cube', col, (bw * .9, bh * .4, bl * .35), (0, lh + bh + bh * .12, bl * .15))
    if s.get('neck'):
        b.add('cube', col, (hw * .75, .5, hw * .8), (0, lh + bh + .1, bl / 2 - .05))
        hy = lh + bh + .38
    else:
        hy = lh + bh * .72
    hz = bl / 2 + hl * .25
    b.add('cube', col, (hw, hh, hl), (0, hy, hz))
    b.add('cube', dark, (hw * .38, hh * .26, .05), (0, hy - hh * .12, hz + hl / 2))
    for sx in (-1, 1):
        b.add('cube', rgb(12, 12, 12), (.04, .04, .03), (sx * hw * .33, hy + hh * .14, hz + hl / 2 - .005))
        if 'ears' in s:
            ew, eh = s['ears']
            b.add('cube', col, (ew, eh, ew * .6), (sx * hw * .32, hy + hh / 2 + eh / 2 - .02, hz - hl * .12))
        if s.get('antlers'):
            k = 1.9 if s.get('big') else 1.0                   # северный олень - крупные ветвистые рога
            b.add('cube', rgb(225, 215, 190), (.03 * k, .34 * k, .03 * k), (sx * .1, hy + hh / 2 + .15 * k, hz - .06))
            b.add('cube', rgb(225, 215, 190), (.18 * k, .03, .03), (sx * .17 * k, hy + hh / 2 + .26 * k, hz - .06))
            if k > 1:
                b.add('cube', rgb(225, 215, 190), (.03, .3, .03), (sx * .34, hy + hh / 2 + .5, hz - .06))
        if s.get('palmate'):                                    # лось: широкие «лопатой» рога
            b.add('cube', rgb(205, 190, 160), (.55, .05, .42), (sx * .42, hy + hh / 2 + .22, hz - .12), (0, sx * -15, sx * 12))
        if s.get('horns'):                                      # овцебык: загнутые рога
            b.add('cube', rgb(226, 220, 200), (.08, .08, .34), (sx * (hw / 2 + .12), hy - .02, hz - .05))
            b.add('cube', rgb(226, 220, 200), (.08, .3, .08), (sx * (hw / 2 + .26), hy + .13, hz - .05))
        if s.get('tusks'):
            b.add('cube', rgb(235, 230, 215), (.04, .04, .14), (sx * hw * .32, hy - hh * .25, hz + hl / 2))
    if s.get('wings'):                                          # тетерев: сложенные крылья, клюв, красная «бровь»
        for sx in (-1, 1):
            b.add('cube', dark, (.04, .18, .32), (sx * (bw / 2 + .01), lh + bh * .6, -.02))
    if s.get('beak'):
        b.add('cube', rgb(230, 190, 60), (.04, .04, .07), (0, hy - .01, hz + hl / 2 + .04))
    if s.get('comb'):
        b.add('cube', rgb(210, 40, 40), (.1, .03, .06), (0, hy + hh / 2 + .01, hz + .01))
        for i in (-1, 0, 1):
            b.add('cube', dark, (.03, .03, .2), (i * .06, lh + bh * .85, -bl / 2 - .1), (0, i * 22, 0))
    t = s['tail']
    b.add('cube', col if t < .2 else dark, (max(.07, t * .35), max(.07, t * .35), t),
          (0, lh + bh * .78, -bl / 2 - t / 2 + .03))
    for sx, sz in ((-1, 1), (1, 1), (-1, -1), (1, -1)):
        b.add('cube', dark, (lw, lh, lw), (sx * bw * .32, lh / 2, sz * bl * .34))
    root = b.build(unlit=unlit)
    root.hth_kind = kind
    root.hth_gold = gold
    if kind.startswith("boss_"):                              # имя босса над головой
        Text(text=ANIMALS[kind]["name"], parent=root, position=(0, lh + bh + hh + 1.4, 0), origin=(0, 0), scale=22,
             billboard=True, color=rgb(255, 90, 70))
    return root


# ------------------------------------------------------------------ оружие и охотник
def make_weapon(kind, parent, unlit=False, dyn=False, skin=None):
    b = Batch()
    wood, steel = rgb(120, 80, 45), rgb(45, 48, 54)
    acc = None
    if skin in SKINS and SKINS[skin][0] == kind:              # скин: свои цвета дерева и металла, у редких - акцентные полосы
        wood, steel = rgb(*SKINS[skin][3]), rgb(*SKINS[skin][4])
        acc = rgb(*SKINS[skin][5]) if SKINS[skin][5] else None
    if kind == 'bow':
        b.add('cube', wood, (.035, .3, .035), (0, 0, 0))
        b.add('cube', wood, (.03, .24, .03), (0, .24, -.06))
        b.add('cube', wood, (.03, .24, .03), (0, -.24, -.06))
        b.add('cube', wood, (.03, .2, .03), (0, .42, -.13))
        b.add('cube', wood, (.03, .2, .03), (0, -.42, -.13))
        if not dyn:                                           # у вида от первого лица тетива рисуется отдельно
            b.add('cube', rgb(230, 225, 200), (.01, .85, .01), (0, 0, -.15))
        mz = .3
    elif kind == 'rifle':
        b.add('cube', steel, (.04, .04, .75), (0, 0, .4))
        b.add('cube', steel, (.06, .09, .4), (0, -.01, 0))
        b.add('cube', wood, (.06, .12, .3), (0, -.04, -.28))
        mz = .8
    elif kind == 'shotgun':
        b.add('cube', steel, (.07, .05, .7), (0, 0, .35))
        b.add('cube', wood, (.09, .06, .22), (0, -.05, .25))
        b.add('cube', steel, (.07, .1, .3), (0, -.01, 0))
        b.add('cube', wood, (.07, .13, .3), (0, -.04, -.25))
        mz = .72
    else:                                    # sniper
        b.add('cube', steel, (.035, .035, 1.0), (0, 0, .55))
        b.add('cube', steel, (.06, .1, .5), (0, 0, 0))
        b.add('cube', wood, (.06, .13, .35), (0, -.04, -.35))
        b.add('cube', rgb(25, 25, 30), (.05, .05, .28), (0, .09, .1))
        b.add('cube', rgb(90, 150, 230), (.04, .04, .02), (0, .09, .25))
        mz = 1.05
    if acc is not None:
        if kind == 'bow':
            for sy in (-1, 1):
                b.add('cube', acc, (.042, .05, .042), (0, sy * .52, -.15))
            b.add('cube', acc, (.045, .08, .045), (0, 0, .005))
        else:
            b.add('cube', acc, (.03, .012, mz * .8), (0, .03 if kind != 'sniper' else .05, mz * .42))      # полоса вдоль ствола
            for zz in (-.2, -.32):
                b.add('cube', acc, (.072 if kind != 'shotgun' else .082, .02, .03), (0, -.04, zz))          # кольца на прикладе
    g = b.build(parent=parent, unlit=unlit)
    g.hth_muzzle = ent(parent=g, position=(0, 0, mz), unlit=True)
    g.hth_kind = kind
    g.hth_skin = skin
    return g


def make_hunter(name):
    b = Batch()
    b.add('cube', rgb(70, 120, 200), (.5, .7, .28), (0, 1.05, 0))
    b.add('sphere', rgb(240, 205, 170), .3, (0, 1.58, 0))
    b.add('cube', rgb(110, 70, 35), (.34, .1, .34), (0, 1.75, 0))
    b.add('cube', rgb(110, 70, 35), (.52, .03, .52), (0, 1.69, 0))
    for sx in (-1, 1):
        b.add('cube', rgb(90, 140, 220), (.13, .55, .13), (sx * .33, 1.05, 0))
        b.add('cube', rgb(55, 60, 80), (.18, .7, .2), (sx * .13, .35, 0))
    root = b.build()
    root.hth_wkind = None
    root.hth_gun = None
    set_hunter_weapon(root, 'bow')
    Text(text=name, parent=root, position=(0, 2.2, 0), origin=(0, 0), scale=12, billboard=True,
         color=rgb(255, 240, 180))
    return root


def carry_size(kind):
    """(длина с головой, высота) зверя в метрах по его параметрам."""
    s = SPECS[kind]
    return s['body'][2] + s['head'][2] * .8, s['leg'][1] + s['body'][1] + s['head'][1] * .5


def set_hunter_carry(root, kind, gold=False):
    """Охотник несёт добычу на плечах: зверь лежит поперёк плеч, оружие убрано за спину (скрыто)."""
    key = (kind, gold) if kind else None
    if getattr(root, "hth_carry_key", "none") == key:
        return
    root.hth_carry_key = key
    old = getattr(root, "hth_carry", None)
    if old is not None:
        destroy(old)
        root.hth_carry = None
    if root.hth_gun is not None:
        root.hth_gun.enabled = key is None
    if kind is None:
        return
    ln, h = carry_size(kind)
    e = make_animal(kind, gold)
    e.parent = root
    sc = max(.18, min(.62, 1.15 / max(ln, .3)))
    e.scale = sc
    e.rotation = (0, 90, 0)                                   # тело поперёк плеч, голова вправо
    e.position = (0, 1.4 - min(.2, h * sc * .1), -.06)
    root.hth_carry = e


def set_hunter_weapon(root, kind, skin=None):
    if root.hth_wkind == (kind, skin):
        return
    if root.hth_gun is not None:
        destroy(root.hth_gun)
    root.hth_gun = make_weapon(kind, root, skin=skin)
    root.hth_gun.position = (.28, 1.0, .3)
    root.hth_gun.enabled = getattr(root, "hth_carry_key", None) is None      # пока несёт добычу - оружие спрятано
    root.hth_wkind = (kind, skin)


# ------------------------------------------------------------------ окружение
def _pine(b, x, z, s, snow, rnd):
    g = rnd.uniform(.85, 1.15)
    green = rgb(int(30 * g), int(88 * g), int(62 * g))
    top = rgb(238, 244, 250) if snow else rgb(int(40 * g), int(105 * g), int(70 * g))
    b.add('cube', rgb(80, 58, 38), (.5 * s, 2.2 * s, .5 * s), (x, 1.1 * s, z))
    b.add('cone', green, (3.8 * s, 3.2 * s, 3.8 * s), (x, 1.5 * s, z))
    b.add('cone', top if snow else green, (3.0 * s, 2.8 * s, 3.0 * s), (x, 3.3 * s, z))
    b.add('cone', top, (2.1 * s, 2.4 * s, 2.1 * s), (x, 5.0 * s, z))


def _limb(b, p0, p1, thick, col):
    """Брусок от точки p0 до p1 (для наклонных стволов)."""
    dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    rz = -math.asin(max(-1, min(1, dx / length)))
    rx = math.asin(max(-1, min(1, dz / (length * (math.cos(rz) or 1e-6)))))
    mid = ((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2, (p0[2] + p1[2]) / 2)
    b.add('cube', col, (thick, length * 1.06, thick), mid, (math.degrees(rx), 0, math.degrees(rz)))


def _trunk(b, x, z, h, thick, rnd, col, segs=3):
    """Тонкий ствол, наклонённый и слегка изогнутый; возвращает верхнюю точку."""
    ang, mag = rnd.uniform(0, 6.283), rnd.uniform(.05, .17) * h
    pts = [(x + math.cos(ang) * mag * (i / segs) ** 1.6, h * i / segs, z + math.sin(ang) * mag * (i / segs) ** 1.6)
           for i in range(segs + 1)]
    for i in range(segs):
        _limb(b, pts[i], pts[i + 1], thick * (1 - .3 * i / segs), col)
    return pts[-1]


PALETTES = [((38, 104, 50), (58, 132, 62), (46, 118, 56))] * 6 + [
    ((96, 140, 40), (130, 170, 52), (112, 156, 46)),          # светло-зелёная
    ((176, 112, 30), (214, 142, 40), (194, 126, 34)),         # осенняя жёлтая
    ((170, 62, 34), (205, 88, 42), (188, 74, 38))]            # осенняя красная


def _broadleaf(b, x, z, s, rnd, birch_p=.18, light=1.0):
    g = rnd.uniform(.85, 1.15) * light
    birch = rnd.random() < birch_p
    pal = PALETTES[-2] if birch else rnd.choice(PALETTES)
    tx, ty, tz = _trunk(b, x, z, 4.6 * s, (.3 if birch else .42) * s, rnd, rgb(226, 224, 212) if birch else rgb(92, 64, 40))
    c1, c2, c3 = (rgb(*[min(255, int(v * g)) for v in c]) for c in pal)
    b.add('sphere', c1, (4.6 * s, 3.2 * s, 4.6 * s), (tx, ty + 1.0 * s, tz))
    b.add('sphere', c2, (3.0 * s, 2.4 * s, 3.0 * s), (tx + .9 * s, ty + 2.1 * s, tz - .4 * s))
    b.add('sphere', c3, (2.6 * s, 2.2 * s, 2.6 * s), (tx - 1.1 * s, ty + .5 * s, tz + .7 * s))


def _rock(b, x, z, s, rnd, snow, moss=False):
    base = rnd.randint(105, 150)
    col = (base - 34, base + 10, base - 26) if moss else (base + 6, base, base - 6)
    b.add('rock%d' % rnd.randrange(3), rgb(*col), (1.9 * s, 1.15 * s, 1.6 * s), (x, .32 * s, z), (0, rnd.uniform(0, 360), 0))
    if snow:
        b.add('rock1', rgb(240, 245, 250), (1.4 * s, .55 * s, 1.15 * s), (x, .66 * s, z), (0, rnd.uniform(0, 360), 0))


def _boulder(b, x, z, s, rnd, snow, moss=False):
    """Крупный валун из нескольких неровных граней."""
    base = rnd.randint(86, 118)
    for i in range(rnd.randint(2, 3)):
        sc = (rnd.uniform(2.4, 3.8) * s * (1 - .25 * i), rnd.uniform(1.8, 2.8) * s * (1 - .2 * i), rnd.uniform(2.2, 3.4) * s * (1 - .25 * i))
        px, pz = x + rnd.uniform(-1.1, 1.1) * s * i, z + rnd.uniform(-1.1, 1.1) * s * i
        col = (base - 30 - i * 5, base + 8, base - 24) if moss else (base + 8 - i * 6, base - i * 6, base - 6 - i * 4)
        b.add('rock%d' % rnd.randrange(3), rgb(*col), sc, (px, sc[1] * .3, pz), (0, rnd.uniform(0, 360), 0))
        if i == 0:
            cap = (sc[0] * .62, sc[1] * .32, sc[2] * .62)
            b.add('rock1', rgb(240, 245, 250) if snow else (rgb(70, 130, 60) if moss else rgb(base + 40, base + 34, base + 22)),
                  cap, (px, sc[1] * .62, pz), (0, rnd.uniform(0, 360), 0))


def _bush(b, x, z, s, rnd, berries=False, autumn=False):
    """Куст из нескольких зелёных «шаров»; иногда с ягодами."""
    g = rnd.uniform(.8, 1.2)
    pal = (190, 130, 40) if autumn else (int(46 * g), int(112 * g), int(52 * g))
    for dx, dz, k in ((0, 0, 1.0), (.8, .3, .75), (-.7, -.4, .8)):
        b.add('sphere_lo', rgb(*[min(255, int(v * (.9 + .25 * k))) for v in pal]), (1.8 * s * k, 1.3 * s * k, 1.8 * s * k),
              (x + dx * s, .55 * s * k, z + dz * s))
    if berries:
        for _ in range(6):
            a, r = rnd.uniform(0, 6.283), rnd.uniform(.5, .9) * s
            b.add('cube', rgb(200, 30, 50), (.1, .1, .1), (x + math.cos(a) * r, rnd.uniform(.4, .9) * s, z + math.sin(a) * r))


def _fern(b, x, z, rnd, big=False):
    """Папоротник: лезвия-листья веером."""
    g = rnd.uniform(.75, 1.2)
    k = 1.5 if big else 1.0
    for i in range(7):
        b.add('blade', rgb(int(30 * g), int(110 * g), int(46 * g)), (.2 * k, rnd.uniform(.9, 1.5) * k, .2 * k), (x, 0, z),
              (rnd.uniform(38, 58), i * 360 / 7 + rnd.uniform(-15, 15), 0))


def _mushroom(b, x, z, rnd):
    cap = rnd.choice(((200, 50, 40), (176, 118, 66), (226, 190, 70)))
    h = rnd.uniform(.12, .22)
    b.add('cube', rgb(236, 228, 208), (.06, h, .06), (x, h / 2, z))
    b.add('sphere_lo', rgb(*cap), (.24, .12, .24), (x, h + .03, z))
    if cap[0] == 200:
        for dx, dz in ((.05, .02), (-.04, .05), (-.02, -.06)):
            b.add('cube', rgb(250, 250, 245), (.035, .02, .035), (x + dx, h + .08, z + dz))


def _dry_shrub(b, x, z, rnd, snow):
    for i in range(9):
        b.add('blade', rgb(150 + rnd.randint(-20, 20), 116 + rnd.randint(-15, 15), 70), (.1, rnd.uniform(.7, 1.3), .1), (x, 0, z),
              (rnd.uniform(15, 40), i * 40 + rnd.uniform(-12, 12), 0))
    if snow:
        b.add('sphere_lo', rgb(244, 248, 252), (.9, .26, .9), (x, .5, z))


def _dead_tree(b, x, z, s, rnd):
    tx, ty, tz = _trunk(b, x, z, 5.0 * s, .34 * s, rnd, rgb(96, 84, 74))
    for i in range(3):
        a = rnd.uniform(0, 6.283)
        h0 = ty * rnd.uniform(.45, .8)
        _limb(b, (x, h0, z), (x + math.cos(a) * 1.4 * s, h0 + rnd.uniform(.6, 1.3) * s, z + math.sin(a) * 1.4 * s), .13 * s, rgb(96, 84, 74))


def _tuft(b, x, z, rnd, forest):
    """Пучок травы из нескольких наклонных лезвий."""
    k = rnd.uniform(.8, 1.2)
    for _ in range(rnd.randint(4, 6)):
        col = rgb(int(66 * k), int(138 * k), int(56 * k)) if forest else rgb(int(196 * k), int(180 * k), int(122 * k))
        h = rnd.uniform(.5, 1.0) if forest else rnd.uniform(.3, .65)
        b.add('blade', col, (.15, h, .15), (x + rnd.uniform(-.28, .28), 0, z + rnd.uniform(-.28, .28)),
              (rnd.uniform(-20, 20), rnd.uniform(0, 360), rnd.uniform(-20, 20)))


def _flowers(b, x, z, rnd):
    for _ in range(rnd.randint(4, 7)):
        fx, fz = x + rnd.uniform(-1.2, 1.2), z + rnd.uniform(-1.2, 1.2)
        b.add('cube', rgb(60, 130, 52), (.03, .38, .03), (fx, .19, fz))
        b.add('cube', rgb(*rnd.choice(((240, 84, 84), (250, 222, 70), (244, 244, 250), (182, 122, 240)))),
              (.13, .09, .13), (fx, .4, fz), (0, rnd.uniform(0, 90), 0))


def _log(b, x, z, rnd):
    b.add('cube', rgb(96, 68, 42), (rnd.uniform(2.6, 4.6), .56, .56), (x, .28, z), (0, rnd.uniform(0, 360), rnd.uniform(-4, 4)))


def _stump(b, x, z):
    b.add('cube', rgb(100, 72, 46), (.72, .5, .72), (x, .25, z))
    b.add('cube', rgb(190, 150, 100), (.62, .04, .62), (x, .51, z))


def _spruce(b, x, z, s, rnd):
    """Высокая тёмная ель старого леса: много ярусов, узкая вершина."""
    g = rnd.uniform(.85, 1.1)
    h = rnd.uniform(9, 13) * s / 1.4
    b.add('cube', rgb(62, 44, 32), (.55 * s, h * .35, .55 * s), (x, h * .175, z))
    tiers = 6
    for i in range(tiers):
        f = i / tiers
        wdt = (3.6 - 2.9 * f) * s
        col = rgb(int((20 + 10 * f) * g), int((56 + 20 * f) * g), int((44 + 10 * f) * g))
        b.add('cone', col, (wdt, h * .32, wdt), (x, h * (.12 + .78 * f), z))


def _old_oak(b, x, z, s, rnd):
    """Могучий старый дуб: толстый ствол, корни, тяжёлая тёмная крона."""
    g = rnd.uniform(.8, 1.05)
    trunk = rgb(70, 52, 38)
    tx, ty, tz = _trunk(b, x, z, 5.2 * s, 1.0 * s, rnd, trunk, segs=2)
    for i in range(5):                                        # корни
        a = i * 1.257 + rnd.uniform(-.3, .3)
        _limb(b, (x, .5 * s, z), (x + math.cos(a) * 1.5 * s, 0, z + math.sin(a) * 1.5 * s), .35 * s, trunk)
    for i in range(3):                                        # толстые ветви
        a = rnd.uniform(0, 6.283)
        _limb(b, (tx, ty - 1.2 * s, tz), (tx + math.cos(a) * 2.6 * s, ty + .6 * s, tz + math.sin(a) * 2.6 * s), .35 * s, trunk)
    for dx, dy, dz, k in ((0, 1.4, 0, 1.0), (2.2, .9, .6, .75), (-2.0, .8, -.8, .8), (.4, 2.4, -1.4, .7), (-.8, 2.2, 1.6, .7)):
        b.add('sphere', rgb(int(30 * g), int(78 * g), int(38 * g)), (5.2 * s * k, 3.6 * s * k, 5.2 * s * k),
              (tx + dx * s, ty + dy * s, tz + dz * s))


def _fallen_tree(b, x, z, s, rnd, moss=True):
    """Поваленное дерево с вывороченным корнем."""
    a = rnd.uniform(0, 6.283)
    ln = rnd.uniform(6, 10) * s
    ex, ez = x + math.cos(a) * ln, z + math.sin(a) * ln
    col = rgb(84, 92, 56) if moss else rgb(96, 70, 46)
    _limb(b, (x, .45 * s, z), (ex, .3 * s, ez), .6 * s, col)
    if FAR[0] is not None and b is not FAR[0]:
        _far_add('cube', col, (.6 * s, .6 * s, ln), ((x + ex) / 2, .4 * s, (z + ez) / 2), (0, 90 - math.degrees(a), 0))
    b.add('sphere', rgb(86, 66, 44), (.3 * s, 2.4 * s, 2.4 * s), (x - math.cos(a) * .2, 1.0 * s, z - math.sin(a) * .2), (0, -math.degrees(a), 0))
    for i in range(3):
        f = rnd.uniform(.3, .9)
        px, pz = x + (ex - x) * f, z + (ez - z) * f
        _limb(b, (px, .5 * s, pz), (px + rnd.uniform(-1, 1), 1.3 * s, pz + rnd.uniform(-1, 1)), .12 * s, col)


def _reeds(b, x, z, rnd):
    """Камыш у воды: высокие стебли с коричневыми початками."""
    for _ in range(rnd.randint(5, 9)):
        px, pz = x + rnd.uniform(-.8, .8), z + rnd.uniform(-.8, .8)
        h = rnd.uniform(1.2, 2.0)
        b.add('cube', rgb(84, 120, 60), (.035, h, .035), (px, h / 2, pz), (rnd.uniform(-6, 6), 0, rnd.uniform(-6, 6)))
        if rnd.random() < .6:
            b.add('cube', rgb(110, 72, 40), (.08, .28, .08), (px, h - .1, pz))


def _dwarf_birch(b, x, z, s, rnd):
    """Карликовая берёзка тундры: тонкий белый ствол, редкая жёлтая крона, снег на ветках."""
    tx, ty, tz = _trunk(b, x, z, 2.2 * s, .14 * s, rnd, rgb(228, 226, 214))
    b.add('sphere_lo', rgb(196, 168, 70), (1.6 * s, 1.0 * s, 1.6 * s), (tx, ty + .3 * s, tz))
    b.add('sphere_lo', rgb(244, 248, 252), (1.2 * s, .35 * s, 1.2 * s), (tx, ty + .7 * s, tz))


def _ice(b, x, z, rnd):
    """Ледяные кристаллы у замёрзшей воды."""
    for _ in range(rnd.randint(3, 6)):
        h = rnd.uniform(.6, 2.2)
        b.add('cone', rgb(170, 215, 240), (.5, h, .5), (x + rnd.uniform(-1.2, 1.2), 0, z + rnd.uniform(-1.2, 1.2)),
              (rnd.uniform(-18, 18), rnd.uniform(0, 360), rnd.uniform(-18, 18)))


FAR = [None]            # Batch для упрощённых дальних версий деревьев (во время сборки локации)


def _far_add(*a):
    if FAR[0] is not None:
        FAR[0].add(*a)


def _lod(fn, far_fn):
    """Обёртка: рисует полное дерево в обычный слой и упрощённое (1-2 фигуры) в дальний слой."""
    def wrapped(b, x, z, s, *a, **k):
        r = fn(b, x, z, s, *a, **k)
        if FAR[0] is not None and b is not FAR[0]:
            far_fn(x, z, s, *a, **k)
        return r
    return wrapped


_pine = _lod(_pine, lambda x, z, s, snow, rnd: _far_add(
    'cone', rgb(206, 220, 228) if snow else rgb(32, 92, 64), (3.7 * s, 6.6 * s, 3.7 * s), (x, .6 * s, z)))
_broadleaf = _lod(_broadleaf, lambda x, z, s, rnd, birch_p=.18, light=1.0: (
    _far_add('cube', rgb(92, 64, 40), (.45 * s, 4.6 * s, .45 * s), (x, 2.3 * s, z)),
    _far_add('sphere_lo', rgb(int(52 * light), int(124 * light), int(58 * light)), (5.2 * s, 4.4 * s, 5.2 * s), (x, 5.6 * s, z))))
_spruce = _lod(_spruce, lambda x, z, s, rnd: _far_add('cone', rgb(24, 64, 48), (3.4 * s, 8.0 * s, 3.4 * s), (x, .4 * s, z)))
_old_oak = _lod(_old_oak, lambda x, z, s, rnd: (
    _far_add('cube', rgb(70, 52, 38), (1.0 * s, 5.2 * s, 1.0 * s), (x, 2.6 * s, z)),
    _far_add('sphere_lo', rgb(30, 76, 38), (7.5 * s, 5.4 * s, 7.5 * s), (x, 6.6 * s, z))))
_dead_tree = _lod(_dead_tree, lambda x, z, s, rnd: _far_add('cube', rgb(96, 82, 70), (.4 * s, 5.0 * s, .4 * s), (x, 2.5 * s, z)))
_dwarf_birch = _lod(_dwarf_birch, lambda x, z, s, rnd: _far_add('sphere_lo', rgb(206, 186, 110), (1.7 * s, 1.4 * s, 1.7 * s), (x, 2.2 * s, z)))
_boulder = _lod(_boulder, lambda x, z, s, rnd, snow, moss=False: _far_add(
    'sphere_lo', rgb(232, 236, 242) if snow else (rgb(96, 112, 86) if moss else rgb(128, 126, 122)), (2.4 * s, 1.5 * s, 2.0 * s), (x, .3 * s, z)))


_SOFT = [None]


def soft_texture():
    """Круглое пятно с мягким краем (белое, прозрачность падает к краю) - из таких «клочьев» складывается туман."""
    if _SOFT[0] is None:
        try:
            from PIL import Image
            from ursina import Texture
            n = 64
            img = Image.new("RGBA", (n, n))
            px = img.load()
            for y in range(n):
                for x in range(n):
                    d = min(1.0, math.hypot((x + .5) / n - .5, (y + .5) / n - .5) * 2)
                    a = (1 - d * d) ** 2                      # плавный спад до нуля на самом краю
                    px[x, y] = (255, 255, 255, int(255 * a))
            tex = Texture(img)
            try:
                tex.filtering = "bilinear"
            except Exception:
                pass
            _SOFT[0] = tex
        except Exception as e:
            print("Текстура тумана недоступна:", e)
            _SOFT[0] = False
    return _SOFT[0] or None


def _fog_banks(root, loc, rnd):
    """Полосы тумана, привязанные к месту на карте (а не к камере): издалека их видно, подходишь - перед тобой они
    редеют и расступаются, а позади остаются стеной. Каждый клочок - полупрозрачный спрайт одного цвета (цвет тумана),
    поэтому порядок их отрисовки не важен и они не мерцают."""
    tex = soft_texture()
    if tex is None:
        return []
    n = {'forest': 9, 'thicket': 15, 'tundra': 10}[loc]
    thick = loc == 'thicket'
    banks = []
    for _ in range(n):
        R = rnd.uniform(24, 44)
        for _try in range(60):                                 # полоса целиком (с краями) вне арены, построек и лагеря
            x, z = _free_spot(rnd, 45)
            if math.hypot(x - CX, z - CZ) > CAMP_R + R + 12 and all(math.hypot(x - ax, z - az) > ar + R + 8 for ax, az, ar in _AVOID):
                break
        else:
            continue
        sprites = []
        for _ in range(int(R / 3.8)):
            a, r = rnd.uniform(0, 6.283), R * math.sqrt(rnd.random()) * .85
            sz = rnd.uniform(19, 34) * (1.15 if thick else 1.0)
            pos = (x + math.cos(a) * r, rnd.uniform(.9, 3.8 if thick else 3.1), z + math.sin(a) * r)
            e = Entity(parent=root, model='quad', texture=tex, unlit=True, billboard=True, double_sided=True,
                       color=Color(1, 1, 1, 0), scale=sz, position=pos, enabled=False)
            e.hth_pos, e.hth_on = pos, False
            try:
                e.setDepthWrite(False)
                e.setLightOff()
                e.setFogOff()
            except Exception:
                pass
            e.hth_a = rnd.uniform(.08, .15) * (1.4 if thick else 1.0)
            e.hth_last = -1.0
            sprites.append(e)
        banks.append(dict(x=x, z=z, R=R, sprites=sprites, vis=False))
    return banks


def _free_spot(rnd, margin=4):
    for _ in range(200):
        x, z = rnd.uniform(margin, W - margin), rnd.uniform(margin, H - margin)
        if math.hypot(x - CX, z - CZ) > CAMP_R + 4 and all(math.hypot(x - ax, z - az) > ar for ax, az, ar in _AVOID):
            return x, z
    return x, z


def make_chest():
    """Сундук: корпус с окованными краями и крышка на петле (hth_lid поворачивается при открытии)."""
    b = Batch()
    b.add('cube', rgb(110, 72, 40), (.9, .5, .6), (0, .25, 0))
    for sx in (-1, 1):
        b.add('cube', rgb(200, 160, 60), (.05, .52, .62), (sx * .43, .26, 0))
    b.add('cube', rgb(200, 160, 60), (.12, .14, .04), (0, .42, .31))
    root = b.build()
    lid_b = Batch()
    lid_b.add('cube', rgb(126, 84, 46), (.92, .2, .62), (0, .1, .31))
    lid_b.add('cube', rgb(200, 160, 60), (.94, .05, .1), (0, .2, .31))
    pivot = ent(parent=root, position=(0, .5, -.31))
    lid = lid_b.build(parent=pivot)
    root.hth_lid = pivot
    return root


def _structures(b, root, loc, g1, g2):
    """Постройки со случайной раскладкой (общий seed), сундуки и логово босса."""
    L = LAYOUTS.get(loc, {})
    root.hth_chests, root.hth_labels, root.hth_gates, root.hth_arena = {}, [], [], None
    items = list(L.get("structs", [])) + ([L["lair"]] if L.get("lair") else [])
    for s in items:
        bp = BLUEPRINTS[s["kind"]]
        decals = 0
        for shape, lx, ly, lz, sx, sy, sz, col, solid, rot in bp["parts"]:
            wx, wz = struct_world(s, lx, lz)
            r = rot or (0, 0, 0)
            if solid == 2:                                        # силовой барьер ворот арены: полупрозрачная панель (цвет меняет клиент)
                g = ent(parent=root, model='cube', color=Color(.9, .24, .24, .32), scale=(sx, sy, .14), position=(wx, ly, wz),
                        rotation_y=s["yaw"], unlit=True, double_sided=True)
                try:
                    g.setDepthWrite(False)
                    g.setLightOff()
                except Exception:
                    pass
                root.hth_gates.append(dict(e=g, x=wx, z=wz))
                continue
            if shape == "sphere" and sy <= .15 and ly < .1:       # плоские пятна на земле (логово, подстилка) - в слои «наклеек»
                (g1 if decals == 0 else g2).add(shape, rgb(*col), (sx, sy, sz), (wx, ly + .012 * (decals + 1), wz), (r[0], r[1] + s["yaw"], r[2]))
                decals += 1
                continue
            if shape.startswith("rock"):                       # камни всегда стоят на земле (чуть врастают в неё)
                ly = -min(v[1] for v in _SHAPES[shape][0]) * sy - .07
                r = (0, r[1], 0)
            b.add(shape, rgb(*col), (sx, sy, sz), (wx, ly, wz), (r[0], r[1] + s["yaw"], r[2]))
        if "cx" in s:
            ch = make_chest()
            ch.parent = root
            ch.position = (s["cx"], 0, s["cy"])
            ch.rotation_y = s["yaw"] + 180
            root.hth_chests[s["id"]] = dict(e=ch, x=s["cx"], z=s["cy"], name=bp["name"], avail=True, open=0.0)
        if s.get("boss"):
            t = Text(text="АРЕНА БОССА", parent=root, position=(s["x"], 10, s["y"]), origin=(0, 0),
                     scale=34, billboard=True, color=rgb(230, 70, 60))
            root.hth_arena = dict(x=s["x"], z=s["y"], gx=s["gx"], gz=s["gy"], boss=s["boss"], label=t)
        else:
            t = Text(text=bp["name"], parent=root, position=(s["x"], 5.2, s["y"]), origin=(0, 0), scale=16, billboard=True,
                     color=rgb(255, 225, 140))
        root.hth_labels.append((t, s["x"], s["y"], 140 if s.get("boss") else 32))


# ------------------------------------------------------------------ костёр
class Fire:
    """Костёр: три слоя языков пламени, угли, искры, дым и тёплое свечение земли."""

    def __init__(self, root):
        rnd = random.Random(3)
        self.flames = []
        for n, rad, h, col in ((7, .42, 1.15, (226, 58, 14)), (5, .27, 1.55, (255, 126, 26)), (3, .13, 1.15, (255, 218, 92))):
            for _ in range(n):
                a, r = rnd.uniform(0, 6.283), rad * rnd.uniform(.3, 1)
                bt = Batch()
                bt.add('cone', rgb(*col), (1, 1, 1), (0, 0, 0))
                e = bt.build(parent=root, unlit=True)
                e.position = (CX + math.cos(a) * r, .22, CZ + math.sin(a) * r)
                self.flames.append(dict(e=e, h=h * rnd.uniform(.75, 1.2), w=rnd.uniform(.3, .46), ph=rnd.uniform(0, 6.28),
                                        sp=rnd.uniform(7, 12)))
        self.glow = ent(parent=root, model='sphere', unlit=True, color=Color(1, .55, .15, .24), scale=(10, .05, 10),
                        position=(CX, .06, CZ))
        self.coals = ent(parent=root, model='sphere', unlit=True, color=rgb(255, 84, 18), scale=(1.5, .2, 1.5), position=(CX, .12, CZ))
        self.sparks = [dict(e=ent(parent=root, model='cube', unlit=True, scale=.07, enabled=False), v=(0, 0, 0), life=0.0, max=1.0)
                       for _ in range(34)]
        self.smoke = [dict(e=ent(parent=root, model='sphere', unlit=True, scale=.5, enabled=False, color=Color(.34, .34, .36, .25)),
                           life=0.0) for _ in range(12)]
        self.t_spark = self.t_smoke = 0.0
        self.rnd = random.Random(9)

    def update(self, t, dt, near=True):
        for f in self.flames:
            s = .78 + .34 * math.sin(t * f['sp'] + f['ph']) + .14 * math.sin(t * 19 + f['ph'] * 2)
            e = f['e']
            e.scale = (f['w'] * (.9 + .15 * math.sin(t * 6 + f['ph'])), f['h'] * s, f['w'] * (.9 + .15 * math.cos(t * 5 + f['ph'])))
            e.rotation_z = math.sin(t * 3 + f['ph']) * 9
            e.rotation_x = math.cos(t * 2.6 + f['ph']) * 9
        k = .22 + .06 * math.sin(t * 9) + .03 * math.sin(t * 23)
        self.glow.color = Color(1, .55, .15, k)
        self.coals.color = rgb(255, int(70 + 30 * math.sin(t * 7)), 18)
        if not near:
            return
        r = self.rnd
        self.t_spark -= dt
        while self.t_spark <= 0:
            self.t_spark += .09
            sp = next((q for q in self.sparks if q['life'] <= 0), None)
            if sp:
                sp['v'] = (r.uniform(-.5, .8), r.uniform(1.8, 3.6), r.uniform(-.5, .5))
                sp['life'] = sp['max'] = r.uniform(1.1, 2.0)
                sp['e'].position = (CX + r.uniform(-.4, .4), 1.0, CZ + r.uniform(-.4, .4))
                sp['e'].color = rgb(255, r.randint(120, 220), 40)
                sp['e'].enabled = True
        self.t_smoke -= dt
        if self.t_smoke <= 0:
            self.t_smoke = .5
            sm = next((q for q in self.smoke if q['life'] <= 0), None)
            if sm:
                sm['life'] = 4.0
                sm['e'].position = (CX + r.uniform(-.3, .3), 2.0, CZ + r.uniform(-.3, .3))
                sm['e'].enabled = True
        for sp in self.sparks:
            if sp['life'] > 0:
                sp['life'] -= dt
                e = sp['e']
                vx, vy, vz = sp['v']
                e.position = (e.x + vx * dt, e.y + vy * dt, e.z + vz * dt)
                if sp['life'] <= 0:
                    e.enabled = False
                else:
                    e.scale = .07 * min(1.0, sp['life'] / sp['max'] * 2)
        for sm in self.smoke:
            if sm['life'] > 0:
                sm['life'] -= dt
                e = sm['e']
                f = 1 - sm['life'] / 4.0
                e.position = (e.x + .35 * dt, e.y + (1.3 - .5 * f) * dt, e.z + .1 * dt)
                e.scale = .5 + 2.2 * f
                e.color = Color(.34, .34, .36, .26 * (1 - f))
                if sm['life'] <= 0:
                    e.enabled = False


# ------------------------------------------------------------------ палатки и NPC
TENT_STYLE = {"trader": ((190, 60, 50), (234, 212, 172)), "master": ((66, 116, 168), (224, 216, 192)),
              "tracker": ((172, 146, 86), (216, 198, 152)), "radio": ((70, 104, 112), (206, 220, 214))}
SIGNS = {"trader": "ЛАВКА", "master": "ЗАКАЗЫ", "tracker": "СЛЕДОПЫТ", "radio": "РАДАР"}
WOOD, WOOD2, STEEL, PAPER = rgb(112, 78, 46), rgb(150, 106, 62), rgb(60, 64, 72), rgb(236, 226, 196)


def _tent(b, root, t):
    kind = t['npc']
    col, liner = (rgb(*c) for c in TENT_STYLE[kind])
    W_, D_, H_ = TENT_W, TENT_D, TENT_H

    def put(shape, c, scale, lp, rot=(0, 0, 0)):
        wx, wz = tent_world(t, lp[0], lp[2])
        b.add(shape, c, scale, (wx, lp[1], wz), (rot[0], rot[1] + t['yaw'], rot[2]))

    ls, phi = math.hypot(W_ / 2, H_), math.atan2(W_ / 2, H_)
    for sx in (1, -1):                                        # скаты крыши: снаружи ткань, внутри светлая подкладка
        nx, ny = math.cos(phi) * sx, math.sin(phi)
        cx, cy = sx * W_ / 4, H_ / 2
        put('cube', col, (.06, ls, D_ + .3), (cx + nx * .035, cy + ny * .035, 0), (0, 0, sx * math.degrees(phi)))
        put('cube', liner, (.05, ls, D_ + .2), (cx - nx * .035, cy - ny * .035, 0), (0, 0, sx * math.degrees(phi)))
        put('cube', WOOD, (.09, ls, .09), (cx, cy, D_ / 2 + .05), (0, 0, sx * math.degrees(phi)))     # рама входа
    put('blade', col, (W_, H_, .1), (0, 0, -D_ / 2))
    put('blade', liner, (W_ * .96, H_ * .95, .12), (0, 0, -D_ / 2 + .04))
    put('cube', WOOD, (.1, .1, D_ + .5), (0, H_, 0))
    put('cube', rgb(*{"trader": (110, 52, 44), "master": (52, 78, 110), "tracker": (104, 84, 52), "radio": (52, 74, 78)}[kind]), (W_ - .5, .05, D_ - .2), (0, .025, 0))
    put('cube', rgb(90, 64, 40), (1.8, .04, .9), (0, .02, D_ / 2 + .55))
    if kind == "trader":                                      # ящики, стол с весами, стойка с оружием
        put('cube', WOOD2, (.8, .8, .8), (-1.05, .4, -D_ / 2 + .55))
        put('cube', WOOD, (.6, .6, .6), (-1.0, 1.1, -D_ / 2 + .55), (0, 20, 0))
        put('cube', WOOD, (1.0, .08, .6), (1.05, .8, -D_ / 2 + .6))
        for sx2, sz2 in ((-.42, -.22), (.42, -.22), (-.42, .22), (.42, .22)):
            put('cube', WOOD, (.07, .8, .07), (1.05 + sx2, .4, -D_ / 2 + .6 + sz2))
        put('cube', rgb(200, 200, 208), (.3, .05, .3), (1.05, .86, -D_ / 2 + .6))
        put('cube', WOOD, (2.0, .08, .1), (0, 2.0, -D_ / 2 + .18))
        for i, ln in enumerate((.9, .8, 1.0)):
            put('cube', STEEL, (ln, .05, .05), (-.4 + i * .05, 1.9 - i * .12, -D_ / 2 + .22))
    elif kind == "master":                                    # стол с картой, доска заданий, трофей
        put('cube', WOOD, (.95, .08, 1.35), (-1.0, .85, -.1))
        for sx2, sz2 in ((-.4, -.6), (.4, -.6), (-.4, .6), (.4, .6)):
            put('cube', WOOD, (.07, .85, .07), (-1.0 + sx2, .42, -.1 + sz2))
        put('cube', PAPER, (.78, .02, 1.15), (-1.0, .9, -.1))
        for px, pz in ((-1.2, -.4), (-.8, .1), (-1.1, .4)):
            put('cube', rgb(210, 50, 50), (.06, .06, .06), (px, .95, pz))
        put('cube', WOOD, (1.7, 1.0, .06), (0, 1.8, -D_ / 2 + .14))
        for i in range(5):
            put('cube', PAPER, (.28, .36, .02), (-.6 + i * .3, 1.8 + (i % 2) * .15 - .05, -D_ / 2 + .19), (0, 0, (i - 2) * 4))
        put('cube', rgb(225, 215, 190), (.6, .06, .06), (1.0, 2.2, -D_ / 2 + .2))
        for sx2 in (-1, 1):
            put('cube', rgb(225, 215, 190), (.04, .3, .04), (1.0 + sx2 * .26, 2.38, -D_ / 2 + .2), (0, 0, sx2 * -15))
    elif kind == "radio":                                     # рация, экран радара, карта с булавками, антенна снаружи
        SCR, GLOW = rgb(70, 200, 150), rgb(140, 255, 190)
        put('cube', WOOD, (1.5, .08, .8), (-.55, .85, -D_ / 2 + .75))
        for sx2, sz2 in ((-.65, -.3), (.65, -.3), (-.65, .3), (.65, .3)):
            put('cube', WOOD, (.07, .85, .07), (-.55 + sx2, .42, -D_ / 2 + .75 + sz2))
        put('cube', rgb(70, 78, 70), (.8, .3, .42), (-.9, 1.04, -D_ / 2 + .78))             # рация
        put('cube', rgb(30, 34, 36), (.62, .18, .02), (-.9, 1.06, -D_ / 2 + .99))
        for i in range(4):
            put('cube', rgb(220, 200, 120) if i % 2 else rgb(200, 70, 60), (.06, .06, .04), (-1.1 + i * .14, 1.0, -D_ / 2 + 1.0))
        put('cube', rgb(26, 30, 32), (.62, .5, .06), (-.1, 1.2, -D_ / 2 + .5))              # монитор радара
        put('cube', rgb(14, 36, 28), (.54, .42, .02), (-.1, 1.2, -D_ / 2 + .54))
        for ang, rr in ((.6, .1), (2.4, .14), (4.1, .08)):
            put('cube', GLOW, (.04, .04, .02), (-.1 + math.cos(ang) * rr, 1.2 + math.sin(ang) * rr, -D_ / 2 + .55))
        put('cube', SCR, (.5, .015, .02), (-.1, 1.2, -D_ / 2 + .55))
        put('cube', SCR, (.015, .38, .02), (-.1, 1.2, -D_ / 2 + .55))
        put('cube', rgb(34, 36, 40), (.5, .03, .22), (-.1, .9, -D_ / 2 + .95))              # клавиатура
        put('cube', rgb(210, 205, 190), (1.6, 1.0, .03), (0, 1.9, -D_ / 2 + .14))           # карта на стене
        for px, pz in ((-.5, 1.7), (.3, 2.0), (.6, 1.6), (-.2, 2.2)):
            put('cube', rgb(210, 50, 50), (.08, .08, .02), (px, pz, -D_ / 2 + .17))
        put('cube', rgb(60, 70, 60), (.7, .5, .5), (1.3, .25, -D_ / 2 + .6))                 # аккумуляторы
        put('cube', rgb(200, 160, 50), (.5, .06, .3), (1.3, .53, -D_ / 2 + .6))
        put('cube', rgb(26, 28, 30), (.1, .1, 2.2), (.8, .05, -.6), (0, 20, 0))             # провода по полу
        put('cube', STEEL, (.06, 6.5, .06), (1.9, 3.25, -D_ / 2 - .9))                       # антенна и тарелка снаружи палатки
        put('cube', STEEL, (1.3, .05, .05), (1.9, 5.8, -D_ / 2 - .9))
        put('cube', STEEL, (.05, .05, 1.3), (1.9, 6.1, -D_ / 2 - .9))
        put('sphere_lo', rgb(200, 205, 212), (1.5, .5, 1.5), (-1.7, 3.1, -D_ / 2 - 1.1), (50, 0, 0))
        put('cube', STEEL, (.07, 2.7, .07), (-1.7, 1.35, -D_ / 2 - 1.1))
    else:                                                     # спальник, рюкзак, шкуры, ружьё
        put('cube', rgb(122, 92, 62), (.85, .22, 2.0), (-1.0, .11, -.2))
        put('cube', rgb(210, 200, 180), (.6, .12, .4), (-1.0, .27, -.95))
        put('cube', rgb(88, 70, 50), (.5, .6, .4), (1.0, .3, -D_ / 2 + .7))
        put('cube', rgb(132, 100, 70), (.9, 1.1, .05), (-.8, 1.7, -D_ / 2 + .15))
        put('cube', rgb(150, 150, 156), (.8, 1.0, .05), (.4, 1.6, -D_ / 2 + .15))
        put('cube', STEEL, (.05, 1.3, .05), (1.22, .68, -D_ / 2 + 1.5), (0, 0, 10))
        put('cube', WOOD, (.07, .5, .07), (1.4, .3, -D_ / 2 + 1.5), (0, 0, 10))
    lx, lz = tent_world(t, 0, .2)                              # лампа под коньком
    put('cube', rgb(60, 58, 62), (.03, .45, .03), (0, H_ * .8 + .22, .2))
    put('cube', rgb(255, 214, 130), (.16, .22, .16), (0, H_ * .8 - .1, .2))
    gx, gz = tent_world(t, 0, 0)
    ent(parent=root, model='sphere', color=Color(1, .75, .35, .16), scale=(4.2, .02, 4.2), position=(gx, .07, gz), unlit=True)
    sx3, sz3 = tent_world(t, 0, D_ / 2 + .3)
    Text(text=SIGNS[kind], parent=root, position=(sx3, H_ + .8, sz3), origin=(0, 0), scale=18, billboard=True, color=rgb(255, 225, 90))


def make_npc(kind, name, role):
    P = {"trader": dict(coat=(84, 140, 92), pants=(70, 60, 50), hat=(120, 80, 45), skin=(238, 200, 160), hair=(60, 40, 30), beard=(70, 48, 34)),
         "master": dict(coat=(170, 76, 62), pants=(60, 60, 84), hat=None, skin=(240, 206, 176), hair=(96, 52, 30), beard=None),
         "tracker": dict(coat=(92, 102, 84), pants=(70, 64, 52), hat=(150, 150, 156), skin=(226, 186, 150), hair=(220, 220, 220), beard=(228, 228, 228)),
         "radio": dict(coat=(80, 112, 150), pants=(52, 56, 66), hat=None, skin=(236, 198, 160), hair=(64, 52, 44), beard=None)}[kind]
    b = Batch()
    b.add('cube', rgb(*P['coat']), (.56, .78, .34), (0, 1.05, 0))
    b.add('cube', rgb(*[max(0, v - 30) for v in P['coat']]), (.58, .12, .36), (0, .72, 0))
    b.add('sphere', rgb(*P['skin']), .33, (0, 1.62, 0))
    for sx in (-1, 1):
        b.add('cube', rgb(*P['coat']), (.14, .62, .14), (sx * .36, 1.02, 0))
        b.add('cube', rgb(*P['pants']), (.2, .7, .22), (sx * .14, .35, 0))
        b.add('cube', rgb(15, 15, 15), (.04, .04, .03), (sx * .07, 1.66, .16))
    b.add('cube', rgb(*P['hair']), (.34, .22, .12), (0, 1.72, -.1))
    if P['hat']:
        b.add('cube', rgb(*P['hat']), (.4, .13, .4), (0, 1.83, 0))
        b.add('cube', rgb(*P['hat']), (.56, .03, .56), (0, 1.77, 0))
    if P['beard']:
        b.add('cube', rgb(*P['beard']), (.26, .2, .07), (0, 1.5, .15))
    if kind == "radio":                                       # наушники с микрофоном и очки
        b.add('cube', rgb(40, 42, 48), (.4, .05, .06), (0, 1.84, 0))
        for sx in (-1, 1):
            b.add('cube', rgb(40, 42, 48), (.08, .16, .12), (sx * .19, 1.66, 0))
            b.add('cube', rgb(40, 42, 48), (.04, .22, .05), (sx * .2, 1.76, 0))
        b.add('cube', rgb(40, 42, 48), (.03, .03, .16), (-.19, 1.56, .1))
        b.add('cube', rgb(170, 200, 220), (.26, .06, .02), (0, 1.66, .17))
        b.add('cube', rgb(230, 190, 50), (.1, .1, .05), (.2, 1.0, .18))
    if kind == "master":
        b.add('sphere', rgb(*P['hair']), .2, (0, 1.82, -.08))
        b.add('cube', rgb(236, 150, 50), (.4, .07, .36), (0, 1.38, 0))
    root = b.build()
    root.hth_kind = kind
    root.hth_tags = [Text(text=name, parent=root, position=(0, 2.42, 0), origin=(0, 0), scale=6, billboard=True, color=rgb(255, 240, 180)),
                     Text(text=role, parent=root, position=(0, 2.28, 0), origin=(0, 0), scale=4.2, billboard=True, color=rgb(190, 205, 195))]
    root.hth_mark = Text(text="!", parent=root, position=(0, 2.75, 0), origin=(0, 0), scale=26, billboard=True, color=rgb(255, 210, 74))
    root.hth_mark.enabled = False
    return root


def _slot_machine(b, root):
    """Игровой автомат «Золотая тайга»: корпус, экран с тремя барабанами, рычаг, лампочки, вывеска."""
    x, z = SLOT_POS
    yaw = math.degrees(math.atan2(CX - x, CZ - z))           # лицом к костру
    th = math.radians(yaw)

    def P(lx, lz):
        return x + lx * math.cos(th) + lz * math.sin(th), z - lx * math.sin(th) + lz * math.cos(th)

    def put(shape, col, sc, lx, ly, lz, rot=(0, 0, 0)):
        wx, wz = P(lx, lz)
        b.add(shape, col, sc, (wx, ly, wz), (rot[0], rot[1] + yaw, rot[2]))
    RED, GOLDC, DARK = rgb(170, 30, 36), rgb(236, 188, 60), rgb(30, 26, 30)
    put('cube', rgb(60, 50, 44), (1.3, .12, 1.0), 0, .06, 0)                                  # подставка
    put('cube', RED, (1.0, 1.15, .7), 0, .7, 0)                                              # нижний корпус
    put('cube', RED, (1.0, .75, .55), 0, 1.65, -.07)                                         # верх с экраном
    put('cube', GOLDC, (1.06, .06, .76), 0, 1.29, 0)
    put('cube', GOLDC, (1.06, .06, .6), 0, 2.04, -.07)
    put('cube', DARK, (.82, .44, .04), 0, 1.68, .21)                                         # экран
    for i, c in enumerate(((255, 214, 80), (120, 220, 255), (255, 120, 170))):
        put('cube', rgb(240, 236, 226), (.22, .34, .02), (i - 1) * .26, 1.68, .23)            # барабаны
        put('cube', rgb(*c), (.11, .11, .02), (i - 1) * .26, 1.68, .245)
    put('cube', DARK, (.5, .08, .1), 0, 1.12, .33)                                            # приёмник жетонов
    put('cube', GOLDC, (.18, .03, .02), 0, 1.13, .385)
    put('cube', rgb(150, 150, 160), (.06, .5, .06), .58, 1.35, 0, (0, 0, -8))               # рычаг
    put('sphere_lo', RED, (.17, .17, .17), .62, 1.62, 0)
    put('cube', GOLDC, (1.2, .32, .12), 0, 2.32, -.05)                                        # вывеска
    for i in range(7):
        put('sphere_lo', rgb(255, 230, 120), (.07, .07, .07), -.45 + i * .15, 2.12, .2)       # лампочки
    t = Text(text="ЗОЛОТАЯ ТАЙГА", parent=root, position=(x, 2.75, z), origin=(0, 0), scale=7, billboard=True, color=rgb(255, 214, 80))
    glow = ent(parent=root, model='cube', color=Color(1, .85, .35, .5), unlit=True, scale=(1.0, .05, .05),
               position=(x, 2.12, z), rotation_y=yaw)
    root.hth_slot = dict(x=x, z=z, label=t, glow=glow)


def _camp(b, root, g1, g2):
    g1.add('sphere', rgb(128, 98, 62), (CAMP_R * 2, .3, CAMP_R * 2), (CX, .01, CZ))              # вытоптанная земля лагеря
    g2.add('sphere', rgb(150, 118, 78), (CAMP_R * 1.2, .34, CAMP_R * 1.2), (CX, .02, CZ))
    for t in TENTS:
        _tent(b, root, t)
    for i in range(10):                                       # костровище из камней
        a = i * math.pi / 5
        b.add('rock%d' % (i % 3), rgb(110, 112, 118), (.6, .38, .56), (CX + 1.45 * math.cos(a), .13, CZ + 1.45 * math.sin(a)), (0, i * 37, 0))
    for i in range(6):                                        # дрова шалашиком
        a = i * math.pi / 3
        _limb(b, (CX + 1.0 * math.cos(a), .15, CZ + 1.0 * math.sin(a)), (CX + .1 * math.cos(a), 1.05, CZ + .1 * math.sin(a)),
              .17, rgb(70, 46, 28) if i % 2 else rgb(88, 58, 34))
    b.add('cube', rgb(90, 62, 38), (.14, 7, .14), (CX + 3.5, 3.5, CZ - 7))     # флагшток
    b.add('cube', rgb(225, 70, 55), (1.8, 1.1, .05), (CX + 4.4, 6.4, CZ - 7))
    root.hth_fire = Fire(root)
    root.hth_npcs = {}
    for nid, n in NPCS.items():
        e = make_npc(nid, n['name'], n['role'])
        e.parent = root                                       # NPC - часть мира: пересборка и скрытие локации убирают и их (раньше копии оставались)
        e.position = (n['x'], 0, n['y'])
        e.rotation_y = n['yaw']
        root.hth_npcs[nid] = e


def build_location(loc):
    """Строит локацию, возвращает корневой Entity (скрытый). Три разных биома:
    Лес - светлый и открытый: поляны с цветами, берёзы и лиственные рощи, пруды с кувшинками.
    Чаща - тёмный старый лес: высокие ели и могучие дубы, бурелом, мох, грибы, папоротник, болотца с камышом, туман.
    Тундра - снег, редкие ели и карликовые берёзы, сугробы, лёд, валуны, северное сияние ночью."""
    tundra, thick, forest = loc == 'tundra', loc == 'thicket', loc == 'forest'
    rnd = random.Random(SEED * 1000 + {'forest': 7, 'thicket': 21, 'tundra': 11}[loc])
    root = ent(unlit=True)
    ph1, ph2 = rnd.uniform(0, 6.28), rnd.uniform(0, 6.28)
    L = LAYOUTS.get(loc, {})
    _AVOID[:] = [(x, z, r + 5) for x, z, r in L.get("centers", [])]

    def n(v):
        return max(1, int(v * DENSITY * AREA ** .85))

    def meadow(x, z):                                         # поляны в лесу: там нет деревьев, зато много цветов
        return forest and math.sin(x * .034 + ph1) * math.sin(z * .045 + ph2) > .32

    if forest:
        kw = dict(color=rgb(216, 238, 182), texture='grass', texture_scale=((W + 400) / 6, (H + 400) / 6))
    elif thick:
        kw = dict(color=rgb(112, 128, 86), texture='grass', texture_scale=((W + 400) / 5, (H + 400) / 5))
    else:
        kw = dict(color=rgb(234, 240, 248))
    ent(parent=root, model='plane', scale=(W + 400, 1, H + 400), position=(CX, 0, CZ), **kw)
    bb, b = Batch(chunk=256), Batch(chunk=128)               # основа 256 м / подробные деревья 128 м: меньше вызовов отрисовки,
                                                              # больше работы видеокарте (она простаивала)
    gp = [Batch() for _ in range(4)]                          # пятна на земле: 4 группы с разной глубиной (каждая - один меш на всю карту)
    g1, g2 = Batch(), Batch()                 # лагерь, берега и вода, подстилки: поверх пятен; чем выше слой, тем ближе к камере
    FAR[0] = Batch(chunk=128)                                 # упрощённые деревья: та же сетка 128 м, что и у подробных -
                                                              # в каждом участке рисуется ровно одна версия (без дыр и дублей)
    holes = []
    for pi in range(int((70 if thick else 45) * AREA)):       # пятна на земле
        x, z = rnd.uniform(-20, W + 20), rnd.uniform(-20, H + 20)
        k = rnd.uniform(.9, 1.1)
        if forest:
            c = (int(96 * k), int(156 * k), int(62 * k)) if rnd.random() < .7 else (int(150 * k), int(168 * k), int(70 * k))
        elif thick:
            c = (int(42 * k), int(80 * k), int(42 * k)) if rnd.random() < .55 else (int(98 * k), int(74 * k), int(50 * k))   # мох / хвоя
        else:
            c = (int(246 * k), int(250 * k), 255)
        gp[pi % 4].add('sphere', rgb(*[min(255, v) for v in c]), (rnd.uniform(6, 20), .12 if not tundra else .5, rnd.uniform(6, 20)), (x, .015, z))
    if forest:                                                # пруды с кувшинками
        for _ in range(int(3 * AREA ** .7)):
            x, z = _free_spot(rnd, 30)
            rx, rz = rnd.uniform(7, 12), rnd.uniform(6, 10)
            holes.append((x, z, rx * 1.15, rz * 1.15))
            g1.add('sphere', rgb(112, 100, 72), (rx * 1.12, .05, rz * 1.12), (x, .02, z))
            g2.add('sphere', rgb(70, 140, 178), (rx, .07, rz), (x, .04, z))
            for _ in range(rnd.randint(4, 8)):
                a_, r_ = rnd.uniform(0, 6.283), rnd.uniform(.2, .8)
                b.add('sphere_lo', rgb(52, 120, 56), (.9, .03, .9), (x + math.cos(a_) * rx * .45 * r_, .08, z + math.sin(a_) * rz * .45 * r_))
            for _ in range(3):
                a_ = rnd.uniform(0, 6.283)
                _reeds(b, x + math.cos(a_) * rx * .5, z + math.sin(a_) * rz * .5, rnd)
    elif thick:                                               # тёмные болотца с камышом
        for _ in range(int(7 * AREA ** .7)):
            x, z = _free_spot(rnd, 25)
            rx, rz = rnd.uniform(4, 9), rnd.uniform(3, 7)
            holes.append((x, z, rx * .6, rz * .6))
            g2.add('sphere', rgb(34, 52, 38), (rx, .06, rz), (x, .04, z))
            for _ in range(4):
                a_ = rnd.uniform(0, 6.283)
                _reeds(b, x + math.cos(a_) * rx * .45, z + math.sin(a_) * rz * .45, rnd)
    else:                                                     # замёрзшие озёра со льдом
        for _ in range(int(5 * AREA ** .7)):
            x, z = _free_spot(rnd, 25)
            rx, rz = rnd.uniform(10, 22), rnd.uniform(8, 16)
            holes.append((x, z, rx * .6, rz * .6))
            g2.add('sphere', rgb(160, 208, 236), (rx, .1, rz), (x, .04, z))
            for _ in range(3):
                a_ = rnd.uniform(0, 6.283)
                _ice(b, x + math.cos(a_) * rx * .5, z + math.sin(a_) * rz * .5, rnd)
    _camp(bb, root, g1, g2)
    _slot_machine(bb, root)
    _structures(bb, root, loc, g1, g2)

    if forest:                                                # ---------- ЛЕС: густые рощи, поляны, бурелом
        def forest_tree(x, z):
            s = rnd.uniform(.8, 1.4)
            r = rnd.random()
            if r < .62:
                _broadleaf(b, x, z, s, rnd, birch_p=.3, light=1.12)
            elif r < .9:
                _pine(b, x, z, s, False, rnd)
            else:
                _spruce(b, x, z, s * .85, rnd)
        for _ in range(n(230)):
            x, z = _free_spot(rnd)
            if not meadow(x, z):
                forest_tree(x, z)
        for _ in range(n(16)):                                # особо густые рощи
            gx, gz = _free_spot(rnd, 20)
            if meadow(gx, gz):
                continue
            for _ in range(rnd.randint(8, 14)):
                x, z = gx + rnd.uniform(-14, 14), gz + rnd.uniform(-14, 14)
                if 4 < x < W - 4 and 4 < z < H - 4 and math.hypot(x - CX, z - CZ) > CAMP_R + 6 and \
                        all(math.hypot(x - ax, z - az) > ar for ax, az, ar in _AVOID):
                    forest_tree(x, z)
        for _ in range(n(26)):                                # поваленные деревья
            x, z = _free_spot(rnd)
            _fallen_tree(b, x, z, rnd.uniform(.8, 1.2), rnd, moss=rnd.random() < .5)
        for _ in range(n(60)):
            x, z = _free_spot(rnd)
            _bush(b, x, z, rnd.uniform(.7, 1.2), rnd, berries=rnd.random() < .35, autumn=rnd.random() < .1)
        for _ in range(n(120)):                               # цветы - больше всего на полянах
            x, z = _free_spot(rnd)
            if meadow(x, z) or rnd.random() < .35:
                _flowers(b, x, z, rnd)
        for _ in range(n(12)):
            x, z = _free_spot(rnd)
            _rock(b, x, z, rnd.uniform(.6, 1.6), rnd, False)
        for _ in range(n(6)):
            x, z = _free_spot(rnd)
            _stump(b, x, z)
        for _ in range(n(5)):
            x, z = _free_spot(rnd)
            _log(b, x, z, rnd)
    elif thick:                                               # ---------- ЧАЩА: ели, дубы, бурелом, мох
        for _ in range(n(165)):
            x, z = _free_spot(rnd)
            s = rnd.uniform(1.1, 1.8)
            r = rnd.random()
            if r < .68:
                _spruce(b, x, z, s, rnd)
            elif r < .88:
                _old_oak(b, x, z, s * .85, rnd)
            else:
                _dead_tree(b, x, z, s, rnd)
        for _ in range(n(22)):
            x, z = _free_spot(rnd)
            _fallen_tree(b, x, z, rnd.uniform(.8, 1.3), rnd)
        for _ in range(n(170)):
            x, z = _free_spot(rnd)
            _fern(b, x, z, rnd, big=True)
        for _ in range(n(120)):
            x, z = _free_spot(rnd)
            _bush(b, x, z, rnd.uniform(.9, 1.5), rnd, berries=rnd.random() < .15)
        for _ in range(n(90)):
            x, z = _free_spot(rnd)
            for _ in range(rnd.randint(2, 5)):
                _mushroom(b, x + rnd.uniform(-.7, .7), z + rnd.uniform(-.7, .7), rnd)
        for _ in range(n(26)):
            x, z = _free_spot(rnd)
            _rock(b, x, z, rnd.uniform(.8, 2.0), rnd, False, moss=True)
        for _ in range(n(18)):
            x, z = _free_spot(rnd)
            _boulder(b, x, z, rnd.uniform(1.1, 2.4), rnd, False, moss=True)
        for _ in range(n(24)):
            x, z = _free_spot(rnd)
            _stump(b, x, z)
    else:                                                     # ---------- ТУНДРА: простор, снег, лёд
        for _ in range(n(38)):
            x, z = _free_spot(rnd)
            _pine(b, x, z, rnd.uniform(.7, 1.2), True, rnd)
        for _ in range(n(26)):
            x, z = _free_spot(rnd)
            _dwarf_birch(b, x, z, rnd.uniform(.8, 1.3), rnd)
        for _ in range(n(10)):
            x, z = _free_spot(rnd)
            _dead_tree(b, x, z, rnd.uniform(.8, 1.2), rnd)
        for _ in range(n(40)):                                # сугробы
            x, z = _free_spot(rnd)
            bb.add('sphere', rgb(248, 251, 255), (rnd.uniform(3, 9), rnd.uniform(.6, 1.6), rnd.uniform(3, 7)), (x, 0, z),
                  (0, rnd.uniform(0, 360), 0))
        for _ in range(n(30)):
            x, z = _free_spot(rnd)
            _rock(b, x, z, rnd.uniform(.8, 2.2), rnd, True)
        for _ in range(n(20)):
            x, z = _free_spot(rnd)
            _boulder(b, x, z, rnd.uniform(1.3, 3.0), rnd, True)
        for _ in range(n(50)):
            x, z = _free_spot(rnd)
            _dry_shrub(b, x, z, rnd, True)

    step = 6 if thick else 9                                  # стена деревьев по краю карты
    edge = [(x, 1.5) for x in range(0, int(W) + 1, step)] + [(x, H - 1.5) for x in range(0, int(W) + 1, step)]
    edge += [(1.5, z) for z in range(0, int(H) + 1, step)] + [(W - 1.5, z) for z in range(0, int(H) + 1, step)]
    for x, z in edge:
        x, z = x + rnd.uniform(-2, 2), z + rnd.uniform(-2, 2)
        if thick:
            _spruce(b, x, z, rnd.uniform(1.6, 2.1), rnd)
        elif forest and rnd.random() < .5:
            _broadleaf(b, x, z, rnd.uniform(1.4, 1.9), rnd, birch_p=.2, light=1.05)
        else:
            _pine(b, x, z, rnd.uniform(1.6, 2.2), tundra, rnd)
    for i in range(int(46 * AREA ** .5)):                     # горы по периметру
        side = i % 4
        d = rnd.uniform(35, 120)
        x, z = ((rnd.uniform(-90, W + 90), -d), (rnd.uniform(-90, W + 90), H + d), (-d, rnd.uniform(-90, H + 90)),
                (W + d, rnd.uniform(-90, H + 90)))[side]
        sx, sy, sz = rnd.uniform(60, 120), rnd.uniform(35, 80), rnd.uniform(60, 120)
        c = rnd.randint(-12, 12)
        col = rgb(26 + c, 56 + c, 38 + c) if thick else rgb(82 + c, 122 + c, 104 + c) if forest else rgb(130 + c, 142 + c, 160 + c)
        bb.add('sphere', col, (sx, sy, sz), (x, -sy * .12, z))
        if tundra or (forest and sy > 62):
            bb.add('sphere', rgb(240, 245, 252), (sx * .45, sy * .3, sz * .45), (x, sy * .32, z))
    far_b, FAR[0] = FAR[0], None
    root.hth_chunks = []
    for layer, bt, off in (("base", bb, 0), ("gp0", gp[0], 1), ("gp1", gp[1], 2), ("gp2", gp[2], 3), ("gp3", gp[3], 4),
                           ("g1", g1, 5), ("g2", g2, 6), ("near", b, 0), ("far", far_b, 0)):
        built = bt.build(parent=root, offset=off)
        root.hth_chunks += [(e, cx, cz, inside, layer, hs) for e, cx, cz, inside, hs in built.hth_chunks]
    holes += [(x, z, r * (1.0 if r > 20 else .8), r * (1.0 if r > 20 else .8)) for x, z, r in L.get("centers", [])]          # в постройках и на арене трава не растёт
    base = (84, 156, 58) if forest else (32, 82, 40) if thick else (196, 180, 122)
    flowers = .16 if forest else .02 if thick else 0.0
    try:
        root.hth_grass = GrassField(root, W, H, base, dry=tundra, thick=thick, level=GRASS_LEVEL, holes=holes,
                                    camp=CAMP, camp_r=CAMP_R, seed=SEED * 10 + {'forest': 3, 'thicket': 4, 'tundra': 5}[loc], flowers=flowers,
                                    area=AREA ** .8)
    except Exception as e:                                    # трава - украшение: если не получилось, играем без неё
        print("Трава не создана:", e)
        root.hth_grass = None
    root.hth_banks = _fog_banks(root, loc, random.Random(SEED * 77 + {'forest': 1, 'thicket': 2, 'tundra': 3}[loc]))
    root.enabled = False
    return root
