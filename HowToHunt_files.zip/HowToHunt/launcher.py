"""HOW TO HUNT - установщик и запуск (только стандартная библиотека Python).

    python launcher.py             - установить всё нужное, создать ярлыки и запустить игру
    python launcher.py --no-launch - только установить
    python launcher.py --low       - то же, но игра стартует с низкой графикой

Игра ставится в ~/.how_to_hunt (game - файлы, venv3d - движок). Дальше достаточно ярлыка на рабочем столе
или в меню «Пуск»: он запускает игру без консоли, открывается одно окно.
"""
import base64
import os
import shutil
import subprocess
import sys
import venv

HERE = os.path.dirname(os.path.abspath(__file__))
HOME = os.path.join(os.path.expanduser("~"), ".how_to_hunt")
GAME_DIR = os.path.join(HOME, "game")
ENV = os.path.join(HOME, "venv3d")
WIN = os.name == "nt"
PY = os.path.join(ENV, "Scripts" if WIN else "bin", "python.exe" if WIN else "python")
PYW = os.path.join(ENV, "Scripts", "pythonw.exe") if WIN else PY          # pythonw - без окна консоли
GAME = os.path.join(GAME_DIR, "how_to_hunt.py")
ICO = os.path.join(GAME_DIR, "assets", "icon.ico")
PNG = os.path.join(GAME_DIR, "assets", "icon.png")
FILES = ["how_to_hunt.py", "world3d.py", "server.py", "ui.py", "fx.py", "sfx.py", "grass.py"]
NAME = "HOW TO HUNT"
QUIET = dict(stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def step(n, title):
    print(f"\n[{n}/5] {title}")


def fail(msg):
    print(f"\nОШИБКА: {msg}")
    if sys.stdin and sys.stdin.isatty():
        input("Нажмите Enter, чтобы закрыть...")
    sys.exit(1)


def has_engine():
    return os.path.exists(PY) and subprocess.call([PY, "-c", "import ursina, numpy"], **QUIET) == 0


# ---------------------------------------------------------------- файлы игры
def install_files():
    os.makedirs(GAME_DIR, exist_ok=True)
    if os.path.samefile(HERE, GAME_DIR):
        return
    for f in FILES:
        src = os.path.join(HERE, f)
        if not os.path.exists(src):
            fail(f"не найден файл {f}. Положите все файлы игры в одну папку с установщиком.")
        shutil.copyfile(src, os.path.join(GAME_DIR, f))
    shutil.copytree(os.path.join(HERE, "assets"), os.path.join(GAME_DIR, "assets"), dirs_exist_ok=True)


# ---------------------------------------------------------------- ярлыки (Windows)
def ps(script):
    """Выполняет PowerShell-скрипт через -EncodedCommand (русские пути и кавычки не ломаются), вернёт текст UTF-8."""
    full = "[Console]::OutputEncoding=[Text.Encoding]::UTF8;" + script
    enc = base64.b64encode(full.encode("utf-16-le")).decode()
    out = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc],
                         capture_output=True, creationflags=NOWIN, timeout=60)
    return out.stdout.decode("utf-8", "replace").strip()


def q(s):
    return "'" + s.replace("'", "''") + "'"


def windows_shortcuts():
    desktop = ps("[Environment]::GetFolderPath('Desktop')")           # учитывает OneDrive и русские пути
    programs = os.path.join(ps("[Environment]::GetFolderPath('Programs')"), NAME)
    os.makedirs(programs, exist_ok=True)
    uninstall = os.path.join(HOME, "uninstall.bat")
    lnk_desktop = os.path.join(desktop, NAME + ".lnk")
    lnk_menu = os.path.join(programs, NAME + ".lnk")
    lnk_remove = os.path.join(programs, "Удалить " + NAME + ".lnk")
    with open(uninstall, "w", encoding="utf-8", newline="\r\n") as f:
        f.write("\n".join([
            "@echo off", "chcp 65001 >nul", f"title Удаление {NAME}",
            f"echo Будет удалена игра {NAME}: ярлыки и файлы игры.",
            f"echo Ваши сохранения останутся в папке {HOME}",
            'choice /c YN /m "Удалить игру? Y - да, N - нет"', "if errorlevel 2 exit /b",
            f'del /q "{lnk_desktop}" 2>nul', f'rmdir /s /q "{programs}" 2>nul',
            'reg delete "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\HowToHunt" /f >nul 2>nul',
            'cd /d "%TEMP%"', f'rmdir /s /q "{GAME_DIR}" 2>nul', f'rmdir /s /q "{ENV}" 2>nul', f'rmdir /s /q "{os.path.join(HOME, "sfx")}" 2>nul',
            "echo Готово. Игра удалена.", "pause", ""]))

    def link(path, target, args, icon, desc):
        ps("$l=(New-Object -ComObject WScript.Shell).CreateShortcut(%s);$l.TargetPath=%s;$l.Arguments=%s;"
           "$l.WorkingDirectory=%s;$l.IconLocation=%s;$l.Description=%s;$l.Save()"
           % (q(path), q(target), q(args), q(GAME_DIR), q(icon + ",0"), q(desc)))

    link(lnk_desktop, PYW, '"%s"' % GAME, ICO, NAME)
    link(lnk_menu, PYW, '"%s"' % GAME, ICO, NAME)
    link(lnk_remove, uninstall, "", ICO, "Удаление " + NAME)
    try:                                                              # запись в «Установленные приложения»
        import winreg
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Uninstall\HowToHunt")
        for k, v in (("DisplayName", NAME), ("DisplayIcon", ICO), ("InstallLocation", GAME_DIR), ("Publisher", NAME),
                     ("DisplayVersion", "1.0"), ("UninstallString", 'cmd.exe /c "%s"' % uninstall)):
            winreg.SetValueEx(key, k, 0, winreg.REG_SZ, v)
        winreg.SetValueEx(key, "NoModify", 0, winreg.REG_DWORD, 1)
    except Exception as e:
        print("Запись об установке не создана:", e)
    return lnk_desktop


# ---------------------------------------------------------------- ярлыки (Linux)
def linux_shortcuts():
    text = ("[Desktop Entry]\nType=Application\nName=%s\nComment=Мультиплеерная 3D-охота\nExec=\"%s\" \"%s\"\nPath=%s\n"
            "Icon=%s\nTerminal=false\nCategories=Game;\n" % (NAME, PY, GAME, GAME_DIR, PNG))
    paths = [os.path.join(os.path.expanduser("~"), ".local", "share", "applications", "howtohunt.desktop")]
    desk = os.path.join(os.path.expanduser("~"), "Desktop")
    if os.path.isdir(desk):
        paths.append(os.path.join(desk, "howtohunt.desktop"))
    for p in paths:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(text)
        os.chmod(p, 0o755)
    return paths[-1]


# ---------------------------------------------------------------- запуск
def start_game(extra):
    if WIN:                                                           # без консоли, отдельным процессом
        flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        subprocess.Popen([PYW, GAME, *extra], cwd=GAME_DIR, creationflags=flags, close_fds=True)
    else:
        subprocess.Popen([PY, GAME, *extra], cwd=GAME_DIR, start_new_session=True)


def main():
    args = sys.argv[1:]
    print(f"=== {NAME} (3D) - установка ===")
    step(1, "Проверка Python")
    if sys.version_info < (3, 10):
        fail(f"Нужен Python 3.10 или новее, а у вас {sys.version.split()[0]}. Лучше всего подходит Python 3.12.")
    print("Python", sys.version.split()[0], "- подходит")

    step(2, "Подготовка игрового окружения (создаётся один раз)")
    if not os.path.exists(PY):
        try:
            venv.EnvBuilder(with_pip=True).create(ENV)
        except Exception as e:                   # на Debian/Ubuntu нужен пакет python3-venv
            shutil.rmtree(ENV, ignore_errors=True)
            fail(f"не удалось создать окружение ({e}).\n"
                 "На Ubuntu/Debian выполните: sudo apt install python3-venv python3-pip")
    print("готово:", ENV)

    step(3, "Загрузка 3D-движка Ursina, Panda3D и numpy (около 120 МБ, только в первый раз)")
    if has_engine():
        print("уже установлено")
    else:
        code = subprocess.call([PY, "-m", "pip", "install", "--disable-pip-version-check", "--upgrade", "ursina", "numpy"])
        if code != 0 or not has_engine():
            fail("не удалось скачать ursina. Проверьте интернет и попробуйте снова.\n"
                 "Если у вас очень новый Python (3.14 и выше), поставьте Python 3.12 с python.org.")

    step(4, "Установка игры и ярлыков")
    install_files()
    print("файлы игры:", GAME_DIR)
    try:
        shortcut = windows_shortcuts() if WIN else linux_shortcuts()
        print("ярлык создан:", shortcut)
    except Exception as e:
        print("Ярлык создать не удалось (игру всё равно можно запустить):", e)

    step(5, "Запуск игры")
    if "--no-launch" in args:
        print("пропущено (--no-launch)")
        return
    start_game([a for a in args if a != "--no-launch"])
    print("Игра запущена в отдельном окне. В следующий раз просто нажмите ярлык «HOW TO HUNT».")


if __name__ == "__main__":
    main()
