@echo off
chcp 65001 >nul
title HOW TO HUNT - сборка Setup.exe
cd /d "%~dp0"
echo Сборка установщика HowToHunt-Setup.exe. Нужен интернет, первый раз это займёт 10-20 минут.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_setup.ps1"
if errorlevel 1 (
    echo.
    echo Сборка не удалась. Сделайте скриншот текста ошибки выше и пришлите разработчику.
)
echo.
pause
