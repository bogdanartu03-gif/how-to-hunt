import http.server, socketserver, webbrowser, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
class H(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map, '.wasm': 'application/wasm', '.js': 'text/javascript'}
socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(("127.0.0.1", 8080), H) as s:
    print("HOW TO HUNT: http://localhost:8080  (закройте окно, чтобы остановить)")
    webbrowser.open("http://localhost:8080/index.html")
    s.serve_forever()
